# Como usar este projeto no GitHub pelo celular

1. Extraia este ZIP no celular.
2. No GitHub, crie um repositório vazio.
3. Envie os arquivos e pastas que estão DENTRO da pasta `cacau-r1-android` para a raiz do repositório. Inclua também a pasta oculta `.github/workflows` e o arquivo `build-apk.yml`.
4. Abra a aba **Actions**. Se necessário, habilite GitHub Actions.
5. Selecione **Build Cacau R1 APK** e toque em **Run workflow**. Também pode iniciar automaticamente quando enviar os arquivos para `main` ou `master`.
6. Quando a execução terminar com sucesso, abra a execução e baixe o artefato `Cacau-R1-debug-APK`.

Observação: o GitHub não extrai ZIPs enviados como um único arquivo. É necessário extrair o ZIP e enviar seu conteúdo ao repositório. A configuração automatiza a compilação, mas o APK só estará disponível se o build terminar com sucesso.
