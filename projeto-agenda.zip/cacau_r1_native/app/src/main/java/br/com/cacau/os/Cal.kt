package br.com.cacau.os

import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Entende pedidos como "marca reunião amanhã às 15h" ou "adiciona na agenda ligar o ar daqui a uma hora". */
object Cal {
    class Parsed(val title: String, val startMs: Long, val durMin: Int)

    private val BR = Locale("pt", "BR")

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(BR), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private val VERB = Regex(
        "\\b(marca|marcar|marque|agenda|agendar|agende|cria|criar|crie|adiciona|adicionar|adicione|" +
            "coloca|colocar|coloque|poe|bota|registra|registrar|salva|salvar)\\b"
    )
    private val NOUN = Regex(
        "\\b(evento|compromisso|reuniao|consulta|tarefa|na agenda|no calendario|google agenda|" +
            "na minha agenda|no meu calendario)\\b"
    )

    /** Só conta como "criar evento" se tiver um verbo de criar e uma palavra de agenda. */
    fun looksLikeCreate(raw: String): Boolean {
        val t = norm(raw)
        return VERB.containsMatchIn(t) && NOUN.containsMatchIn(t)
    }

    private val NUM = mapOf(
        "um" to 1.0, "uma" to 1.0, "dois" to 2.0, "duas" to 2.0, "tres" to 3.0, "quatro" to 4.0,
        "cinco" to 5.0, "seis" to 6.0, "meia" to 0.5, "meio" to 0.5
    )

    private val WEEKDAYS = listOf(
        "domingo" to Calendar.SUNDAY, "segunda" to Calendar.MONDAY, "terca" to Calendar.TUESDAY,
        "quarta" to Calendar.WEDNESDAY, "quinta" to Calendar.THURSDAY, "sexta" to Calendar.FRIDAY,
        "sabado" to Calendar.SATURDAY
    )

    private fun cleanup(s: String): String {
        var r = s.replace(Regex("\\s+"), " ").trim()
        r = r.trim(' ', ',', '.', ':', ';', '-', '"', '“', '”')
        r = r.replace(Regex("^(?:para|pra|de|do|da|que)\\s+", RegexOption.IGNORE_CASE), "")
        r = r.replace(Regex("\\s+(?:para|pra|de|em|as|às|a)$", RegexOption.IGNORE_CASE), "")
        r = r.trim(' ', ',', '.', ':', ';', '-')
        return if (r.isEmpty()) "" else r.substring(0, 1).uppercase(BR) + r.substring(1)
    }

    /** Tira da frase tudo que não é o assunto do compromisso (verbo, dia, hora). */
    private fun titleFrom(raw: String): String {
        val ic = RegexOption.IGNORE_CASE
        Regex("(?:t[ií]tulo|chamad[oa]|com o nome)\\s*[:\"“]?\\s*(.+)$", ic).find(raw)?.let {
            val t = cleanup(it.groupValues[1])
            if (t.isNotEmpty()) return t
        }
        var t = raw
        val strip = listOf(
            "\\b(?:daqui(?: a)?|em)\\s+(?:\\d+(?:[.,]\\d+)?|um|uma|dois|duas|tr[eê]s|quatro|cinco|seis|meia|meio)\\s*(?:minutos?|min|horas?|h)\\b(?:\\s+e\\s+meia)?",
            "\\b(?:depois de amanh[ãa]|amanh[ãa]|hoje)\\b",
            "\\b(?:segunda|ter[çc]a|quarta|quinta|sexta)(?:-feira)?\\b",
            "\\b(?:s[áa]bado|domingo)\\b",
            "\\bdia\\s+\\d{1,2}\\b",
            "\\b(?:[àa]s|pras|para as)\\s+\\d{1,2}(?:[:h]\\d{2})?(?:\\s*(?:h\\b|horas?\\b))?(?:\\s+da\\s+(?:manh[ãa]|tarde|noite|madrugada))?",
            "\\b\\d{1,2}[:h]\\d{2}\\b",
            "\\b\\d{1,2}h\\b",
            "\\bmeio[- ]dia\\b",
            "\\bmeia[- ]noite\\b",
            "\\b(?:na minha agenda|na agenda|no meu calend[áa]rio|no calend[áa]rio|no google agenda|no google calendar)\\b",
            "\\bpor favor\\b"
        )
        for (p in strip) t = t.replace(Regex(p, ic), " ")
        t = t.replace(Regex("^\\s*(?:cacau[, ]+)?(?:marca|marcar|marque|agenda|agendar|agende|cria|criar|crie|adiciona|adicionar|adicione|coloca|colocar|coloque|p[õo]e|bota|registra|registrar|salva|salvar)\\s+", ic), "")
        t = t.replace(Regex("^\\s*(?:um|uma|o|a)?\\s*(?:novo|nova)?\\s*(?:evento|compromisso|tarefa)\\s*(?:para|pra|de|:)?\\s*", ic), "")
        t = t.replace(Regex("^\\s*(?:um|uma)\\s+(?=(?:reuni[ãa]o|consulta))", ic), "")
        return cleanup(t)
    }

    /** Descobre o instante pedido. Devolve null se não achar dia nem hora. */
    private fun whenFrom(raw: String, now: Long): Long? {
        var t = norm(raw)
        val cal = Calendar.getInstance()
        cal.timeInMillis = now

        // "daqui a 30 minutos", "daqui a uma hora", "daqui a duas horas", "daqui a meia hora"
        Regex("\\b(?:daqui(?: a)?|em)\\s+(\\d+(?:[.,]\\d+)?|um|uma|dois|duas|tres|quatro|cinco|seis|meia|meio)\\s*(minutos?|min|horas?|h)\\b(\\s+e\\s+meia)?").find(t)?.let { m ->
            val q = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: NUM[m.groupValues[1]] ?: return@let
            val unit = m.groupValues[2]
            var mins = if (unit.startsWith("h")) q * 60.0 else q
            if (m.groupValues[3].isNotEmpty() && unit.startsWith("h")) mins += 30.0
            return now + Math.round(mins) * 60000L
        }

        // dia
        var dayOffset = -1
        when {
            Regex("\\bdepois de amanha\\b").containsMatchIn(t) -> dayOffset = 2
            Regex("\\bamanha\\b").containsMatchIn(t) -> dayOffset = 1
            Regex("\\bhoje\\b").containsMatchIn(t) -> dayOffset = 0
        }
        var dayOfMonth = -1
        Regex("\\bdia\\s+(\\d{1,2})\\b").find(t)?.let {
            dayOfMonth = it.groupValues[1].toInt()
            t = t.replace(it.value, " ")
        }
        var weekday = -1
        if (dayOffset < 0 && dayOfMonth < 0) {
            for ((name, num) in WEEKDAYS) if (Regex("\\b$name\\b").containsMatchIn(t)) { weekday = num; break }
        }

        // hora
        var hour = -1
        var minute = 0
        if (Regex("\\bmeio[- ]dia\\b").containsMatchIn(t)) { hour = 12 }
        else if (Regex("\\bmeia[- ]noite\\b").containsMatchIn(t)) { hour = 0 }
        else {
            val withAs = Regex("\\b(?:as|pras|para as)\\s+(\\d{1,2})(?:(?::|h)(\\d{2}))?(?:\\s*(?:h\\b|horas?\\b))?(?:\\s+da\\s+(manha|tarde|noite|madrugada))?").find(t)
            val clock = Regex("\\b(\\d{1,2})(?::|h)(\\d{2})\\b").find(t)
            val bareH = Regex("\\b(\\d{1,2})h\\b").find(t)
            val m = withAs ?: clock ?: bareH
            if (m != null) {
                hour = m.groupValues[1].toInt()
                minute = m.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
                val period = if (m === withAs) m.groupValues[3] else ""
                if ((period == "tarde" || period == "noite") && hour in 1..11) hour += 12
                if (period == "noite" && hour == 12) hour = 0
            }
        }
        if (hour !in 0..23 || minute !in 0..59) {
            if (hour == -1 && (dayOffset >= 0 || dayOfMonth >= 0 || weekday >= 0)) { hour = 9; minute = 0 } else return null
        }

        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        when {
            dayOffset >= 0 -> cal.add(Calendar.DAY_OF_YEAR, dayOffset)
            dayOfMonth in 1..31 -> {
                if (dayOfMonth < cal.get(Calendar.DAY_OF_MONTH)) cal.add(Calendar.MONTH, 1)
                cal.set(Calendar.DAY_OF_MONTH, minOf(dayOfMonth, cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
            }
            weekday >= 0 -> {
                var add = (weekday - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7
                cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute)
                if (add == 0 && cal.timeInMillis <= now) add = 7
                cal.add(Calendar.DAY_OF_YEAR, add)
            }
        }
        cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute)
        // sem dia: hoje se a hora ainda não passou, senão amanhã
        if (dayOffset < 0 && dayOfMonth < 0 && weekday < 0 && cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    /** Interpretação por regras (funciona sem IA). */
    fun parse(raw: String, now: Long): Parsed? {
        val start = whenFrom(raw, now) ?: return null
        val title = titleFrom(raw).ifEmpty { "Compromisso" }
        return Parsed(title, start, 60)
    }

    /** A IA só ajuda a achar o título (e o horário, se as regras não acharem). Devolve null se falhar. */
    fun parseWithAi(key: String, raw: String, now: Long): Parsed? {
        val df = SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", BR)
        val prompt = "Agora é " + df.format(Date(now)) + " (fuso " + java.util.TimeZone.getDefault().id + "). " +
            "O usuário pediu: \"" + raw.replace("\"", "'") + "\". " +
            "Extraia UM evento de calendário. Responda JSON com: " +
            "\"title\" (assunto curto em português, sem verbos como marcar ou adicionar, sem dia nem hora), " +
            "\"start\" (data e hora local no formato yyyy-MM-dd'T'HH:mm, ou null se não houver hora clara), " +
            "\"duration_min\" (inteiro, 60 se não for dito)."
        val j: JSONObject = Groq.json(key, prompt, 15000) ?: return null
        val title = cleanup(j.optString("title", ""))
        if (title.isEmpty()) return null
        val s = j.optString("start", "")
        val startMs = if (s.isEmpty() || s == "null") 0L else try {
            val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
            f.isLenient = false
            f.parse(s.take(16))!!.time
        } catch (e: Exception) { 0L }
        val dur = j.optInt("duration_min", 60).coerceIn(5, 24 * 60)
        return Parsed(title, startMs, dur)
    }

    /** Frase curta para o Cacau falar. */
    fun confirm(p: Parsed, now: Long): String {
        val a = Calendar.getInstance(); a.timeInMillis = now
        val b = Calendar.getInstance(); b.timeInMillis = p.startMs
        val days = (b.get(Calendar.YEAR) * 366 + b.get(Calendar.DAY_OF_YEAR)) - (a.get(Calendar.YEAR) * 366 + a.get(Calendar.DAY_OF_YEAR))
        val day = when (days) {
            0 -> "hoje"
            1 -> "amanhã"
            else -> SimpleDateFormat("EEEE, d 'de' MMMM", BR).format(Date(p.startMs))
        }
        val hour = SimpleDateFormat("HH:mm", BR).format(Date(p.startMs))
        return "Pronto, marquei \"" + p.title + "\" " + day + " às " + hour + " na sua agenda."
    }
}
