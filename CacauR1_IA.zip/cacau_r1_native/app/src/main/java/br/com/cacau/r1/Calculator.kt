package br.com.cacau.r1

/** Small recursive-descent calculator: + - * /, parentheses and decimal numbers. No eval(). */
object Calculator {
    fun evaluate(input: String): Double {
        val parser = Parser(input.replace(',', '.'))
        val value = parser.expression()
        parser.skipSpaces()
        require(parser.atEnd()) { "Expressão inválida" }
        require(value.isFinite()) { "Resultado inválido" }
        return value
    }

    private class Parser(private val s: String) {
        private var p = 0
        fun atEnd() = p >= s.length
        fun skipSpaces() { while (!atEnd() && s[p].isWhitespace()) p++ }
        private fun eat(c: Char): Boolean { skipSpaces(); if (!atEnd() && s[p] == c) { p++; return true }; return false }
        fun expression(): Double {
            var v = term()
            while (true) v = when { eat('+') -> v + term(); eat('-') -> v - term(); else -> return v }
        }
        private fun term(): Double {
            var v = factor()
            while (true) {
                if (eat('*')) v *= factor()
                else if (eat('/')) { val d = factor(); require(d != 0.0) { "Divisão por zero" }; v /= d }
                else return v
            }
        }
        private fun factor(): Double {
            if (eat('+')) return factor()
            if (eat('-')) return -factor()
            if (eat('(')) { val v = expression(); require(eat(')')) { "Falta fechar parênteses" }; return v }
            skipSpaces(); val start = p; var dots = 0
            while (!atEnd() && (s[p].isDigit() || s[p] == '.')) { if (s[p] == '.') dots++; p++ }
            require(p > start && dots <= 1) { "Número inválido" }
            return s.substring(start, p).toDouble()
        }
    }
}
