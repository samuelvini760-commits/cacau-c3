package br.com.cacau.r1

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF0D0E10)
private val Panel = Color(0xFF17181A)
private val Orange = Color(0xFFFF5A1F)
private val Paper = Color(0xFFF2F2F0)
private val Muted = Color(0xFF9A9DA3)
private val Lilac = Color(0xFFA79AC7)
private val Lime = Color(0xFFD6F545)
private val Yellow = Color(0xFFF7E936)

private data class AppItem(val id: String, val name: String, val icon: String, val color: Color, val desc: String)
private val apps = listOf(
    AppItem("talk", "Conversa", "◉", Lilac, "Fale ou escreva para o Cacau"),
    AppItem("vision", "Vision", "◎", Lime, "Abra a câmera do aparelho"),
    AppItem("magic", "Magic Câmera", "✦", Orange, "Filtros criativos serão adicionados"),
    AppItem("music", "Música", "♪", Color(0xFF1FA83A), "Gerador de tons local"),
    AppItem("timer", "Timer", "◷", Yellow, "Temporizador com contagem regressiva"),
    AppItem("notes", "Notas", "▤", Color(0xFFD7E0D3), "Notas salvas neste aparelho"),
    AppItem("translate", "Tradutor", "⇄", Color(0xFF5B7BE8), "Frases úteis offline"),
    AppItem("weather", "Clima", "☼", Color(0xFF8F8A12), "Integração meteorológica pendente"),
    AppItem("calc", "Calculadora", "±", Color(0xFFD7E0D3), "Operações e parênteses"),
    AppItem("teach", "Ensinar", "✎", Orange, "Rotinas personalizadas"),
    AppItem("hole", "Cacau Hole", "◍", Lilac, "Histórico local da conversa"),
    AppItem("agenda", "Agenda", "▦", Yellow, "Agenda local básica"),
    AppItem("clock", "Relógio", "◔", Paper, "Hora e data"),
    AppItem("sleep", "Sono", "☾", Orange, "Modo descanso visual"),
    AppItem("compass", "Bússola", "✛", Lime, "Requer sensor compatível"),
    AppItem("synth", "Sintetizador", "∿", Color(0xFFE3252B), "Sons simples gerados no aparelho"),
    AppItem("hoje", "Resumo do dia", "☀", Yellow, "Resumo das funções locais"),
    AppItem("spotify", "Spotify", "♫", Color(0xFF1FA83A), "Abrir Spotify se instalado"),
    AppItem("mail", "Gmail", "✉", Color(0xFF5B7BE8), "Abrir Gmail se instalado"),
    AppItem("conn", "Conexões", "⇆", Color(0xFF8F8A12), "Estado das integrações"),
    AppItem("pet", "Cuidar", "♥", Color(0xFFE3252B), "Cuide da calopsita virtual"),
    AppItem("games", "Jogos", "▶", Lime, "Minijogo simples"),
    AppItem("emotes", "Emoções", "☺", Lilac, "Estados do avatar Cacau"),
    AppItem("set", "Ajustes", "⚙", Color(0xFFA6A6A1), "Preferências locais")
)
private val emotions = listOf("feliz", "curioso", "sonolento", "animado", "tímido", "pensando", "surpreso", "carinhoso", "confuso", "orgulhoso", "tranquilo", "brincalhão", "com fome", "com sono", "atento", "apaixonado", "triste", "assustado", "concentrado", "dançando", "cantando", "ouvindo", "esperando", "celebrando", "irritado", "envergonhado", "relaxado", "esperto", "com saudade", "explorando", "grato", "corajoso", "misterioso", "dormindo")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CacauApp() }
    }
}

@Composable
private fun CacauApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("cacau_r1", Activity.MODE_PRIVATE) }
    var current by remember { mutableStateOf("home") }
    var emotion by remember { mutableStateOf("curioso") }
    var noteText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf(prefs.getString("notes", "") ?: "") }
    var chatInput by remember { mutableStateOf("") }
    var aiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var aiModel by remember { mutableStateOf(prefs.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash") }
    var aiBusy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var chatLog by remember { mutableStateOf(listOf("Cacau: Oi! Sou o Cacau. Posso ajudar com comandos locais.")) }
    var expression by remember { mutableStateOf("") }
    var calcResult by remember { mutableStateOf("") }
    var timerInput by remember { mutableStateOf("60") }
    var remaining by remember { mutableIntStateOf(0) }
    var timerRunning by remember { mutableStateOf(false) }
    var chosenColor by remember { mutableStateOf(Color(prefs.getInt("accent", Orange.toArgb()))) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var invert by remember { mutableStateOf(false) }
    var petLevel by remember { mutableIntStateOf(prefs.getInt("pet_level", 1)) }
    var agendaText by remember { mutableStateOf(prefs.getString("agenda", "") ?: "") }
    var routineText by remember { mutableStateOf(prefs.getString("routine", "") ?: "") }
    var weatherCity by remember { mutableStateOf("São Luís") }
    var spotifyQuery by remember { mutableStateOf("") }
    var mailTo by remember { mutableStateOf("") }
    var mailSubject by remember { mutableStateOf("") }
    var calendarTitle by remember { mutableStateOf("") }
    var calendarDetails by remember { mutableStateOf("") }
    var translatorInput by remember { mutableStateOf("") }
    var translatorOutput by remember { mutableStateOf("") }
    var gameScore by remember { mutableIntStateOf(0) }
    var musicOn by remember { mutableStateOf(false) }
    val tts = remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) tts.value?.language = Locale("pt", "BR") }
        tts.value = engine
        onDispose { engine.stop(); engine.shutdown(); tts.value = null }
    }
    LaunchedEffect(timerRunning, remaining) {
        if (timerRunning && remaining > 0) { delay(1000); remaining -= 1 }
        if (timerRunning && remaining == 0) {
            timerRunning = false
            Toast.makeText(context, "Tempo encerrado!", Toast.LENGTH_LONG).show()
            tts.value?.speak("Tempo encerrado", TextToSpeech.QUEUE_FLUSH, null, "timer_done")
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) { chatInput = spoken }
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) Toast.makeText(context, "Imagem selecionada. Análise visual por IA ainda não está conectada.", Toast.LENGTH_LONG).show()
    }

    val bg = if (darkMode) Ink else Color(0xFFECEEF0)
    val fg = if (darkMode) Paper else Color(0xFF14161A)
    MaterialTheme(colorScheme = darkColorScheme(primary = chosenColor, background = bg, surface = Panel, onSurface = fg)) {
        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Orange), contentAlignment = Alignment.Center) {
                        Text("c.", color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("CACAU R1", color = fg, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp)
                        Text("companheiro de bolso · build nativo", color = Muted, fontSize = 11.sp)
                    }
                    Text(SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date()), color = fg, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(16.dp))
                if (current == "home") {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Olá, eu sou o Cacau", color = fg, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Um pequeno amigo, muitas possibilidades.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("ESTADO ATUAL", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Text(emotion.replaceFirstChar { it.uppercase() }, color = fg, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                        BirdAvatar(Modifier.size(116.dp), emotion, Orange)
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Seus aplicativos", color = fg, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        Text("24 MÓDULOS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(apps) { item -> AppTile(item, fg) { current = item.id; if (item.id == "vision") emotion = "curioso" } }
                    }
                    Text("Offline: notas, calculadora, timer e comandos básicos · Conexões externas exigem configuração.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("‹", color = fg, fontSize = 30.sp, modifier = Modifier.clickable { current = "home" }.padding(end = 12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(apps.firstOrNull { it.id == current }?.name ?: "Cacau", color = fg, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Text(apps.firstOrNull { it.id == current }?.desc ?: "", color = Muted, fontSize = 12.sp)
                        }
                        BirdAvatar(Modifier.size(48.dp), emotion, chosenColor)
                    }
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        when (current) {
                            "talk" -> {
                                chatLog.forEach { line -> Surface(color = if (line.startsWith("Você:")) chosenColor else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(line, color = if (line.startsWith("Você:")) Ink else fg, modifier = Modifier.padding(12.dp)) } }
                                Spacer(Modifier.height(12.dp))
                                Field(chatInput, { chatInput = it }, "Escreva para o Cacau…")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ActionButton(if (aiBusy) "Pensando…" else "Enviar", chosenColor, Modifier.weight(1f)) {
                                        if (chatInput.isNotBlank() && !aiBusy) {
                                            val input = chatInput.trim()
                                            chatLog = (chatLog + "Você: $input").takeLast(40)
                                            chatInput = ""
                                            emotion = "pensando"
                                            if (aiKey.isNotBlank()) {
                                                aiBusy = true
                                                scope.launch {
                                                    val reply = withContext(Dispatchers.IO) { askGemini(input, aiKey, aiModel, chatLog.takeLast(12)) }
                                                    val safeReply = reply ?: "Não consegui falar com a IA. Confira a chave, o modelo e a conexão com a internet. Você ainda pode usar os comandos locais."
                                                    chatLog = (chatLog + "Cacau: $safeReply").takeLast(40)
                                                    emotion = if (reply != null) "curioso" else "confuso"
                                                    tts.value?.speak(safeReply, TextToSpeech.QUEUE_FLUSH, null, "cacau_reply")
                                                    aiBusy = false
                                                }
                                            } else {
                                                val reply = localReply(input)
                                                chatLog = (chatLog + "Cacau: $reply").takeLast(40)
                                                emotion = "curioso"
                                                tts.value?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "cacau_reply")
                                            }
                                        }
                                    }
                                    ActionButton("🎙 Falar", Lilac, Modifier.weight(1f)) {
                                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR"); putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o Cacau") }
                                        runCatching { speechLauncher.launch(intent) }.onFailure { Toast.makeText(context, "Reconhecimento de voz indisponível neste aparelho", Toast.LENGTH_LONG).show() }
                                    }
                                }
                                Text(if (aiKey.isBlank()) "Modo local ativo. Para respostas generativas, configure a chave da API Gemini em Ajustes." else "IA Gemini configurada · respostas usam internet e podem consumir cota da API.", color = Muted, fontSize = 11.sp)
                                ActionButton("Configurar IA", chosenColor, Modifier.fillMaxWidth()) { current = "set" }
                            }
                            "calc" -> {
                                Text("CALCULADORA", color = chosenColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.End) { Text(expression.ifBlank { "0" }, color = fg, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text(calcResult, color = chosenColor, fontSize = 22.sp) } }
                                Spacer(Modifier.height(12.dp))
                                val keys = listOf("7","8","9","÷","4","5","6","×","1","2","3","−","C","0",".","+","(",")","⌫","=")
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { keys.chunked(4).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { key -> ActionButton(key, if (key in listOf("÷","×","−","+","=","C")) chosenColor else Panel, Modifier.weight(1f)) {
                                    when (key) { "C" -> { expression = ""; calcResult = "" }; "⌫" -> expression = expression.dropLast(1); "=" -> runCatching { Calculator.evaluate(expression.replace("×", "*").replace("÷", "/").replace("−", "-")).toString().removeSuffix(".0") }.onSuccess { calcResult = it }.onFailure { calcResult = it.message ?: "Erro" }; else -> expression += when (key) { "×" -> "*"; "÷" -> "/"; "−" -> "-"; else -> key }
                                    }
                                } } } } }
                            }
                            "notes" -> {
                                Text("ANOTAÇÕES LOCAIS", color = chosenColor, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Field(noteText, { noteText = it }, "Digite uma nota nova…", singleLine = false)
                                ActionButton("Salvar nota", chosenColor, Modifier.fillMaxWidth()) { if (noteText.isNotBlank()) { notes = (notes + if (notes.isBlank()) "" else "\n\n" + "• ${noteText.trim()}"); prefs.edit().putString("notes", notes).apply(); noteText = "" } }
                                Spacer(Modifier.height(12.dp)); Text(notes.ifBlank { "Suas notas aparecerão aqui e ficarão salvas neste aparelho." }, color = fg)
                                ActionButton("Apagar todas as notas", Panel, Modifier.fillMaxWidth()) { notes = ""; prefs.edit().remove("notes").apply() }
                            }
                            "timer" -> {
                                Text("TEMPORIZADOR", color = chosenColor, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Text(String.format(Locale.getDefault(), "%02d:%02d", remaining / 60, remaining % 60), color = fg, fontSize = 56.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Field(timerInput, { timerInput = it.filter(Char::isDigit).take(5) }, "Segundos")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ActionButton(if (timerRunning) "Pausar" else "Iniciar", chosenColor, Modifier.weight(1f)) { if (timerRunning) timerRunning = false else { if (remaining <= 0) remaining = timerInput.toIntOrNull()?.coerceIn(1, 86400) ?: 60; timerRunning = true } }
                                    ActionButton("Reiniciar", Panel, Modifier.weight(1f)) { timerRunning = false; remaining = timerInput.toIntOrNull()?.coerceIn(0, 86400) ?: 60 }
                                }
                            }
                            "emotes" -> {
                                Text("34 ESTADOS DO CACAU", color = chosenColor, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.heightIn(max = 650.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(emotions) { e -> Surface(color = if (emotion == e) chosenColor else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.clickable { emotion = e }.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { BirdAvatar(Modifier.size(38.dp), e, if (emotion == e) Ink else chosenColor); Spacer(Modifier.width(8.dp)); Text(e.replaceFirstChar { it.uppercase() }, color = if (emotion == e) Ink else fg, fontWeight = FontWeight.Bold) } } } }
                            }
                            "vision" -> {
                                Text("VISÃO DO CACAU", color = chosenColor, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { BirdAvatar(Modifier.size(130.dp), "curioso", chosenColor); Text("Escolha como abrir a imagem", color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("A análise inteligente da imagem ainda não foi conectada.", color = Muted, fontSize = 12.sp) } }
                                ActionButton("Abrir câmera", chosenColor, Modifier.fillMaxWidth()) { runCatching { cameraLauncher.launch(Intent("android.media.action.IMAGE_CAPTURE")) }.onFailure { Toast.makeText(context, "Câmera não disponível", Toast.LENGTH_SHORT).show() } }
                                ActionButton("Escolher imagem", Panel, Modifier.fillMaxWidth()) { photoPicker.launch("image/*") }
                            }
                            "magic" -> InfoCard("MAGIC CÂMERA", "A estrutura nativa está preparada. Os filtros pixel, 1-bit, duotone e bordas precisam ser portados do protótipo para processamento real de imagens.", chosenColor, fg)
                            "music", "synth" -> {
                                InfoCard("CACAU SYNTH", "Geração de som simples no aparelho. Isso não é Spotify nem reprodução de faixas protegidas.", chosenColor, fg)
                                ActionButton(if (musicOn) "Parar demonstração" else "Tocar tom de demonstração", chosenColor, Modifier.fillMaxWidth()) { musicOn = !musicOn; if (musicOn) { tts.value?.speak("Som de demonstração do Cacau", TextToSpeech.QUEUE_FLUSH, null, "synth"); emotion = "cantando" } else tts.value?.stop() }
                            }
                            "translate" -> {
                                Text("TRADUTOR OFFLINE · FRASES", color = chosenColor, fontWeight = FontWeight.Bold)
                                Field(translatorInput, { translatorInput = it }, "Digite: olá, obrigado, bom dia…")
                                ActionButton("Traduzir frase", chosenColor, Modifier.fillMaxWidth()) { translatorOutput = translatePhrase(translatorInput) }
                                Text(translatorOutput, color = fg, fontSize = 18.sp, modifier = Modifier.padding(12.dp))
                                Text("Dicionário inicial pequeno; não substitui um tradutor completo.", color = Muted, fontSize = 11.sp)
                            }
                            "agenda" -> {
                                Text("AGENDA LOCAL", color = chosenColor, fontWeight = FontWeight.Bold)
                                Field(agendaText, { agendaText = it }, "Adicione compromissos ou lembretes…", false)
                                ActionButton("Salvar agenda local", chosenColor, Modifier.fillMaxWidth()) { prefs.edit().putString("agenda", agendaText).apply(); Toast.makeText(context, "Agenda salva", Toast.LENGTH_SHORT).show() }
                                Divider(color = Muted.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 8.dp))
                                Text("CRIAR EVENTO NO GOOGLE AGENDA", color = chosenColor, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Field(calendarTitle, { calendarTitle = it }, "Título do evento")
                                Field(calendarDetails, { calendarDetails = it }, "Detalhes do evento", singleLine = false)
                                ActionButton("Criar evento no calendário", chosenColor, Modifier.fillMaxWidth()) {
                                    runCatching {
                                        val intent = Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI)
                                            .putExtra(android.provider.CalendarContract.Events.TITLE, calendarTitle.ifBlank { "Evento do Cacau R1" })
                                            .putExtra(android.provider.CalendarContract.Events.DESCRIPTION, calendarDetails)
                                        context.startActivity(intent)
                                    }.onFailure { Toast.makeText(context, "Nenhum app de agenda disponível", Toast.LENGTH_SHORT).show() }
                                }
                                ActionButton("Abrir Google Agenda", chosenColor, Modifier.fillMaxWidth()) { openPackageOrWeb(context, "com.google.android.calendar", "https://calendar.google.com") }
                                Text("O evento é aberto no app de calendário para você revisar e salvar. Sincronização/leitura automática ainda exige OAuth.", color = Muted, fontSize = 11.sp)
                            }
                            "teach" -> {
                                Text("ENSINAR UMA ROTINA", color = chosenColor, fontWeight = FontWeight.Bold)
                                Field(routineText, { routineText = it }, "Uma ação por linha…", false)
                                ActionButton("Salvar rotina", chosenColor, Modifier.fillMaxWidth()) { prefs.edit().putString("routine", routineText).apply(); Toast.makeText(context, "Rotina salva localmente", Toast.LENGTH_SHORT).show() }
                                Text("As rotinas são guardadas; execução automática de ações ainda não está habilitada.", color = Muted, fontSize = 11.sp)
                            }
                            "hole" -> { Text("CACAU HOLE", color = chosenColor, fontWeight = FontWeight.Bold); Text(chatLog.joinToString("\n\n"), color = fg) }
                            "clock", "hoje" -> { Text(SimpleDateFormat("HH:mm:ss", Locale("pt", "BR")).format(Date()), color = fg, fontSize = 48.sp, fontWeight = FontWeight.Black); Text(SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("pt", "BR")).format(Date()).replaceFirstChar { it.uppercase() }, color = Muted); InfoCard("RESUMO", "Notas: ${if (notes.isBlank()) "nenhuma" else "salvas"}\nRotina: ${if (routineText.isBlank()) "nenhuma" else "configurada"}\nNível do Cacau: $petLevel", chosenColor, fg) }
                            "weather" -> { Text("CLIMA", color = chosenColor, fontWeight = FontWeight.Bold); Field(weatherCity, { weatherCity = it }, "Cidade"); InfoCard("DADOS AO VIVO AINDA NÃO LIGADOS", "O protótipo anterior usava dados de exemplo. Esta versão não inventa temperatura: a integração com um serviço meteorológico será feita numa etapa própria.", chosenColor, fg) }
                            "pet" -> { BirdAvatar(Modifier.fillMaxWidth().height(150.dp), emotion, chosenColor); Text("Nível de amizade: $petLevel", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold); listOf("Dar carinho", "Brincar", "Dar colo", "Cochilar").forEach { action -> ActionButton(action, chosenColor, Modifier.fillMaxWidth()) { petLevel = (petLevel + 1).coerceAtMost(100); prefs.edit().putInt("pet_level", petLevel).apply(); emotion = when(action) { "Brincar" -> "brincalhão"; "Cochilar" -> "sonolento"; else -> "carinhoso" } } } }
                            "set" -> {
                                Text("PERSONALIZAÇÃO", color = chosenColor, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { listOf(Orange, Lilac, Lime, Yellow, Color(0xFF5B7BE8)).forEach { color -> Box(Modifier.size(44.dp).clip(CircleShape).background(color).clickable { chosenColor = color; prefs.edit().putInt("accent", color.toArgb()).apply() }) } }
                                Spacer(Modifier.height(16.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text("Tema escuro", color = fg, modifier = Modifier.weight(1f)); Switch(darkMode, { darkMode = it; prefs.edit().putBoolean("dark", it).apply() }) }
                                Row(verticalAlignment = Alignment.CenterVertically) { Text("Inverter tela (visualização)", color = fg, modifier = Modifier.weight(1f)); Switch(invert, { invert = it }) }
                                Spacer(Modifier.height(18.dp))
                                Text("INTELIGÊNCIA ARTIFICIAL", color = chosenColor, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text("Gemini API (Google). Crie uma chave em aistudio.google.com/apikey. A chave fica salva apenas neste aparelho; não a compartilhe.", color = Muted, fontSize = 12.sp)
                                Field(aiKey, { aiKey = it; prefs.edit().putString("gemini_key", it.trim()).apply() }, "Cole sua chave da API Gemini")
                                Field(aiModel, { aiModel = it; prefs.edit().putString("gemini_model", it.trim()).apply() }, "Modelo Gemini (ex.: gemini-2.5-flash)")
                                ActionButton("Testar conexão com a IA", chosenColor, Modifier.fillMaxWidth()) {
                                    if (aiKey.isBlank()) Toast.makeText(context, "Cole primeiro sua chave Gemini", Toast.LENGTH_LONG).show()
                                    else {
                                        aiBusy = true
                                        scope.launch {
                                            val result = withContext(Dispatchers.IO) { askGemini("Responda apenas: Cacau conectado.", aiKey, aiModel, emptyList()) }
                                            aiBusy = false
                                            Toast.makeText(context, result ?: "Falha. Verifique a chave, o modelo e a internet.", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                                Text("Sem chave, o Cacau continua com comandos locais. A IA generativa requer internet e uma chave válida; tarifas e limites dependem da sua conta Google.", color = Muted, fontSize = 11.sp)
                                Spacer(Modifier.height(10.dp))
                                Text("A cor e o tema são salvos. Controles de Wi-Fi, Bluetooth e modo avião do Android não são alterados por este botão.", color = Muted, fontSize = 11.sp)
                            }
                            "conn" -> {
                                Text("SERVIÇOS DO CACAU", color = chosenColor, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                InfoCard("INTEGRAÇÕES DISPONÍVEIS", "Estas ações abrem os serviços oficiais instalados ou seus sites. Acesso direto a dados privados por API (OAuth) exige credenciais de desenvolvedor e consentimento da sua conta.", chosenColor, fg)
                                ActionButton("Abrir Google Agenda", Color(0xFF4285F4), Modifier.fillMaxWidth()) { openPackageOrWeb(context, "com.google.android.calendar", "https://calendar.google.com") }
                                ActionButton("Abrir Google Drive", Color(0xFF34A853), Modifier.fillMaxWidth()) { openPackageOrWeb(context, "com.google.android.apps.docs", "https://drive.google.com") }
                                ActionButton("Abrir YouTube", Color(0xFFFF0033), Modifier.fillMaxWidth()) { openPackageOrWeb(context, "com.google.android.youtube", "https://youtube.com") }
                                ActionButton("Abrir Google Maps", Color(0xFF4285F4), Modifier.fillMaxWidth()) { openPackageOrWeb(context, "com.google.android.apps.maps", "https://maps.google.com") }
                                ActionButton("Abrir pesquisa Google", chosenColor, Modifier.fillMaxWidth()) { openUrl(context, "https://www.google.com/search?q=Cacau+R1") }
                            }
                            "spotify" -> {
                                Text("SPOTIFY", color = Color(0xFF1FA83A), fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Field(spotifyQuery, { spotifyQuery = it }, "Buscar música, artista ou álbum")
                                ActionButton("Buscar no Spotify", Color(0xFF1FA83A), Modifier.fillMaxWidth()) {
                                    val raw = spotifyQuery.trim()
                                    if (raw.isBlank()) {
                                        openPackageOrWeb(context, "com.spotify.music", "https://open.spotify.com")
                                    } else {
                                        val q = android.net.Uri.encode(raw)
                                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("spotify:search:$q"))) }
                                            .onFailure { openUrl(context, "https://open.spotify.com/search/$q") }
                                    }
                                }
                                ActionButton("Abrir aplicativo Spotify", Color(0xFF1FA83A), Modifier.fillMaxWidth()) { openPackageOrWeb(context, "com.spotify.music", "https://open.spotify.com") }
                                Text("A busca abre o Spotify/site oficial. Controle de reprodução e leitura de faixa via API exigem um app Spotify for Developers e OAuth; não são simulados aqui.", color = Muted, fontSize = 11.sp)
                            }
                            "mail" -> {
                                Text("GMAIL", color = Color(0xFF5B7BE8), fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Field(mailTo, { mailTo = it }, "Destinatário (opcional)")
                                Field(mailSubject, { mailSubject = it }, "Assunto")
                                ActionButton("Escrever e-mail no Gmail", Color(0xFF5B7BE8), Modifier.fillMaxWidth()) {
                                    val uri = android.net.Uri.parse("mailto:").buildUpon().appendQueryParameter("to", mailTo).appendQueryParameter("subject", mailSubject).build()
                                    runCatching { context.startActivity(Intent(Intent.ACTION_SENDTO, uri)) }.onFailure { openUrl(context, "https://mail.google.com") }
                                }
                                ActionButton("Abrir caixa de entrada", Color(0xFF5B7BE8), Modifier.fillMaxWidth()) { openPackageOrWeb(context, "com.google.android.gm", "https://mail.google.com") }
                                Text("O envio final é feito no Gmail após você revisar e confirmar. Leitura de mensagens pela API exige OAuth e autorização explícita.", color = Muted, fontSize = 11.sp)
                            }
                            "sleep" -> { InfoCard("MODO DESCANSO", "A interface permanece leve. Ative o tema escuro nas configurações e escolha uma emoção tranquila.", chosenColor, fg); ActionButton("Deixar Cacau sonolento", chosenColor, Modifier.fillMaxWidth()) { emotion = "sonolento" } }
                            "compass" -> InfoCard("BÚSSOLA", "A leitura real depende de magnetômetro no aparelho. A integração com sensor será adicionada depois de validar o hardware.", chosenColor, fg)
                            "games" -> { Text("JOGO: TOQUE PARA GANHAR PONTOS", color = chosenColor, fontWeight = FontWeight.Bold); Text("$gameScore pontos", color = fg, fontSize = 36.sp, fontWeight = FontWeight.Black); ActionButton("Brincar com Cacau +1", chosenColor, Modifier.fillMaxWidth()) { gameScore++; emotion = "brincalhão" } }
                            else -> InfoCard(apps.firstOrNull { it.id == current }?.name ?: "CACAU", "Este módulo está no mapa do aplicativo, mas ainda precisa de implementação funcional própria. Não está marcado como concluído.", chosenColor, fg)
                        }
                        Spacer(Modifier.height(28.dp))
                    }
                }
            }
        }
    }
}

@Composable private fun AppTile(item: AppItem, fg: Color, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().aspectRatio(0.91f).clickable(onClick = onClick)) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(item.color), contentAlignment = Alignment.Center) { Text(item.icon, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Black) }
            Column {
                Text(item.name, color = fg, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp)
                Text("ABRIR ↗", color = item.color, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable private fun BirdAvatar(modifier: Modifier = Modifier, emotion: String, color: Color) {
    val transition = rememberInfiniteTransition(label = "bird")
    val bob by transition.animateFloat(initialValue = 0f, targetValue = 5f, animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "bob")
    Canvas(modifier = modifier.graphicsLayer { translationY = bob }.padding(2.dp)) {
        val w = size.width; val h = size.height
        val body = Path().apply { moveTo(w*.20f,h*.70f); cubicTo(w*.08f,h*.36f,w*.27f,h*.15f,w*.52f,h*.22f); cubicTo(w*.77f,h*.18f,w*.91f,h*.42f,w*.80f,h*.70f); cubicTo(w*.67f,h*.91f,w*.35f,h*.91f,w*.20f,h*.70f); close() }
        drawPath(body, color = color, style = Stroke(width = w*.045f, cap = StrokeCap.Round))
        val sleepy = emotion.contains("sono") || emotion == "dormindo" || emotion == "relaxado"
        val happy = emotion.contains("feliz") || emotion.contains("brinc") || emotion.contains("carinhos") || emotion.contains("celebr")
        if (sleepy) {
            drawLine(Ink, androidx.compose.ui.geometry.Offset(w*.34f,h*.43f), androidx.compose.ui.geometry.Offset(w*.46f,h*.43f), strokeWidth = w*.025f, cap = StrokeCap.Round)
            drawLine(Ink, androidx.compose.ui.geometry.Offset(w*.57f,h*.43f), androidx.compose.ui.geometry.Offset(w*.69f,h*.43f), strokeWidth = w*.025f, cap = StrokeCap.Round)
        } else {
            drawCircle(color, radius = w*.09f, center = androidx.compose.ui.geometry.Offset(w*.40f,h*.42f))
            drawCircle(color, radius = w*.09f, center = androidx.compose.ui.geometry.Offset(w*.62f,h*.42f))
            drawCircle(Ink, radius = w*.025f, center = androidx.compose.ui.geometry.Offset(w*.41f,h*.42f))
            drawCircle(Ink, radius = w*.025f, center = androidx.compose.ui.geometry.Offset(w*.63f,h*.42f))
        }
        val beak = Path().apply {
            if (happy) { moveTo(w*.48f,h*.50f); quadraticTo(w*.56f,h*.58f,w*.49f,h*.60f); close() }
            else { moveTo(w*.48f,h*.50f); lineTo(w*.57f,h*.55f); lineTo(w*.49f,h*.59f); close() }
        }
        drawPath(beak, color = color)
        val crest = Path().apply { moveTo(w*.46f,h*.24f); quadraticTo(w*.36f,h*.04f,w*.49f,h*.13f); quadraticTo(w*.57f,h*.02f,w*.58f,h*.22f) }
        drawPath(crest, color = color, style = Stroke(width = w*.04f, cap = StrokeCap.Round))
        drawLine(color, androidx.compose.ui.geometry.Offset(w*.33f,h*.79f), androidx.compose.ui.geometry.Offset(w*.28f,h*.90f), strokeWidth = w*.035f, cap = StrokeCap.Round)
        drawLine(color, androidx.compose.ui.geometry.Offset(w*.64f,h*.79f), androidx.compose.ui.geometry.Offset(w*.69f,h*.90f), strokeWidth = w*.035f, cap = StrokeCap.Round)
    }
}

@Composable private fun Field(value: String, onChange: (String) -> Unit, placeholder: String, singleLine: Boolean = true) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        BasicTextField(value = value, onValueChange = onChange, singleLine = singleLine, textStyle = androidx.compose.ui.text.TextStyle(color = Paper, fontSize = 16.sp), modifier = Modifier.fillMaxWidth().padding(15.dp), decorationBox = { inner -> Box { if (value.isEmpty()) Text(placeholder, color = Muted, fontSize = 14.sp); inner() } })
    }
}
@Composable private fun ActionButton(label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(color = color, shape = RoundedCornerShape(16.dp), modifier = modifier.padding(vertical = 4.dp).clickable(onClick = onClick)) { Box(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), contentAlignment = Alignment.Center) { Text(label, color = if (color == Panel) Paper else Ink, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp) } }
}
@Composable private fun InfoCard(title: String, body: String, color: Color, fg: Color) {
    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(18.dp)) { Text(title, color = color, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp); Spacer(Modifier.height(8.dp)); Text(body, color = fg, fontSize = 15.sp, lineHeight = 22.sp) } }
}
private fun askGemini(prompt: String, apiKey: String, model: String, history: List<String>): String? {
    var connection: HttpURLConnection? = null
    return try {
        val cleanModel = model.trim().ifBlank { "gemini-2.5-flash" }
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:generateContent?key=${java.net.URLEncoder.encode(apiKey.trim(), "UTF-8")}")
        connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val contextText = history.takeLast(10).joinToString("\n")
        val fullPrompt = "Você é Cacau, uma calopsita digital amigável. Responda em português brasileiro, com clareza e honestidade. Não diga que executou ações externas se não executou. Histórico recente:\n$contextText\nUsuário: $prompt"
        val body = JSONObject().put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", fullPrompt)))))
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            val message = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
            "Erro da API Gemini ($code): ${message ?: "resposta inválida"}"
        } else {
            val json = JSONObject(response)
            json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?.let { parts -> (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text") }.joinToString("\n").trim() }
                ?.takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) { null } finally { connection?.disconnect() }
}

private fun localReply(text: String): String {
    val s = text.lowercase(Locale("pt", "BR"))
    return when {
        listOf("oi", "olá", "ola", "bom dia", "boa noite").any(s::contains) -> "Oi! Que bom ter você por aqui. Como posso ajudar?"
        s.contains("hora") -> "Agora são ${SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())}."
        s.startsWith("anota ") -> "Posso guardar isso em Notas. Abra o aplicativo Notas para salvar o texto."
        s.contains("calcul") -> "Abra a Calculadora no menu. Ela aceita +, -, ×, ÷ e parênteses."
        s.contains("obrigad") -> "Sempre que precisar, estou aqui!"
        s.contains("quem é você") || s.contains("quem e voce") -> "Sou o Cacau R1, uma calopsita digital em construção."
        s.contains("ajuda") -> "Posso abrir notas, timer, calculadora, emoções e comandos simples offline."
        else -> "Ainda estou aprendendo. Por enquanto respondo a comandos básicos sem internet; a IA generativa online/offline será integrada em outra etapa."
    }
}
private fun translatePhrase(text: String): String {
    val dict = mapOf("olá" to "Hello", "ola" to "Hello", "obrigado" to "Thank you", "obrigada" to "Thank you", "bom dia" to "Good morning", "boa noite" to "Good evening", "por favor" to "Please", "como você está?" to "How are you?", "desculpa" to "Sorry", "até logo" to "See you later")
    return dict[text.trim().lowercase(Locale("pt", "BR"))]?.let { "Inglês: $it" } ?: "Ainda não tenho essa frase no dicionário offline."
}
private fun openUrl(context: android.content.Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
        .onFailure { Toast.makeText(context, "Não foi possível abrir o link", Toast.LENGTH_SHORT).show() }
}
private fun openPackageOrWeb(context: android.content.Context, packageName: String, url: String) {
    val launch = context.packageManager.getLaunchIntentForPackage(packageName)
    runCatching { context.startActivity(launch ?: Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
        .onFailure { Toast.makeText(context, "Não foi possível abrir o serviço", Toast.LENGTH_SHORT).show() }
}
