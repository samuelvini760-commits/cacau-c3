package br.com.cacau.r1

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CalculatorTest {
    @Test fun precedenceAndParentheses() {
        assertEquals(14.0, Calculator.evaluate("2 + 3 * 4"), 0.00001)
        assertEquals(20.0, Calculator.evaluate("(2 + 3) * 4"), 0.00001)
        assertEquals(-2.5, Calculator.evaluate("-5 / 2"), 0.00001)
    }
    @Test fun divisionByZeroIsRejected() {
        assertThrows(IllegalArgumentException::class.java) { Calculator.evaluate("8/0") }
    }
}
