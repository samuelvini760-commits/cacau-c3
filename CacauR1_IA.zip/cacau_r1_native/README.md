# Cacau R1 — projeto nativo Android + companheiro Raspberry Pi

**Versão de trabalho:** 0.1.0 · **Data:** 29/10/2026  
**Base visual:** `cacau-os-android-r3.html` enviado pelo usuário. O HTML foi usado como referência de identidade, inventário e fluxo; ele não é incluído nem usado como interface do aplicativo final.

## Objetivo e limites desta entrega

Este repositório inicia a migração para **Kotlin + Jetpack Compose nativo**, com cartões coloridos por aplicativo, fundo escuro, laranja Cacau, avatar vetorial animado e navegação por toque. Também inclui um companheiro Python leve para Raspberry Pi OS, pois o Raspberry Pi 4B normalmente roda Linux e não instala um APK Android diretamente.

Isto é um **primeiro corte funcional**, não uma alegação de que todos os 24 módulos estão concluídos. A tela inicial e os módulos indicados abaixo já têm comportamento local. Outros módulos aparecem no mapa de aplicativos, mas são explicitamente marcados como pendentes ou informativos para não fingir que integrações existem.

### Implementado nesta versão

- Aplicativo Android nativo Compose, sem WebView e sem HTML como produto final.
- Menu com 24 módulos derivados do arquivo de referência.
- Avatar vetorial do Cacau com movimento suave e 34 estados selecionáveis.
- Conversa local baseada em regras, fala por Android Text-to-Speech e entrada de voz via intent do sistema quando disponível.
- Calculadora local com `+`, `-`, `*`, `/`, parênteses, decimais e rejeição de divisão por zero; sem `eval`.
- Notas persistidas em SharedPreferences.
- Timer com contagem regressiva e aviso falado.
- Preferência de tema e cores de destaque persistidas.
- Agenda e rotinas em texto salvas localmente (a execução automática de rotinas ainda não existe).
- Abertura da câmera / seletor de imagem via intents do Android.
- Tradutor offline mínimo de frases fixas; não é um tradutor geral.
- Spotify: busca por música/artista/álbum pela página oficial e abertura do aplicativo quando instalado.
- Gmail: formulário de destinatário/assunto que abre a tela oficial de composição para revisão e envio manual.
- Google Agenda: criação de evento por intent Android, para revisão e salvamento no calendário instalado.
- Atalhos para Google Drive, YouTube, Maps e Pesquisa Google.
- API Python de companheiro para Pi, sem dependências externas, com estado, notas e respostas locais por regras.

### Ainda pendente (não simular como pronto)

- IA generativa offline/online e sincronização de conversas entre Android e Pi.
- Integração de API com leitura de e-mails/eventos, controle de reprodução Spotify e OAuth completo. As telas atuais abrem fluxos oficiais do Android/serviços, mas não leem dados privados nem controlam playback por API. Para isso são necessários IDs de cliente e configuração de OAuth nos consoles Google Cloud e Spotify for Developers, além de testes com as contas do usuário.
- Clima em tempo real; a versão de referência explicita que havia dados de exemplo.
- Vision com análise de imagem por IA e os oito filtros reais da Magic Câmera.
- Sensor de bússola, controles privilegiados de Wi-Fi/Bluetooth/modo avião, notificações e execução segura de rotinas.
- Música completa, reprodução de arquivos locais e metadados/capas.
- Importação de todas as 34 animações SVG originais para vetores nativos detalhados. O avatar desta versão é um desenho Compose simples, não uma conversão pixel a pixel.
- Interface Linux de tela cheia para o Pi e cliente Android conectado à API do Pi.

## Estrutura

```text
CacauR1/
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  app/
    build.gradle.kts
    src/main/AndroidManifest.xml
    src/main/java/br/com/cacau/r1/MainActivity.kt
    src/main/java/br/com/cacau/r1/Calculator.kt
    src/test/java/br/com/cacau/r1/CalculatorTest.kt
  raspberry-pi/
    cacau_pi.py
    test_cacau_pi.py
  docs/TESTES.md
```

## Compilar o APK

Requisitos: Android Studio recente, JDK 17, Android SDK Platform 35 e internet na primeira resolução das dependências Gradle.

1. Extraia o ZIP.
2. Abra a pasta `cacau_r1_native` no Android Studio (**Open**, não abra o HTML).
3. Aguarde o Gradle Sync. Se o Android Studio pedir para instalar Android SDK Platform 35 e Build Tools, aceite.
4. Execute `app` em um telefone Android ou emulador.
5. Para gerar APK de depuração: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. O APK de debug normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.
6. Para uma distribuição própria, use **Build → Generate Signed Bundle / APK** e proteja a chave de assinatura.

O wrapper Gradle não foi incluído porque não havia instalação do Gradle nem distribuição de wrapper disponível neste ambiente de criação. O Android Studio consegue importar o projeto e gerar os arquivos do wrapper localmente. A compilação do APK **não foi executada aqui**: não havia Android SDK/Gradle configurado neste ambiente.


## Gerar APK usando somente o celular (GitHub Actions)

Este projeto inclui o fluxo `.github/workflows/android-apk.yml` para compilar na nuvem. Você não precisa instalar Android Studio no telefone.

1. No navegador do celular, entre em https://github.com e crie uma conta ou entre na sua conta.
2. Crie um repositório novo, por exemplo `CacauR1-Android`. Se houver a opção, deixe-o **Private**. Não marque para adicionar README, `.gitignore` ou licença, pois o projeto já contém esses arquivos.
3. Para enviar o código, use a interface web do GitHub para carregar os arquivos e pastas do projeto. O arquivo `.github/workflows/android-apk.yml` precisa ser enviado também; por ser uma pasta iniciada por ponto, confira que ela foi incluída.
4. Depois de enviar os arquivos para a branch `main` ou `master`, abra a aba **Actions** do repositório. Se solicitado, habilite workflows. Se a execução não iniciar sozinha, abra **Build Cacau R1 APK**, toque em **Run workflow** e confirme.
5. Abra a execução mais recente e espere ficar verde (**Success**). Se ficar vermelha (**Failure**), abra os logs; não considere o APK gerado.
6. Em **Artifacts**, baixe `cacau-r1-debug-apk`. O download é um ZIP contendo `app-debug.apk`; extraia-o com o gerenciador de arquivos do Android.
7. Toque em `app-debug.apk` para instalar. Se o Android bloquear, permita temporariamente a instalação de apps dessa origem nas configurações exibidas pelo próprio sistema. Instale apenas o APK que você gerou no seu repositório.

**Limitações:** este processo produz um APK de depuração, não um app publicado na Play Store. A compilação em nuvem ainda precisa ser executada com sucesso para confirmar que o APK foi produzido. A conta GitHub é necessária. A interface móvel do GitHub pode ser trabalhosa para enviar muitas pastas; se isso impedir o envio, me diga em qual tela você ficou para eu orientar a próxima etapa.

## Raspberry Pi 4B com 1 GB

O Pi recebe um serviço Python independente, sem bibliotecas externas. Não é um APK nem uma interface gráfica completa. Para executar:

```bash
cd raspberry-pi
python3 cacau_pi.py
```

Por padrão, a API escuta apenas `127.0.0.1:8765`, mais seguro para testes locais. Endpoints:

- `GET /api/status` — versão, plataforma, uptime, espaço livre e número de notas.
- `GET /api/notes` — lista notas salvas.
- `POST /api/notes` com JSON `{"text":"minha nota"}` — salva uma nota.
- `POST /api/chat` com JSON `{"text":"oi"}` — resposta local baseada em regras.

Para permitir acesso pela rede local, defina `CACAU_HOST=0.0.0.0` somente em uma rede confiável e configure firewall. **A API ainda não possui autenticação nem TLS; não a exponha à internet.** O app Android desta versão ainda não se conecta automaticamente a ela.

## Testes

- Execute os testes do companheiro Pi: `python3 raspberry-pi/test_cacau_pi.py`.
- Os testes unitários da calculadora estão em `app/src/test/java/br/com/cacau/r1/CalculatorTest.kt` e rodam via Android Studio/Gradle (`testDebugUnitTest`).
- Ver o relatório honesto em `docs/TESTES.md`.

## Próximas etapas recomendadas

1. Importar e validar o projeto no Android Studio e resolver qualquer erro de compilação com a versão real do SDK.
2. Testar em Android físico: voz, TTS, câmera, notas, timer, rotação e tamanhos de tela.
3. Portar o desenho SVG e as 34 animações originais para Compose Canvas/VectorDrawable.
4. Ligar o cliente Android ao serviço Pi com autenticação local antes de abrir a API na rede.
5. Implementar módulos por prioridade, começando por notas, timer, mídia local e comandos, depois integrações externas com OAuth.


## IA generativa Gemini

Abra **Ajustes → Inteligência Artificial**, cole uma chave da API Gemini criada em https://aistudio.google.com/apikey e toque em **Testar conexão com a IA**. Em seguida, a tela **Conversa** usa Gemini quando a chave está configurada; sem chave, usa comandos locais. Requer internet e pode estar sujeita a limites/custos da conta Google. Não publique sua chave em repositórios.
