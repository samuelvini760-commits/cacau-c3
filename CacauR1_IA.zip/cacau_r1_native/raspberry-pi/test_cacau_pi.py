import json, os, subprocess, sys, tempfile, time, urllib.request, urllib.error
from pathlib import Path

SCRIPT = Path(__file__).with_name("cacau_pi.py")
with tempfile.TemporaryDirectory() as td:
    env = os.environ.copy(); env.update(CACAU_HOST="127.0.0.1", CACAU_PORT="18765", CACAU_DATA=td)
    proc = subprocess.Popen([sys.executable, str(SCRIPT)], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        base = "http://127.0.0.1:18765"
        for _ in range(30):
            try:
                urllib.request.urlopen(base + "/api/status", timeout=0.2).read(); break
            except Exception: time.sleep(0.1)
        status = json.loads(urllib.request.urlopen(base + "/api/status").read())
        assert status["name"] == "Cacau R1 Pi Companion"
        req = urllib.request.Request(base + "/api/notes", data=json.dumps({"text":"teste local"}).encode(), headers={"Content-Type":"application/json"}, method="POST")
        assert urllib.request.urlopen(req).status == 201
        saved = json.loads(urllib.request.urlopen(base + "/api/notes").read())
        assert saved["notes"][0]["text"] == "teste local"
        req = urllib.request.Request(base + "/api/chat", data=json.dumps({"text":"oi"}).encode(), headers={"Content-Type":"application/json"}, method="POST")
        reply = json.loads(urllib.request.urlopen(req).read())
        assert "Oi" in reply["answer"]
        print("PASS: status endpoint")
        print("PASS: salvar e listar notas")
        print("PASS: resposta local de conversa")
    finally:
        proc.terminate(); proc.wait(timeout=3)
