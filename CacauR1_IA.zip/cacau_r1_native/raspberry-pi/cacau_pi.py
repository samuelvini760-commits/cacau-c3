#!/usr/bin/env python3
"""Lightweight local companion API for Cacau R1 on Raspberry Pi OS. Python stdlib only."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os, platform, shutil, time

HOST = os.environ.get("CACAU_HOST", "127.0.0.1")
PORT = int(os.environ.get("CACAU_PORT", "8765"))
DATA = Path(os.environ.get("CACAU_DATA", str(Path.home() / ".local/share/cacau-r1")))
DATA.mkdir(parents=True, exist_ok=True)
NOTES = DATA / "notes.json"


def load_notes():
    try:
        data = json.loads(NOTES.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def save_notes(notes):
    NOTES.write_text(json.dumps(notes[-500:], ensure_ascii=False, indent=2), encoding="utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "CacauPi/0.1"

    def _send(self, status, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/api/status":
            disk = shutil.disk_usage(DATA)
            self._send(200, {"name": "Cacau R1 Pi Companion", "version": "0.1.0", "platform": platform.platform(), "python": platform.python_version(), "uptime_seconds": int(time.time() - START), "disk_free_bytes": disk.free, "notes_count": len(load_notes()), "ai_mode": "local-rules-only"})
        elif self.path == "/api/notes":
            self._send(200, {"notes": load_notes()})
        else:
            self._send(404, {"error": "not_found"})

    def do_POST(self):
        if self.path not in ("/api/notes", "/api/chat"):
            self._send(404, {"error": "not_found"}); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 64_000:
                self._send(413, {"error": "payload_too_large"}); return
            body = json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, json.JSONDecodeError):
            self._send(400, {"error": "invalid_json"}); return
        if self.path == "/api/notes":
            text = str(body.get("text", "")).strip()
            if not text:
                self._send(400, {"error": "text_required"}); return
            notes = load_notes(); notes.append({"text": text, "created_at": int(time.time())}); save_notes(notes)
            self._send(201, {"saved": True, "notes_count": len(notes)})
        else:
            text = str(body.get("text", "")).strip()
            low = text.casefold()
            if any(x in low for x in ("oi", "olá", "ola", "bom dia", "boa noite")):
                answer = "Oi! Que bom ter você por aqui."
            elif "hora" in low:
                answer = time.strftime("Agora são %H:%M.")
            elif "ajuda" in low:
                answer = "Posso ajudar com notas, timer, calculadora e comandos simples locais."
            elif "obrigad" in low:
                answer = "Sempre que precisar, estou aqui!"
            else:
                answer = "Ainda não conheço esse comando no modo offline. Esta API usa regras locais, não um modelo generativo."
            self._send(200, {"answer": answer, "mode": "local-rules-only"})

    def log_message(self, fmt, *args):
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))


START = time.time()
if __name__ == "__main__":
    print(f"Cacau Pi Companion em http://{HOST}:{PORT} (somente rede confiável)")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
