# Relatório de testes — Cacau R1 0.1.0

Data: 29/10/2026

## Executado neste ambiente

- [ ] Build Android / Gradle Sync — **não executado**: o ambiente não possui Gradle nem Android SDK configurados.
- [ ] APK instalado em Android físico — **não executado**.
- [ ] Interface Compose em emulador — **não executado**.
- [ ] Testes Kotlin/JUnit — **escritos, não executados**.
- [ ] Teste em Raspberry Pi 4B físico — **não executado**.
- [ ] Integrações OAuth, IA online/offline, Spotify, Gmail e Agenda — **não implementadas/testadas**.

## Teste automatizado disponível

`python3 raspberry-pi/test_cacau_pi.py` inicia o serviço local em porta de teste e verifica:

1. resposta de status;
2. gravação e leitura de nota;
3. resposta local de conversa.

O teste usa diretório temporário, portanto não altera as notas do usuário.

## Testes Android incluídos

`CalculatorTest.kt` cobre precedência de operadores, parênteses, números negativos e divisão por zero. Rodar no Android Studio com `testDebugUnitTest`.

## Interpretação

Não declarar o APK pronto para uso até o projeto sincronizar e compilar no Android Studio e ser testado em aparelho real. Não declarar o companion compatível com o Raspberry Pi físico antes de executá-lo no Raspberry Pi OS de destino. Os módulos marcados como pendentes no README não devem ser apresentados como funcionais.
