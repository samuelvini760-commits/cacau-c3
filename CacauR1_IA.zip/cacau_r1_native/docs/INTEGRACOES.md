# Integrações Google e Spotify — estado real

## Já pode testar no aparelho

- **Spotify:** o campo de busca tenta abrir a pesquisa no aplicativo Spotify por URI `spotify:search:`; se isso falhar, abre a busca oficial na web. Há também um botão para abrir o Spotify.
- **Gmail:** o formulário cria um intent `mailto:` com destinatário e assunto; o Android oferece o app de e-mail para revisar e enviar. O Cacau não envia silenciosamente.
- **Google Agenda/calendário Android:** o formulário abre a tela de criação de evento via `CalendarContract`. Você revisa e salva no calendário disponível.
- **Google Drive, YouTube, Maps e Pesquisa:** atalhos abrem o aplicativo se instalado ou a página oficial no navegador.

Esses são fluxos reais entre aplicativos Android, não telas falsas. Eles dependem de o usuário ter o app ou navegador compatível instalado.

## O que ainda não está conectado por API

- Ler mensagens do Gmail, pesquisar a caixa de entrada, ler/criar/editar eventos em segundo plano e sincronizar a agenda dentro do Cacau.
- Ler a música atual, capa, artista, posição de reprodução e controlar play/pause/skip pelo Spotify Web API.
- Login OAuth integrado e renovação segura de tokens.

Essas funções exigem configurar um projeto Google Cloud (OAuth consent screen, APIs habilitadas e client ID) e um app Spotify for Developers (Client ID e redirect URI). As credenciais são específicas do proprietário e não podem ser inventadas ou embutidas no repositório público. O login e o fluxo OAuth ainda precisam ser implementados e testados depois de receber essas configurações.

## Como validar no Android

1. Instale o APK de debug compilado a partir deste projeto.
2. Abra **Spotify**, pesquise um artista ou música e confirme que a busca abre no app ou na web.
3. Abra **Gmail**, preencha destinatário/assunto e confirme que aparece a tela de composição.
4. Abra **Agenda**, preencha título e detalhes, crie o evento e confirme que o calendário abre com os dados preenchidos. Salve manualmente.
5. Em **Conexões**, teste os atalhos para Drive, YouTube, Maps e Pesquisa.

O APK ainda precisa ser compilado na nuvem ou em ambiente Android SDK. Não foi possível compilar neste ambiente porque Gradle/Android SDK não estão instalados; portanto, não há alegação de que o APK foi gerado ou de que a interface foi testada num aparelho físico.


## IA generativa Gemini API

A tela Conversa usa a API REST do Google Gemini quando uma chave é configurada em Ajustes. Sem chave, permanece o modo local por regras. Ajustes permite guardar a chave no armazenamento privado do app e testar a conexão. Obtenha uma chave em https://aistudio.google.com/apikey. Não publique a chave em repositórios nem a compartilhe. A chamada requer internet e pode estar sujeita a limites/custos da conta Google. Para distribuição a terceiros, recomenda-se backend próprio para proteger credenciais.

Limites conhecidos: análise de imagens por IA, seleção entre fornecedores OpenAI/Claude, armazenamento seguro com Android Keystore e testes reais em aparelho ainda não foram validados. O código Android não foi compilado nesta sessão.
