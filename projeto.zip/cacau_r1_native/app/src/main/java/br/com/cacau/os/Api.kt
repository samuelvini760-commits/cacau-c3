package br.com.cacau.os

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

// O "servidor" do Cacau, agora dentro do app: atende as mesmas rotas da API que o programa da placa atendia.
class Api(
    private val act: MainActivity,
    private val store: Store,
    private val google: Google,
    private val spotify: Spotify,
    private val voice: Voice
) {
    private val vibe = Vibe(store)

    fun handle(method: String, fullPath: String, body: String): Pair<Int, String> {
        val path = fullPath.substringBefore("?")
        return try {
            route(method, path, body)
        } catch (e: ApiError) {
            fail(e.status, e.message ?: "erro")
        } catch (e: IOException) {
            fail(503, "Sem conexão com a internet.")
        } catch (e: Exception) {
            fail(500, e.message ?: "erro interno")
        }
    }

    private fun ok(j: JSONObject): Pair<Int, String> = Pair(200, j.toString())
    private fun fail(code: Int, msg: String): Pair<Int, String> = Pair(code, JSONObject().put("error", msg).toString())
    private fun json(body: String): JSONObject = if (body.isEmpty()) JSONObject() else JSONObject(body)

    private fun netType(): String {
        val cm = act.getSystemService(ConnectivityManager::class.java) ?: return "none"
        val n = cm.activeNetwork ?: return "none"
        val c = cm.getNetworkCapabilities(n) ?: return "none"
        if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "none"
        if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) return "none"
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "4g"
            else -> "cabo"
        }
    }

    private fun hasKey(): Boolean = store.s("groq_key").isNotEmpty()

    private fun route(method: String, path: String, body: String): Pair<Int, String> {
        when (path) {
            "/api/status" -> return ok(status())
            "/api/config" -> {
                if (method == "POST") saveConfig(json(body))
                return ok(config())
            }
            "/api/ask" -> return ask(json(body))
            "/api/ai/test" -> {
                val key = store.s("groq_key")
                if (key.isEmpty()) throw ApiError(400, "Cole e salve a chave da Groq primeiro.")
                val r = Groq.ask(key, "Diga olá em uma frase curta.", null, "fast")
                return ok(JSONObject().put("text", r.first).put("model", r.second))
            }
            "/api/speak" -> {
                val j = json(body)
                voice.speak(j.optString("text"), j.optInt("vol", 80), langTag(j.optString("lang", "")))
                return ok(JSONObject().put("ok", true))
            }
            "/api/speak/stop" -> {
                voice.stopSpeaking()
                return ok(JSONObject().put("ok", true))
            }
            "/api/stt/start" -> {
                voice.start()
                return ok(JSONObject().put("ok", true))
            }
            "/api/stt/stop" -> return ok(JSONObject().put("text", voice.stop()))
            "/api/agenda" -> {
                val ev = if (google.connected()) google.agendaToday() else JSONArray()
                return ok(JSONObject().put("events", ev))
            }
            "/api/mail" -> {
                if (!google.connected()) return ok(JSONObject().put("configured", false))
                return ok(google.inbox())
            }
            "/api/spotify/state" -> {
                if (!spotify.connected()) return ok(JSONObject().put("configured", false))
                return ok(spotify.state())
            }
            "/api/spotify/playlists" -> return ok(JSONObject().put("playlists", spotify.playlists()))
            "/api/spotify/tracks" -> {
                val j = json(body)
                return ok(spotify.tracks(j.optString("uri"), j.optInt("offset", 0)))
            }
            "/api/spotify/devices" -> return ok(JSONObject().put("devices", spotify.devices()))
            "/api/spotify/transfer" -> {
                val j = json(body)
                spotify.transfer(j.optString("id"), j.optBoolean("play", true))
                return ok(JSONObject().put("ok", true))
            }
            "/api/spotify/open-app" -> return ok(JSONObject().put("opened", spotify.openSpotifyApp()))
            "/api/music/vibe" -> {
                val j = json(body)
                return ok(vibe.get(j.optString("id"), j.optString("name"), j.optString("artist"), j.optLong("duration_ms")))
            }
            "/api/google/test" -> return ok(google.test())
            "/api/clipboard" -> {
                val cm = act.getSystemService(ClipboardManager::class.java)
                if (method == "POST") {
                    cm.setPrimaryClip(ClipData.newPlainText("cacau", json(body).optString("text")))
                    return ok(JSONObject().put("ok", true))
                }
                val clip = cm.primaryClip
                val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(act).toString() else ""
                return ok(JSONObject().put("text", t))
            }
            "/api/open-url" -> {
                val u = json(body).optString("url")
                val okHost = listOf("console.groq.com", "aistudio.google.com", "console.cloud.google.com", "developer.spotify.com")
                    .any { u.startsWith("https://$it/") }
                if (!okHost) throw ApiError(400, "endereço não permitido")
                act.openExternal(u)
                return ok(JSONObject().put("ok", true))
            }
            "/api/spotify/search-play" -> {
                val r = spotify.searchPlay(json(body).optString("q"))
                return ok(r)
            }
            "/api/spotify/control" -> {
                spotify.control(json(body))
                return ok(JSONObject().put("ok", true))
            }
            "/api/translate" -> {
                val j = json(body)
                val key = store.s("groq_key")
                if (key.isEmpty() || netType() == "none") throw ApiError(503, "Sem IA online")
                val t = Groq.translate(key, j.optString("text"), j.optString("to", "inglês"))
                return ok(JSONObject().put("text", t).put("via", "cloud"))
            }
            "/api/vision" -> {
                val j = json(body)
                val key = store.s("groq_key")
                if (key.isEmpty() || netType() == "none") throw ApiError(503, "A Vision precisa da IA online.")
                val img = j.optString("image").replace(Regex("^data:[^,]*,"), "")
                return ok(JSONObject().put("text", Groq.vision(key, img, j.optString("prompt"))))
            }
            "/api/photo" -> return ok(JSONObject().put("saved", savePhoto(json(body).optString("image"))))
            "/api/music" -> return ok(JSONObject().put("tracks", JSONArray()).put("dir", ""))
            "/api/volume" -> {
                val am = act.getSystemService(AudioManager::class.java)
                val pct = json(body).optInt("percent", 50).coerceIn(0, 100)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, pct * max / 100, 0)
                return ok(JSONObject().put("ok", true))
            }
            "/api/google/login" -> {
                act.openExternal(google.startLogin())
                return ok(JSONObject().put("started", true))
            }
            "/api/google/logout" -> {
                google.logout()
                return ok(JSONObject().put("ok", true))
            }
            "/api/spotify/login" -> {
                act.openExternal(spotify.loginUrl())
                return ok(JSONObject().put("started", true))
            }
            "/api/spotify/logout" -> {
                spotify.logout()
                return ok(JSONObject().put("ok", true))
            }
            "/api/google/drive/backup" -> {
                google.driveBackup(json(body).optString("data", "{}"))
                return ok(JSONObject().put("ok", true))
            }
            "/api/google/drive/restore" -> return ok(JSONObject().put("data", google.driveRestore()))
            "/api/google/youtube" -> return ok(google.youtube())
        }
        return fail(404, "rota desconhecida: $path")
    }

    private fun langTag(l: String): String = when {
        l.isEmpty() -> ""
        l.length == 2 -> l
        else -> l.replace('_', '-')
    }

    private fun status(): JSONObject {
        val net = netType()
        val hw = JSONObject().put("net", net).put("wifi", JSONObject.NULL)
        val bi = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bi != null) {
            val level = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0 && scale > 0) {
                hw.put("battery", JSONObject().put("pct", level * 100 / scale).put("charging", charging))
            }
        }
        val hasNet = net != "none"
        return JSONObject()
            .put("net", hasNet).put("ai", hasKey()).put("online", hasNet && hasKey())
            .put("provider", "groq").put("tts", true).put("stt", voice.sttAvailable())
            .put("ical", google.connected()).put("mail", google.connected())
            .put("spotify", spotify.connected()).put("music", 0).put("needle", false)
            .put("local_llm", false).put("sys", JSONObject()).put("models", JSONObject()).put("hw", hw)
    }

    private fun config(): JSONObject = JSONObject()
        .put("groq", hasKey())
        .put("groq_tail", store.s("groq_key").takeLast(4))
        .put("google_client_id", store.s("g_client_id"))
        .put("google_secret", store.s("g_client_secret").isNotEmpty())
        .put("google_connected", google.connected())
        .put("google_email", google.email())
        .put("google_status", google.status)
        .put("google_missing", JSONArray(google.missing()))
        .put("spotify_client_id", store.s("s_client_id"))
        .put("spotify_connected", spotify.connected())
        .put("spotify_status", spotify.status)

    private fun saveConfig(j: JSONObject) {
        if (j.optBoolean("clear_groq", false)) { store.remove("groq_key"); Groq.forgetModels() }
        val gk = Groq.cleanKey(j.optString("groq_key", ""))
        if (gk.isNotEmpty()) { store.put("groq_key", gk); Groq.forgetModels() }
        if (j.has("google_client_id")) {
            val id = j.optString("google_client_id").trim().trim('"', '\'').replace(Regex("\\s+"), "")
            if (id.startsWith("GOCSPX-")) throw ApiError(400, "Você colou o Client secret no campo do Client ID. O ID termina em .apps.googleusercontent.com.")
            if (id.isNotEmpty() && !id.endsWith(".apps.googleusercontent.com"))
                throw ApiError(400, "Esse Client ID não parece certo: ele termina em .apps.googleusercontent.com.")
            if (id != store.s("g_client_id")) store.put("g_client_id", id)
        }
        val gs = j.optString("google_client_secret", "").trim().trim('"', '\'').replace(Regex("\\s+"), "")
        if (gs.isNotEmpty()) {
            if (gs.endsWith(".apps.googleusercontent.com")) throw ApiError(400, "Você colou o Client ID no campo do secret. O secret começa com GOCSPX-.")
            store.put("g_client_secret", gs)
        }
        if (j.has("spotify_client_id")) store.put("s_client_id", j.optString("spotify_client_id").trim().replace(Regex("\\s+"), ""))
    }

    private fun ask(j: JSONObject): Pair<Int, String> {
        val text = j.optString("text").trim()
        val mode = j.optString("mode", "smart")
        val key = store.s("groq_key")
        var cloudError = ""
        if (key.isNotEmpty() && netType() != "none") {
            try {
                val r = Groq.ask(key, text, j.optJSONArray("history"), mode)
                return ok(JSONObject().put("text", r.first).put("via", "cloud").put("model", r.second))
            } catch (e: ApiError) {
                cloudError = e.message ?: "erro"
            } catch (e: IOException) {
                cloudError = "Sem conexão com a internet."
            }
        }
        val off = Offline.answer(text)
        if (off != null) return ok(JSONObject().put("text", off).put("via", "offline").put("model", "regras"))
        return fail(503, if (cloudError.isEmpty()) "Sem IA online" else cloudError)
    }

    private fun savePhoto(image: String): String {
        val b64 = image.replace(Regex("^data:[^,]*,"), "")
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val name = "cacau-" + System.currentTimeMillis() + ".jpg"
        val values = ContentValues()
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name)
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Cacau")
        values.put(MediaStore.Images.Media.IS_PENDING, 1)
        val resolver = act.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw ApiError(500, "não consegui criar o arquivo da foto")
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
        val done = ContentValues()
        done.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, done, null, null)
        return name
    }
}
