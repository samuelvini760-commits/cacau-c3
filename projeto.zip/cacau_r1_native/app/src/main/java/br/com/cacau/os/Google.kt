package br.com.cacau.os

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.ServerSocket
import java.net.URLDecoder
import java.util.Calendar
import java.util.TimeZone

/** Login Google (cliente "App para computador", PKCE + retorno em 127.0.0.1) e chamadas às APIs. */
class Google(private val store: Store) {
    private val scopes = "openid email " +
        "https://www.googleapis.com/auth/calendar.readonly " +
        "https://www.googleapis.com/auth/gmail.readonly " +
        "https://www.googleapis.com/auth/drive.appdata " +
        "https://www.googleapis.com/auth/youtube.readonly"

    @Volatile var status: String = ""
    private var server: ServerSocket? = null

    fun connected(): Boolean = store.s("g_refresh").isNotEmpty()
    fun email(): String = store.s("g_email")

    fun logout() {
        store.remove("g_refresh", "g_access", "g_exp", "g_email")
        status = ""
    }

    /** Abre o navegador para o login. Devolve a URL a abrir; o retorno chega no servidor local. */
    fun startLogin(): String {
        val cid = store.s("g_client_id")
        if (cid.isEmpty()) throw ApiError(400, "Cole primeiro o Client ID do Google e salve.")
        try { server?.close() } catch (e: Exception) { }
        val ss = ServerSocket(0, 5, InetAddress.getByName("127.0.0.1"))
        ss.soTimeout = 300000
        server = ss
        val redirect = "http://127.0.0.1:" + ss.localPort
        val verifier = Pkce.random(48)
        val state = Pkce.random(12)
        val url = "https://accounts.google.com/o/oauth2/v2/auth?" + Http.form(
            linkedMapOf(
                "client_id" to cid,
                "redirect_uri" to redirect,
                "response_type" to "code",
                "scope" to scopes,
                "code_challenge" to Pkce.challenge(verifier),
                "code_challenge_method" to "S256",
                "state" to state,
                "access_type" to "offline",
                "prompt" to "consent"
            )
        )
        status = "Aguardando você entrar no navegador…"
        Thread {
            try {
                val params = Loopback.wait(ss)
                try { ss.close() } catch (e: Exception) { }
                val ok = params["code"] != null && params["state"] == state
                if (!ok) {
                    status = "Erro no login: " + (params["error"] ?: "resposta inválida")
                    return@Thread
                }
                exchange(params["code"]!!, verifier, redirect)
            } catch (e: Exception) {
                status = "Erro no login: " + (e.message ?: "tempo esgotado")
            }
        }.start()
        return url
    }

    private fun exchange(code: String, verifier: String, redirect: String) {
        val r = Http.request(
            "POST", "https://oauth2.googleapis.com/token",
            mapOf("Content-Type" to "application/x-www-form-urlencoded"),
            Http.form(
                linkedMapOf(
                    "code" to code,
                    "client_id" to store.s("g_client_id"),
                    "client_secret" to store.s("g_client_secret"),
                    "redirect_uri" to redirect,
                    "grant_type" to "authorization_code",
                    "code_verifier" to verifier
                )
            )
        )
        if (r.code !in 200..299) {
            status = "Erro no login: " + errText(r.body)
            return
        }
        val j = JSONObject(r.body)
        val refresh = j.optString("refresh_token", "")
        if (refresh.isEmpty()) {
            status = "O Google não devolveu a permissão de longa duração. Tente de novo."
            return
        }
        store.put("g_refresh", refresh)
        store.put("g_access", j.optString("access_token"))
        store.putL("g_exp", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L)
        store.put("g_email", emailFrom(j.optString("id_token", "")))
        status = "Conectado"
    }

    private fun emailFrom(idToken: String): String {
        return try {
            val p = idToken.split(".")[1]
            val raw = Base64.decode(p, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
            JSONObject(String(raw, Charsets.UTF_8)).optString("email", "")
        } catch (e: Exception) {
            ""
        }
    }

    private fun errText(raw: String): String {
        return try {
            val j = JSONObject(raw)
            val d = j.optString("error_description", "")
            if (d.isNotEmpty()) d else j.optString("error", raw.take(120))
        } catch (e: Exception) {
            raw.take(120)
        }
    }

    @Synchronized
    fun token(): String {
        if (!connected()) throw ApiError(401, "Google não conectado. Entre em Conexões.")
        if (store.l("g_exp") - 60000L > System.currentTimeMillis() && store.s("g_access").isNotEmpty()) {
            return store.s("g_access")
        }
        val r = Http.request(
            "POST", "https://oauth2.googleapis.com/token",
            mapOf("Content-Type" to "application/x-www-form-urlencoded"),
            Http.form(
                linkedMapOf(
                    "client_id" to store.s("g_client_id"),
                    "client_secret" to store.s("g_client_secret"),
                    "refresh_token" to store.s("g_refresh"),
                    "grant_type" to "refresh_token"
                )
            )
        )
        if (r.code !in 200..299) {
            if (r.code == 400 || r.code == 401) {
                logout()
                throw ApiError(401, "O login do Google expirou. Entre de novo em Conexões.")
            }
            throw ApiError(502, "Google: " + errText(r.body))
        }
        val j = JSONObject(r.body)
        store.put("g_access", j.optString("access_token"))
        store.putL("g_exp", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L)
        return store.s("g_access")
    }

    private fun get(url: String): JSONObject {
        val r = Http.request("GET", url, mapOf("Authorization" to "Bearer " + token()))
        if (r.code !in 200..299) throw ApiError(502, "Google " + r.code + ": " + errText(r.body))
        return JSONObject(r.body)
    }

    // ---------- Agenda ----------
    fun agendaToday(): JSONArray {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        val end = start + 24L * 3600L * 1000L
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val url = "https://www.googleapis.com/calendar/v3/calendars/primary/events?singleEvents=true&orderBy=startTime&maxResults=30" +
            "&timeMin=" + Http.enc(fmt.format(java.util.Date(start))) + "&timeMax=" + Http.enc(fmt.format(java.util.Date(end)))
        val items = get(url).optJSONArray("items") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until items.length()) {
            val e = items.getJSONObject(i)
            val title = e.optString("summary", "(sem título)")
            val st = e.optJSONObject("start") ?: continue
            val en = e.optJSONObject("end")
            val ev = JSONObject()
            if (st.has("dateTime")) {
                val a = parseIso(st.getString("dateTime"))
                val b = if (en != null && en.has("dateTime")) parseIso(en.getString("dateTime")) else a + 3600000L
                val c = Calendar.getInstance(); c.timeInMillis = a
                ev.put("h", c.get(Calendar.HOUR_OF_DAY)).put("m", c.get(Calendar.MINUTE))
                ev.put("dur", maxOf(5L, (b - a) / 60000L).toInt()).put("txt", title)
            } else {
                ev.put("h", 0).put("m", 0).put("dur", 30).put("txt", "$title (dia todo)")
            }
            out.put(ev)
        }
        return out
    }

    private fun parseIso(s: String): Long {
        val t = s.replace("Z", "+00:00")
        val fixed = if (Regex(".*[+-]\\d\\d:\\d\\d$").matches(t)) t.substring(0, t.length - 3) + t.substring(t.length - 2) else t
        val clean = fixed.replace(Regex("\\.\\d+"), "")
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", java.util.Locale.US)
        return f.parse(clean)!!.time
    }

    // ---------- Gmail ----------
    fun inbox(): JSONObject {
        val label = get("https://www.googleapis.com/gmail/v1/users/me/labels/INBOX")
        val unread = label.optInt("messagesUnread", 0)
        val list = get("https://www.googleapis.com/gmail/v1/users/me/messages?labelIds=INBOX&maxResults=8")
        val ids = list.optJSONArray("messages") ?: JSONArray()
        val msgs = JSONArray()
        for (i in 0 until ids.length()) {
            val id = ids.getJSONObject(i).getString("id")
            val m = get(
                "https://www.googleapis.com/gmail/v1/users/me/messages/" + id +
                    "?format=metadata&metadataHeaders=From&metadataHeaders=Subject"
            )
            var from = ""
            var subject = ""
            val hs = m.optJSONObject("payload")?.optJSONArray("headers") ?: JSONArray()
            for (k in 0 until hs.length()) {
                val h = hs.getJSONObject(k)
                if (h.optString("name").equals("From", true)) from = h.optString("value")
                if (h.optString("name").equals("Subject", true)) subject = h.optString("value")
            }
            val name = if (from.contains("<")) from.substringBefore("<").trim().trim('"') else from
            val labels = m.optJSONArray("labelIds") ?: JSONArray()
            var isUnread = false
            for (k in 0 until labels.length()) if (labels.getString(k) == "UNREAD") isUnread = true
            msgs.put(
                JSONObject().put("subject", if (subject.isEmpty()) "(sem assunto)" else subject)
                    .put("from", if (name.isEmpty()) from else name).put("unread", isUnread)
            )
        }
        return JSONObject().put("configured", true).put("unread", unread).put("messages", msgs)
    }

    // ---------- Drive (pasta privada do app) ----------
    private fun driveFileIds(): List<String> {
        val q = Http.enc("name='cacau-backup.json'")
        val j = get("https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&fields=files(id)&q=$q")
        val arr = j.optJSONArray("files") ?: JSONArray()
        val ids = ArrayList<String>()
        for (i in 0 until arr.length()) ids.add(arr.getJSONObject(i).getString("id"))
        return ids
    }

    fun driveBackup(data: String) {
        val tk = token()
        for (id in driveFileIds()) {
            Http.request("DELETE", "https://www.googleapis.com/drive/v3/files/$id", mapOf("Authorization" to "Bearer $tk"))
        }
        val b = "cacau_boundary_7f3a"
        val meta = JSONObject().put("name", "cacau-backup.json").put("parents", JSONArray().put("appDataFolder"))
        val body = "--$b\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta.toString() +
            "\r\n--$b\r\nContent-Type: application/json\r\n\r\n" + data + "\r\n--$b--"
        val r = Http.request(
            "POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
            mapOf("Authorization" to "Bearer $tk", "Content-Type" to "multipart/related; boundary=$b"), body, 40000
        )
        if (r.code !in 200..299) throw ApiError(502, "Drive " + r.code + ": " + errText(r.body))
    }

    fun driveRestore(): String {
        val ids = driveFileIds()
        if (ids.isEmpty()) throw ApiError(404, "Nenhum backup encontrado no Drive.")
        val r = Http.request(
            "GET", "https://www.googleapis.com/drive/v3/files/" + ids[0] + "?alt=media",
            mapOf("Authorization" to "Bearer " + token()), null, 40000
        )
        if (r.code !in 200..299) throw ApiError(502, "Drive " + r.code + ": " + errText(r.body))
        return r.body
    }

    // ---------- YouTube (leitura) ----------
    fun youtube(): JSONObject {
        val pl = get("https://www.googleapis.com/youtube/v3/playlists?part=snippet&mine=true&maxResults=10")
        val sb = get("https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true&maxResults=10")
        fun titles(j: JSONObject): JSONArray {
            val out = JSONArray()
            val items = j.optJSONArray("items") ?: return out
            for (i in 0 until items.length()) {
                out.put(items.getJSONObject(i).optJSONObject("snippet")?.optString("title", "") ?: "")
            }
            return out
        }
        return JSONObject().put("playlists", titles(pl)).put("subscriptions", titles(sb))
    }
}
