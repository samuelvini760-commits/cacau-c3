package br.com.cacau.os

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * "Clima" de uma música para a Cacau dançar e reagir: andamento (bpm), humor e momentos da letra.
 *
 * - O Spotify fechou o acesso a análise de áudio para apps novos, então o andamento vem da Groq (se houver chave)
 *   ou de uma estimativa local. A letra é lida só para marcar *quando* aparece amor, festa, tristeza etc.;
 *   o texto da letra nunca é guardado nem enviado para a tela.
 * - Tudo é opcional: se algo falhar, a Cacau dança com a estimativa local.
 */
class Vibe(private val store: Store) {
    private val cats = linkedMapOf(
        "love" to Regex("\\b(love|loves|loving|amor|amo|te quiero|je t'aime|heart|cora[cç][aã]o|coraz[oó]n|kiss|beijo|baby|darling|querid[ao]|mon amour)\\b", RegexOption.IGNORE_CASE),
        "sad" to Regex("\\b(cry|crying|chor[ao]|l[aá]grimas?|tears?|sad|triste|alone|sozinh[ao]|lonely|goodbye|adeus|hurt|pain|dor|miss you|saudade|broken|leave me|sola|soledad)\\b", RegexOption.IGNORE_CASE),
        "dance" to Regex("\\b(dance|dancing|dan[cç]a|dan[cç]ar|bailar|baila|groove|boogie|disco|jump|pula|party|festa|fiesta|one more time|harder|faster|stronger|around the world|get lucky)\\b", RegexOption.IGNORE_CASE),
        "happy" to Regex("\\b(happy|feliz|smile|sorri[ds]o|sunshine|sol|summer|ver[aã]o|alegria|fun|good (time|day|life|morning)|lucky|celebrate|yeah)\\b", RegexOption.IGNORE_CASE),
        "dream" to Regex("\\b(dream|dreams|sonho|sonhar|sue[nñ]o|sleep|dormir|moon|lua|stars?|estrelas?|float|space|cosmic|sky|c[eé]u|trip|high|nightfall)\\b", RegexOption.IGNORE_CASE),
        "wow" to Regex("\\b(wow|whoa|oh my|omg|surprise|uau|nossa|caramba|what the)\\b", RegexOption.IGNORE_CASE),
        "huh" to Regex("\\b(why|por ?que|confused|confus[ao]|lost|perdid[ao]|crazy|louc[ao]|doubt|d[uú]vida)\\b", RegexOption.IGNORE_CASE)
    )

    private val lrc = Regex("^\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?](.*)$")

    fun get(key: String, name: String, artist: String, durMs: Long): JSONObject {
        val ck = (artist + "|" + name).lowercase().take(120)
        val cached = readCache(ck)
        if (cached != null) return cached

        var events = JSONArray()
        var ai: JSONObject? = null
        val t1 = Thread { events = try { lyricEvents(name, artist, durMs) } catch (e: Exception) { JSONArray() } }
        val gk = store.s("groq_key")
        val t2 = Thread { if (gk.isNotEmpty()) ai = try { askGroq(gk, name, artist) } catch (e: Exception) { null } }
        t1.start(); t2.start()
        try { t1.join(9000); t2.join(14000) } catch (e: InterruptedException) { }

        val h = heuristic(name, artist)
        val a = ai
        val out = JSONObject()
        out.put("bpm", clampBpm(a?.optInt("bpm", 0) ?: 0, h.getInt("bpm")))
        var en = h.getDouble("energy")
        if (a != null && a.has("energy")) en = a.optDouble("energy", en)
        out.put("energy", en.coerceIn(0.0, 1.0))
        out.put("mood", validMood(a?.optString("mood", "") ?: "", h.getString("mood")))
        out.put("style", h.getString("style"))
        out.put("events", events)
        out.put("src", (if (a != null) "groq" else "estimado") + (if (events.length() > 0) "+letra" else ""))
        // só guarda no cache se ao menos uma fonte externa respondeu (senão tenta de novo na próxima vez)
        if (a != null || events.length() > 0) writeCache(ck, out)
        return out
    }

    private fun clampBpm(v: Int, fallback: Int): Int = if (v in 50..220) v else fallback

    private val moods = setOf("happy", "chill", "dreamy", "love", "hype", "sad", "cool")
    private fun validMood(m: String, fallback: String): String = if (m.lowercase() in moods) m.lowercase() else fallback

    /** Estimativa local: conhece o estilo de alguns artistas e usa o nome da faixa para variar o andamento. */
    fun heuristic(name: String, artist: String): JSONObject {
        val a = artist.lowercase()
        var h = 0
        for (ch in name.lowercase()) h = (h * 31 + ch.code) and 0x7fffffff
        val j = JSONObject()
        when {
            a.contains("daft punk") -> j.put("bpm", 116 + h % 12).put("energy", 0.9).put("mood", "hype").put("style", "robot")
            a.contains("tame impala") -> j.put("bpm", 96 + h % 30).put("energy", 0.65).put("mood", "dreamy").put("style", "psy")
            a.contains("tv girl") -> j.put("bpm", 84 + h % 24).put("energy", 0.45).put("mood", "chill").put("style", "lofi")
            else -> j.put("bpm", 84 + h % 40).put("energy", 0.6).put("mood", "happy").put("style", "pop")
        }
        return j
    }

    private fun askGroq(key: String, name: String, artist: String): JSONObject? {
        val q = "Música: \"" + name.replace("\"", "'") + "\" de " + artist.replace("\"", "'") + ". " +
            "Responda SOMENTE com JSON no formato {\"bpm\":número,\"energy\":número de 0 a 1,\"mood\":\"happy|chill|dreamy|love|hype|sad|cool\"}. " +
            "bpm é o andamento aproximado em batidas por minuto; se não conhecer a música, estime pelo estilo do artista."
        return Groq.json(key, q)
    }

    /** Lê a letra sincronizada (lrclib.net) só para achar momentos; devolve [[ms, categoria], ...]. */
    private fun lyricEvents(name: String, artist: String, durMs: Long): JSONArray {
        val first = artist.substringBefore(",").trim()
        val base = "https://lrclib.net/api/get?track_name=" + enc(name) + "&artist_name=" + enc(first) +
            (if (durMs > 0) "&duration=" + (durMs / 1000) else "")
        var body = ""
        val r = Http.request("GET", base, emptyMap(), null, 6000)
        if (r.code in 200..299) body = r.body
        else {
            val s = Http.request("GET", "https://lrclib.net/api/search?track_name=" + enc(name) + "&artist_name=" + enc(first), emptyMap(), null, 6000)
            if (s.code in 200..299) {
                val arr = JSONArray(s.body)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("syncedLyrics").isNotEmpty()) { body = o.toString(); break }
                }
            }
        }
        if (body.isEmpty()) return JSONArray()
        val synced = JSONObject(body).optString("syncedLyrics", "")
        if (synced.isEmpty()) return JSONArray()

        val out = JSONArray()
        var last = -99999L
        val lastByCat = HashMap<String, Long>()
        for (line in synced.lineSequence()) {
            val m = lrc.find(line.trim()) ?: continue
            val ms = m.groupValues[1].toLong() * 60000L + m.groupValues[2].toLong() * 1000L +
                (m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L)
            val text = m.groupValues[4]
            if (ms - last < 4500L) continue
            for (entry in cats.entries) {
                val cat = entry.key
                if (entry.value.containsMatchIn(text) && ms - (lastByCat[cat] ?: -99999L) > 9000L) {
                    out.put(JSONArray().put(ms).put(cat))
                    last = ms
                    lastByCat[cat] = ms
                    break
                }
            }
            if (out.length() >= 60) break
        }
        return out
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---- cache pequeno (no máximo 40 músicas) ----
    private fun readCache(k: String): JSONObject? = try {
        JSONObject(store.s("vibe_cache")).optJSONObject(k)
    } catch (e: Exception) { null }

    private fun writeCache(k: String, v: JSONObject) {
        try {
            val all = try { JSONObject(store.s("vibe_cache")) } catch (e: Exception) { JSONObject() }
            all.put(k, v)
            if (all.length() > 40) {
                val keys = all.keys().asSequence().toList()
                for (i in 0 until all.length() - 40) all.remove(keys[i])
            }
            store.put("vibe_cache", all.toString())
        } catch (e: Exception) { }
    }
}
