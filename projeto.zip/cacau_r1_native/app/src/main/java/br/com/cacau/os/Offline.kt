package br.com.cacau.os

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** IA "fraca" offline: só o que dá para responder com regras (hora, data, contas e ajuda). */
object Offline {
    private val BR = Locale("pt", "BR")

    fun answer(raw: String): String? {
        val t = raw.lowercase(BR).trim()
        if (t.isEmpty()) return null
        if (Regex("que horas|\\bhoras?\\b").containsMatchIn(t) && !t.contains("daqui")) {
            return "Agora são " + SimpleDateFormat("HH:mm", BR).format(Date()) + "."
        }
        if (Regex("que dia|qual a data|data de hoje|dia da semana").containsMatchIn(t)) {
            return "Hoje é " + SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", BR).format(Date()) + "."
        }
        if (Regex("\\bajuda\\b|o que voc[eê] (faz|sabe)").containsMatchIn(t)) {
            return "Sem internet eu sei a hora, a data e fazer contas. Online eu converso de verdade."
        }
        return calc(t)
    }

    private fun calc(t0: String): String? {
        var t = t0
        val words = Regex("quanto|calcul|vezes|mais|menos|dividido|multiplicado|\\bconta\\b")
        val onlyExpr = Regex("^[0-9\\s+\\-*/().,x]+$")
        if (!words.containsMatchIn(t) && !onlyExpr.matches(t)) return null
        t = t.replace("dividido por", "/").replace("multiplicado por", "*")
            .replace("vezes", "*").replace("mais", "+").replace("menos", "-")
            .replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), "*").replace(",", ".")
        val m = Regex("[0-9][0-9+\\-*/().\\s]*[0-9)]").find(t) ?: return null
        val expr = m.value
        if (!Regex("[+\\-*/]").containsMatchIn(expr)) return null
        return try {
            val v = Parser(expr).parse()
            if (v.isNaN() || v.isInfinite()) {
                "Isso não dá para calcular."
            } else {
                val shown = if (v == Math.floor(v) && Math.abs(v) < 1e12) v.toLong().toString()
                else String.format(BR, "%.4f", v).trimEnd('0').trimEnd(',')
                "O resultado é $shown."
            }
        } catch (e: Exception) {
            null
        }
    }

    private class Parser(val s: String) {
        var i = 0

        fun parse(): Double {
            val v = expr()
            skip()
            if (i != s.length) throw IllegalArgumentException("sobrou texto")
            return v
        }

        private fun skip() {
            while (i < s.length && s[i] == ' ') i++
        }

        private fun expr(): Double {
            var v = term()
            while (true) {
                skip()
                if (i < s.length && s[i] == '+') { i++; v += term() }
                else if (i < s.length && s[i] == '-') { i++; v -= term() }
                else return v
            }
        }

        private fun term(): Double {
            var v = factor()
            while (true) {
                skip()
                if (i < s.length && s[i] == '*') { i++; v *= factor() }
                else if (i < s.length && s[i] == '/') { i++; v /= factor() }
                else return v
            }
        }

        private fun factor(): Double {
            skip()
            if (i < s.length && s[i] == '-') { i++; return -factor() }
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                skip()
                if (i < s.length && s[i] == ')') i++ else throw IllegalArgumentException("falta )")
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("número esperado")
            return s.substring(st, i).toDouble()
        }
    }
}
