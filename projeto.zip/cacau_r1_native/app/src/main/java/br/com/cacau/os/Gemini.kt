package br.com.cacau.os

import org.json.JSONArray
import org.json.JSONObject

/** IA online: API Gemini (REST). A chave fica só neste aparelho. */
object Gemini {
    const val PERSONA =
        "Você é o Cacau, um passarinho assistente de bolso, simpático e curioso. " +
            "Responda em português do Brasil, em no máximo duas frases curtas, sem listas e sem formatação, " +
            "porque sua resposta aparece numa tela pequena e é falada em voz alta."

    private val HARD = Regex(
        "\\b(explique|explica|analis|compar|planej|resum|por ?que|como funciona|diferen[cç]a|vantagens|" +
            "pr[oó]s e contras|estrat[eé]gia|escreva|redij|demonstr|calcule|passo a passo)",
        RegexOption.IGNORE_CASE
    )

    fun tierFor(text: String, mode: String): String {
        val words = text.trim().split(Regex("\\s+")).size
        return if (mode == "smart" && words <= 7 && !HARD.containsMatchIn(text)) "fast" else mode
    }

    private fun models(tier: String): List<String> = when (tier) {
        "fast" -> listOf("gemini-3.1-flash-lite", "gemini-3.5-flash")
        "deep", "max" -> listOf("gemini-3.1-pro-preview", "gemini-3.5-flash")
        else -> listOf("gemini-3.5-flash", "gemini-3.1-flash-lite")
    }

    private fun maxTokens(tier: String): Int = when (tier) {
        "fast" -> 1024
        "smart" -> 2048
        "deep" -> 4096
        else -> 6000
    }

    /** Devolve (texto, modelo usado). Tenta o modelo do nível e cai para o seguinte se ele não existir. */
    fun generate(key: String, tier: String, system: String, contents: JSONArray): Pair<String, String> {
        var lastMsg = "a IA não respondeu"
        for (model in models(tier)) {
            val body = JSONObject()
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            body.put("contents", contents)
            body.put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens(tier)))
            val r = Http.request(
                "POST",
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                mapOf("Content-Type" to "application/json", "x-goog-api-key" to key),
                body.toString(),
                45000
            )
            if (r.code in 200..299) {
                val text = extract(r.body)
                if (text.isNotEmpty()) return Pair(text, model)
                lastMsg = "resposta vazia"
                continue
            }
            lastMsg = errMsg(r.body, r.code)
            if (r.code == 401 || r.code == 403) throw ApiError(r.code, "A chave Gemini foi recusada: $lastMsg")
            if (r.code != 400 && r.code != 404 && r.code != 429 && r.code < 500) break
        }
        throw ApiError(502, lastMsg)
    }

    private fun extract(raw: String): String {
        val j = JSONObject(raw)
        val cands = j.optJSONArray("candidates") ?: return ""
        if (cands.length() == 0) return ""
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text", ""))
        }
        return sb.toString().trim()
    }

    private fun errMsg(raw: String, code: Int): String {
        return try {
            val m = JSONObject(raw).optJSONObject("error")?.optString("message", "") ?: ""
            if (m.isNotEmpty()) m else "erro $code"
        } catch (e: Exception) {
            "erro $code"
        }
    }

    fun userMsg(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun ask(key: String, text: String, history: JSONArray?, mode: String): Triple<String, String, String> {
        val tier = tierFor(text, mode)
        val contents = JSONArray()
        if (history != null) {
            val from = maxOf(0, history.length() - 6)
            for (i in from until history.length()) {
                val h = history.getJSONObject(i)
                val role = if (h.optString("role") == "assistant") "model" else "user"
                val c = h.optString("content")
                if (c.isNotEmpty()) contents.put(userMsg(role, c))
            }
        }
        contents.put(userMsg("user", text))
        val r = generate(key, tier, PERSONA, contents)
        return Triple(r.first, r.second, tier)
    }

    fun vision(key: String, imageB64: String, prompt: String): String {
        val parts = JSONArray()
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", imageB64)))
            .put(JSONObject().put("text", if (prompt.isEmpty()) "Descreva o que você vê." else prompt))
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
        return generate(key, "smart", "$PERSONA Você está olhando pela câmera do aparelho.", contents).first
    }

    fun translate(key: String, text: String, to: String): String {
        val sys = "Você é um tradutor. Traduza o texto do usuário para $to. " +
            "Responda SOMENTE com a tradução, sem aspas e sem explicações."
        val contents = JSONArray().put(userMsg("user", text))
        return generate(key, "fast", sys, contents).first
    }
}
