package br.com.cacau.os

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var store: Store
    private lateinit var google: Google
    private lateinit var spotify: Spotify
    private lateinit var voice: Voice
    private lateinit var api: Api
    private val pool = Executors.newCachedThreadPool()
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val host = "appassets.androidplatform.net"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        google = Google(store)
        spotify = Spotify(applicationContext, store)
        voice = Voice(this)
        api = Api(this, store, google, spotify, voice)

        web = WebView(this)
        web.setBackgroundColor(0xFF000000.toInt())
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                if (u.host != host) return null
                var p = u.path ?: "/"
                if (p == "/" || p.isEmpty()) p = "/index.html"
                return try {
                    WebResourceResponse(mime(p), "utf-8", assets.open("www$p"))
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                if (u.host == host) return false
                openExternal(u.toString())
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                val req = request
                runOnUiThread { if (req != null) req.grant(req.resources) }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                val chooser = fileChooserParams?.createIntent()
                if (chooser == null) {
                    fileCb = null
                    return false
                }
                return try {
                    startActivityForResult(chooser, 77)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCb = null
                    false
                }
            }
        }

        setContentView(web)
        askPermissions()
        handleIntent(intent)
        web.loadUrl("https://$host/index.html")
    }

    private fun mime(p: String): String = when {
        p.endsWith(".html") -> "text/html"
        p.endsWith(".js") -> "application/javascript"
        p.endsWith(".css") -> "text/css"
        p.endsWith(".json") -> "application/json"
        p.endsWith(".svg") -> "image/svg+xml"
        p.endsWith(".png") -> "image/png"
        p.endsWith(".woff2") -> "font/woff2"
        else -> "application/octet-stream"
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    fun openExternal(url: String) {
        runOnUiThread {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: Exception) { }
        }
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "cacau" && d.host == "spotify") spotify.handleRedirect(d)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val js = "(function(){try{if(typeof mode!=='undefined'&&mode==='home')return 'home';back();return 'ok'}catch(e){return 'home'}})()"
        web.evaluateJavascript(js) { v ->
            if (v == null || v.contains("home")) moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        voice.shutdown()
        pool.shutdown()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun api(id: Int, method: String, path: String, body: String) {
            pool.execute {
                val r = this@MainActivity.api.handle(method, path, body)
                val js = "window.__cacauResolve(" + id + "," + r.first + "," + JSONObject.quote(r.second) + ")"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }
        }
    }
}
