package br.com.cacau.os

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var store: Store
    private lateinit var google: Google
    private lateinit var spotify: Spotify
    private lateinit var voice: Voice
    private lateinit var api: Api
    private val pool = Executors.newFixedThreadPool(4)   // limitado: aparelhos de 1 GB de RAM não aguentam dezenas de threads
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val host = "appassets.androidplatform.net"

    companion object {
        const val EXTRA_ASSIST = "cacau_assist"
    }

    // modo conversa vindo de fora (botão de ligar segurado / volume segurado)
    private var pageReady = false
    private var resumed = false
    private var pendingAssist = false
    private var volLong = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        google = Google(store)
        spotify = Spotify(applicationContext, store)
        voice = Voice(this)
        voice.onEnd = { runOnUiThread { if (!isDestroyed) web.evaluateJavascript("window.__cacauSttEnd&&window.__cacauSttEnd()", null) } }
        api = Api(this, store, google, spotify, voice)

        web = WebView(this)
        web.setBackgroundColor(0xFF000000.toInt())
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.textZoom = 100
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                runPendingAssist()
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                if (u.host != host) return null
                var p = u.path ?: "/"
                if (p == "/" || p.isEmpty()) p = "/index.html"
                return try {
                    WebResourceResponse(mime(p), "utf-8", assets.open("www$p"))
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                if (u.host == host) return false
                openExternal(u.toString())
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                val req = request
                runOnUiThread { if (req != null) req.grant(req.resources) }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                val chooser = fileChooserParams?.createIntent()
                if (chooser == null) {
                    fileCb = null
                    return false
                }
                return try {
                    startActivityForResult(chooser, 77)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCb = null
                    false
                }
            }
        }

        setContentView(web)
        askPermissions()
        web.loadUrl("https://$host/index.html")
        handleAssistIntent(intent)
    }

    private fun mime(p: String): String = when {
        p.endsWith(".html") -> "text/html"
        p.endsWith(".js") -> "application/javascript"
        p.endsWith(".css") -> "text/css"
        p.endsWith(".json") -> "application/json"
        p.endsWith(".svg") -> "image/svg+xml"
        p.endsWith(".png") -> "image/png"
        p.endsWith(".woff2") -> "font/woff2"
        else -> "application/octet-stream"
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    fun openExternal(url: String) {
        runOnUiThread {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: Exception) { }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    // Fora da tela, a página para de gastar CPU (relógios, animações e consultas ao Spotify pausam).
    @Volatile private var keepAwake = false   // a página avisa quando há música tocando, para o som não cortar

    override fun onPause() {
        resumed = false
        if (!keepAwake) web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.evaluateJavascript("window.__cacauResume&&window.__cacauResume()", null)
        resumed = true
        runPendingAssist()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)   // volta do navegador depois do login (cacau://voltar): só traz o app para a frente
        setIntent(intent)
        handleAssistIntent(intent)
    }

    private fun handleAssistIntent(i: Intent?) {
        if (i == null) return
        val a = i.action
        if (i.getBooleanExtra(EXTRA_ASSIST, false) || a == Intent.ACTION_ASSIST || a == Intent.ACTION_VOICE_COMMAND) {
            i.removeExtra(EXTRA_ASSIST)
            pendingAssist = true
            runPendingAssist()
        }
    }

    // só dispara quando a página já carregou e o app está na frente; senão espera o próximo onResume/onPageFinished
    private fun runPendingAssist() {
        if (!pendingAssist || !pageReady || !resumed) return
        pendingAssist = false
        web.postDelayed({
            if (!isDestroyed) web.evaluateJavascript("window.__cacauAssist&&window.__cacauAssist()", null)
        }, 400)
    }

    // Volume: toque curto muda o volume; segurar abre o modo conversa
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && event != null) {
            if (event.repeatCount == 0) event.startTracking()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            volLong = true
            pendingAssist = true
            runPendingAssist()
            return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (volLong) {
                volLong = false
            } else {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustVolume(
                    if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val js = "(function(){try{if(typeof mode!=='undefined'&&mode==='home')return 'home';back();return 'ok'}catch(e){return 'home'}})()"
        web.evaluateJavascript(js) { v ->
            if (v == null || v.contains("home")) moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidBridge")
        voice.shutdown()
        pool.shutdown()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun keep(on: Boolean) { keepAwake = on }

        // Desligar (Ajustes): fecha o app e tira da lista de recentes
        @JavascriptInterface
        fun shutdown() { runOnUiThread { finishAndRemoveTask() } }

        @JavascriptInterface
        fun api(id: Int, method: String, path: String, body: String) {
            try {
                pool.execute {
                    val r = this@MainActivity.api.handle(method, path, body)
                    val js = "window.__cacauResolve(" + id + "," + r.first + "," + JSONObject.quote(r.second) + ")"
                    runOnUiThread { if (!isDestroyed) web.evaluateJavascript(js, null) }
                }
            } catch (e: Exception) { /* app fechando */ }
        }
    }
}
