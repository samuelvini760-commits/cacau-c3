package br.com.cacau.os

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Segurar o botão de ligar: o Android chama o "assistente digital" escolhido pelo usuário.
 * Ao escolher o Cacau OS nesse lugar (Configurações > Apps > Apps padrão > App assistente digital),
 * este serviço abre o Cacau já ouvindo.
 */
class CacauAssistService : VoiceInteractionService()

class CacauAssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = CacauSession(this)
}

class CacauSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            val i = Intent(context, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra(MainActivity.EXTRA_ASSIST, true)
            startAssistantActivity(i)
        } catch (e: Exception) { }
        finish()
    }
}

/**
 * O Android exige um serviço de reconhecimento declarado junto com o assistente.
 * Este é só uma casca: quem reconhece a fala de verdade é o motor do próprio aparelho (ver Voice.kt).
 */
class CacauRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (e: Exception) { }
    }
    override fun onCancel(listener: Callback?) { }
    override fun onStopListening(listener: Callback?) { }
}

/**
 * Volume segurado (~0,5 s) em qualquer tela, inclusive na tela inicial do celular: abre o Cacau ouvindo.
 * Toque curto continua mudando o volume normalmente.
 * Precisa ser ligado em Configurações > Acessibilidade > Cacau OS.
 */
class VolumeKeyService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var longDone = false
    private val longRun = Runnable {
        longDone = true
        try {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra(MainActivity.EXTRA_ASSIST, true)
            startActivity(i)
        } catch (e: Exception) { }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = serviceInfo ?: return
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k != KeyEvent.KEYCODE_VOLUME_UP && k != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        // tela apagada ou bloqueada: deixa o Android cuidar do volume
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!pm.isInteractive || km.isKeyguardLocked) return false

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                longDone = false
                h.removeCallbacks(longRun)
                h.postDelayed(longRun, 500)
            }
            return true
        }
        if (event.action == KeyEvent.ACTION_UP) {
            h.removeCallbacks(longRun)
            if (!longDone) {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustVolume(
                    if (k == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            longDone = false
            return true
        }
        return true
    }
}
