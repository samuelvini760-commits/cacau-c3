package br.com.cacau.os

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Segurar o botão de ligar: o Android chama o "assistente digital" escolhido pelo usuário.
 * Ao escolher o Cacau OS nesse lugar (Configurações > Apps > Apps padrão > App assistente digital),
 * este serviço abre o Cacau já ouvindo.
 */
class CacauAssistService : VoiceInteractionService()

class CacauAssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = CacauSession(this)
}

class CacauSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            val i = Intent(context, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra(MainActivity.EXTRA_ASSIST, true)
            startAssistantActivity(i)
        } catch (e: Exception) { }
        finish()
    }
}

/**
 * O Android exige um serviço de reconhecimento declarado junto com o assistente.
 * Este é só uma casca: quem reconhece a fala de verdade é o motor do próprio aparelho (ver Voice.kt).
 */
class CacauRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (e: Exception) { }
    }
    override fun onCancel(listener: Callback?) { }
    override fun onStopListening(listener: Callback?) { }
}
