package br.com.cacau.os

import android.content.Context
import android.content.Intent
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import org.json.JSONArray
import org.json.JSONObject

/** Login PKCE do Spotify (retorno em 127.0.0.1) e controle do player pela Web API. */
class Spotify(private val ctx: Context, private val store: Store) {
    private val redirect = "http://127.0.0.1:8888/callback"
    private var server: ServerSocket? = null
    private val scopes = "user-read-playback-state user-modify-playback-state user-read-currently-playing " +
        "playlist-read-private playlist-read-collaborative"

    @Volatile var status: String = ""

    fun connected(): Boolean = store.s("s_refresh").isNotEmpty()

    fun logout() {
        store.remove("s_refresh", "s_access", "s_exp", "s_uid")
        status = ""
    }

    fun loginUrl(): String {
        val cid = store.s("s_client_id")
        if (cid.isEmpty()) throw ApiError(400, "Cole primeiro o Client ID do Spotify e salve.")
        if (!Regex("^[0-9a-fA-F]{32}$").matches(cid)) throw ApiError(400, "O Client ID do Spotify tem 32 letras e números. Copie de novo no painel do desenvolvedor.")
        try { server?.close() } catch (e: Exception) { }
        val ss = ServerSocket()
        try {
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), 8888), 5)
        } catch (e: Exception) {
            throw ApiError(500, "A porta 8888 está ocupada. Feche o app, abra de novo e tente outra vez.")
        }
        ss.soTimeout = 300000
        server = ss
        val verifier = Pkce.random(48)
        val state = Pkce.random(12)
        status = "Aguardando você entrar no navegador…"
        val url = "https://accounts.spotify.com/authorize?" + Http.form(
            linkedMapOf(
                "client_id" to cid,
                "response_type" to "code",
                "redirect_uri" to redirect,
                "scope" to scopes,
                "code_challenge_method" to "S256",
                "code_challenge" to Pkce.challenge(verifier),
                "state" to state
            )
        )
        Thread {
            try {
                val params = Loopback.wait(ss)
                try { ss.close() } catch (e: Exception) { }
                val code = params["code"]
                if (code == null || params["state"] != state) {
                    status = "Erro no login: " + (params["error"] ?: "resposta inválida")
                    return@Thread
                }
                val r = Http.request(
                    "POST", "https://accounts.spotify.com/api/token",
                    mapOf("Content-Type" to "application/x-www-form-urlencoded"),
                    Http.form(
                        linkedMapOf(
                            "grant_type" to "authorization_code",
                            "code" to code,
                            "redirect_uri" to redirect,
                            "client_id" to cid,
                            "code_verifier" to verifier
                        )
                    )
                )
                if (r.code !in 200..299) {
                    status = "Erro no login: " + r.body.take(140)
                    return@Thread
                }
                saveTokens(JSONObject(r.body))
                status = "Conectado"
            } catch (e: Exception) {
                status = "Erro no login: " + (e.message ?: "tempo esgotado")
            }
        }.start()
        return url
    }

    private fun saveTokens(j: JSONObject) {
        store.put("s_access", j.optString("access_token"))
        val rt = j.optString("refresh_token", "")
        if (rt.isNotEmpty()) store.put("s_refresh", rt)
        store.putL("s_exp", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L)
    }

    @Synchronized
    private fun token(): String {
        if (!connected()) throw ApiError(401, "Spotify não conectado.")
        if (store.l("s_exp") - 60000L > System.currentTimeMillis() && store.s("s_access").isNotEmpty()) {
            return store.s("s_access")
        }
        val r = Http.request(
            "POST", "https://accounts.spotify.com/api/token",
            mapOf("Content-Type" to "application/x-www-form-urlencoded"),
            Http.form(
                linkedMapOf(
                    "grant_type" to "refresh_token",
                    "refresh_token" to store.s("s_refresh"),
                    "client_id" to store.s("s_client_id")
                )
            )
        )
        if (r.code !in 200..299) {
            if (r.code == 400 || r.code == 401) {
                logout()
                throw ApiError(401, "O login do Spotify expirou. Entre de novo em Conexões.")
            }
            throw ApiError(502, "Spotify " + r.code)
        }
        saveTokens(JSONObject(r.body))
        return store.s("s_access")
    }

    private fun call(method: String, path: String, body: String? = null): HttpResp =
        Http.request(
            method, "https://api.spotify.com/v1$path",
            mapOf("Authorization" to "Bearer " + token(), "Content-Type" to "application/json"), body
        )

    private fun errText(r: HttpResp): String {
        val raw = try {
            JSONObject(r.body).optJSONObject("error")?.optString("message", "") ?: ""
        } catch (e: Exception) { "" }
        return when {
            r.code == 429 -> "o Spotify pediu para esperar um pouco. Tente em alguns segundos."
            raw.contains("PREMIUM_REQUIRED", true) || raw.contains("Premium", true) -> "o controle do player exige Spotify Premium."
            raw.contains("not registered", true) ->
                "esse e-mail não está liberado no app do Spotify. No painel do desenvolvedor, abra User Management e adicione seu e-mail."
            raw.isNotEmpty() -> raw.take(140)
            else -> "erro " + r.code
        }
    }

    private fun artists(item: JSONObject): String {
        val names = ArrayList<String>()
        val ar = item.optJSONArray("artists") ?: JSONArray()
        for (i in 0 until ar.length()) names.add(ar.getJSONObject(i).optString("name"))
        return names.joinToString(", ")
    }

    private fun imgOf(o: JSONObject?, small: Boolean = false): String {
        val imgs = o?.optJSONArray("images") ?: return ""
        if (imgs.length() == 0) return ""
        // a imagem do meio (~300px) pesa bem menos que a de 640px e basta para a tela pequena
        val i = if (small && imgs.length() > 1) minOf(1, imgs.length() - 1) else 0
        return imgs.getJSONObject(i).optString("url")
    }

    fun state(): JSONObject {
        val out = JSONObject().put("configured", true).put("playing", false).put("active", false)
            .put("volume", JSONObject.NULL).put("track", JSONObject.NULL).put("shuffle", false)
            .put("device", JSONObject.NULL)
        val r = call("GET", "/me/player")
        if (r.code == 204 || r.body.isEmpty()) return out
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val j = JSONObject(r.body)
        out.put("playing", j.optBoolean("is_playing", false)).put("shuffle", j.optBoolean("shuffle_state", false))
        val dev = j.optJSONObject("device")
        if (dev != null) {
            out.put("active", dev.optBoolean("is_active", false))
            out.put("device", JSONObject().put("id", dev.optString("id")).put("name", dev.optString("name")).put("type", dev.optString("type")))
            if (!dev.isNull("volume_percent")) out.put("volume", dev.optInt("volume_percent"))
        }
        val item = j.optJSONObject("item")
        if (item != null) {
            val album = item.optJSONObject("album")
            out.put(
                "track",
                JSONObject().put("id", item.optString("id")).put("uri", item.optString("uri"))
                    .put("name", item.optString("name")).put("artist", artists(item))
                    .put("img", imgOf(album, true)).put("duration_ms", item.optLong("duration_ms"))
                    .put("progress_ms", j.optLong("progress_ms"))
            )
        }
        return out
    }

    private fun myId(): String {
        val cached = store.s("s_uid")
        if (cached.isNotEmpty()) return cached
        val r = call("GET", "/me")
        if (r.code !in 200..299) return ""
        val id = JSONObject(r.body).optString("id", "")
        if (id.isNotEmpty()) store.put("s_uid", id)
        return id
    }

    fun playlists(): JSONArray {
        val r = call("GET", "/me/playlists?limit=40")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val items = JSONObject(r.body).optJSONArray("items") ?: JSONArray()
        val me = myId()
        val out = JSONArray()
        for (i in 0 until items.length()) {
            val p = items.optJSONObject(i) ?: continue
            // desde fev/2026 o Spotify chama isso de "items" (antes "tracks")
            val total = p.optJSONObject("items")?.optInt("total", 0) ?: p.optJSONObject("tracks")?.optInt("total", 0) ?: 0
            // só as playlists suas ou colaborativas deixam listar as músicas
            val mine = me.isEmpty() || p.optJSONObject("owner")?.optString("id") == me || p.optBoolean("collaborative", false)
            out.put(
                JSONObject().put("uri", p.optString("uri")).put("id", p.optString("id")).put("name", p.optString("name"))
                    .put("img", imgOf(p, true)).put("tracks", total).put("listable", mine)
            )
        }
        return out
    }

    /** Músicas de uma playlist, para listar dentro do Cacau (sem abrir o app do Spotify). */
    fun tracks(uri: String, offset: Int): JSONObject {
        val id = uri.substringAfterLast(":")
        if (id.isEmpty()) throw ApiError(400, "playlist inválida")
        val fields = Http.enc("items(item(uri,name,duration_ms,artists(name)),track(uri,name,duration_ms,artists(name))),total,next")
        var r = call("GET", "/playlists/$id/items?limit=40&offset=$offset&additional_types=track&fields=$fields")
        if (r.code == 404 || r.code == 400) r = call("GET", "/playlists/$id/tracks?limit=40&offset=$offset&fields=$fields")
        if (r.code == 403 || r.code == 404) {
            return JSONObject().put("items", JSONArray()).put("total", 0).put("restricted", true)
        }
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val j = JSONObject(r.body)
        val arr = j.optJSONArray("items") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val row = arr.optJSONObject(i) ?: continue
            val t = row.optJSONObject("item") ?: row.optJSONObject("track") ?: continue
            val tu = t.optString("uri", "")
            if (!tu.startsWith("spotify:track:")) continue
            out.put(JSONObject().put("uri", tu).put("name", t.optString("name")).put("artist", artists(t)).put("ms", t.optLong("duration_ms")))
        }
        return JSONObject().put("items", out).put("total", j.optInt("total", out.length()))
            .put("restricted", arr.length() == 0 && !j.has("total"))
            .put("next", !j.isNull("next") && j.has("next"))
    }

    fun devices(): JSONArray {
        val r = call("GET", "/me/player/devices")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val arr = JSONObject(r.body).optJSONArray("devices") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val d = arr.getJSONObject(i)
            out.put(
                JSONObject().put("id", d.optString("id")).put("name", d.optString("name")).put("type", d.optString("type"))
                    .put("active", d.optBoolean("is_active", false))
            )
        }
        return out
    }

    fun transfer(id: String, play: Boolean) {
        val body = JSONObject().put("device_ids", JSONArray().put(id)).put("play", play)
        val r = call("PUT", "/me/player", body.toString())
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
    }


    /** Busca por nome para a tela do Spotify: devolve músicas e artistas para a pessoa escolher. */
    fun search(q0: String): JSONObject {
        val q = q0.trim()
        if (q.isEmpty()) throw ApiError(400, "Digite o nome da música ou do artista.")
        val enc = java.net.URLEncoder.encode(q, "UTF-8")
        val r = call("GET", "/search?q=$enc&type=track,artist&limit=8")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val j = JSONObject(r.body)
        val tr = j.optJSONObject("tracks")?.optJSONArray("items") ?: JSONArray()
        val ar = j.optJSONObject("artists")?.optJSONArray("items") ?: JSONArray()
        val tracks = JSONArray()
        for (i in 0 until tr.length()) {
            val t = tr.optJSONObject(i) ?: continue
            tracks.put(
                JSONObject().put("name", t.optString("name")).put("artist", artists(t)).put("uri", t.optString("uri"))
                    .put("ms", t.optInt("duration_ms", 0)).put("img", imgOf(t.optJSONObject("album"), true))
            )
        }
        val artistsOut = JSONArray()
        for (i in 0 until ar.length()) {
            val a = ar.optJSONObject(i) ?: continue
            artistsOut.put(JSONObject().put("name", a.optString("name")).put("uri", a.optString("uri")).put("img", imgOf(a, true)))
        }
        return JSONObject().put("tracks", tracks).put("artists", artistsOut)
    }

    private fun fold(t: String): String =
        java.text.Normalizer.normalize(t.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun overlap(q: String, name: String): Double {
        val a = fold(q).split(" ").filter { it.isNotEmpty() }.toSet()
        val b = fold(name).split(" ").filter { it.isNotEmpty() }.toSet()
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return a.intersect(b).size.toDouble() / a.size
    }

    /**
     * Procura por nome (música, artista ou "música do artista") e toca o melhor resultado.
     * Devolve o que está tocando para a Cacau falar. Aceita "música - artista" e "música do artista".
     */
    fun searchPlay(q0: String): JSONObject {
        val q = q0.trim()
        if (q.isEmpty()) throw ApiError(400, "Qual música?")
        val enc = java.net.URLEncoder.encode(q, "UTF-8")
        var r = call("GET", "/search?q=$enc&type=track,artist&limit=5")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        var j = JSONObject(r.body)
        var tracks = j.optJSONObject("tracks")?.optJSONArray("items") ?: JSONArray()
        var arts = j.optJSONObject("artists")?.optJSONArray("items") ?: JSONArray()
        // "música do artista": tenta de novo com os dois pedaços separados
        if (tracks.length() == 0) {
            val m = Regex("^(.+?)\\s+(?:de|do|da|dos|das|por|-)\\s+(.+)$", RegexOption.IGNORE_CASE).find(q)
            if (m != null) {
                val q2 = java.net.URLEncoder.encode("track:" + m.groupValues[1] + " artist:" + m.groupValues[2], "UTF-8")
                r = call("GET", "/search?q=$q2&type=track&limit=5")
                if (r.code in 200..299) tracks = JSONObject(r.body).optJSONObject("tracks")?.optJSONArray("items") ?: JSONArray()
            }
        }
        var bestTrack: JSONObject? = null
        var bestScore = 0.0
        for (i in 0 until tracks.length()) {
            val t = tracks.getJSONObject(i)
            val sc = overlap(q, t.optString("name") + " " + artists(t)) + (if (i == 0) 0.05 else 0.0)
            if (sc > bestScore) { bestScore = sc; bestTrack = t }
        }
        var bestArtist: JSONObject? = null
        var artistScore = 0.0
        for (i in 0 until arts.length()) {
            val a = arts.getJSONObject(i)
            val sc = overlap(q, a.optString("name"))
            if (sc > artistScore) { artistScore = sc; bestArtist = a }
        }
        // pedido só com o nome do artista: toca o artista; senão, a música
        val useArtist = bestArtist != null && artistScore >= 0.99 && (bestTrack == null || overlap(q, bestTrack.optString("name")) < 0.5)
        val uri: String
        val say: String
        if (useArtist && bestArtist != null) {
            uri = bestArtist.optString("uri"); say = "Tocando " + bestArtist.optString("name") + "."
        } else if (bestTrack != null) {
            uri = bestTrack.optString("uri"); say = "Tocando " + bestTrack.optString("name") + ", de " + artists(bestTrack) + "."
        } else {
            throw ApiError(404, "Não achei \"" + q + "\" no Spotify.")
        }
        control(JSONObject().put("action", "play").put("uri", uri))
        return JSONObject().put("ok", true).put("say", say).put("uri", uri)
    }

    /** action: play | pause | next | prev | volume (value) | shuffle (value 0/1). "play" aceita uri, offset_uri e shuffle. */
    fun control(j: JSONObject) {
        val action = j.optString("action")
        if (action == "play" && j.has("shuffle")) call("PUT", "/me/player/shuffle?state=" + j.optBoolean("shuffle", false))
        var r = send(action, j)
        if (r.code == 404 || (r.code == 403 && r.body.contains("NO_ACTIVE_DEVICE"))) {
            // não abre o app do Spotify à força: tenta ligar um aparelho que já existe e, se não houver, avisa a tela
            if (!wakeDevice()) throw ApiError(409, "Nenhum aparelho do Spotify está ligado agora.")
            Thread.sleep(700)
            r = send(action, j)
        }
        if (r.code == 403) throw ApiError(403, errText(r))
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
    }

    private fun send(action: String, j: JSONObject): HttpResp = when (action) {
        "pause" -> call("PUT", "/me/player/pause")
        "next" -> call("POST", "/me/player/next")
        "prev" -> call("POST", "/me/player/previous")
        "volume" -> call("PUT", "/me/player/volume?volume_percent=" + j.optInt("value", 50))
        "shuffle" -> call("PUT", "/me/player/shuffle?state=" + (j.optInt("value", 0) == 1))
        else -> {
            val uri = j.optString("uri", "")
            val b = JSONObject()
            if (uri.startsWith("spotify:track:")) b.put("uris", JSONArray().put(uri))
            else if (uri.isNotEmpty()) {
                b.put("context_uri", uri)
                val off = j.optString("offset_uri", "")
                if (off.isNotEmpty()) b.put("offset", JSONObject().put("uri", off))
            }
            call("PUT", "/me/player/play", if (b.length() > 0) b.toString() else "")
        }
    }

    private fun wakeDevice(): Boolean {
        val r = call("GET", "/me/player/devices")
        if (r.code !in 200..299) return false
        val arr = JSONObject(r.body).optJSONArray("devices") ?: return false
        if (arr.length() == 0) return false
        var pick = arr.getJSONObject(0)
        for (i in 0 until arr.length()) {
            val d = arr.getJSONObject(i)
            if (d.optString("type").equals("Smartphone", true)) { pick = d; break }
        }
        val body = JSONObject().put("device_ids", JSONArray().put(pick.getString("id"))).put("play", false)
        return call("PUT", "/me/player", body.toString()).code in 200..299
    }

    /** Só por pedido explícito do usuário (botão "Abrir Spotify"). */
    fun openSpotifyApp(): Boolean {
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.spotify.music") ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) { false }
    }
}
