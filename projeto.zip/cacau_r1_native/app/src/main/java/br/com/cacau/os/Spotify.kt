package br.com.cacau.os

import android.content.Context
import android.content.Intent
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import org.json.JSONArray
import org.json.JSONObject

/** Login PKCE do Spotify (retorno em 127.0.0.1) e controle do player pela Web API. */
class Spotify(private val ctx: Context, private val store: Store) {
    private val redirect = "http://127.0.0.1:8888/callback"
    private var server: ServerSocket? = null
    private val scopes = "user-read-playback-state user-modify-playback-state user-read-currently-playing " +
        "playlist-read-private playlist-read-collaborative streaming user-read-email user-read-private"

    @Volatile var status: String = ""

    fun connected(): Boolean = store.s("s_refresh").isNotEmpty()

    fun logout() {
        store.remove("s_refresh", "s_access", "s_exp", "s_uid", "s_scope", "s_dev")
        lastState = null
        status = ""
    }

    fun loginUrl(): String {
        val cid = store.s("s_client_id")
        if (cid.isEmpty()) throw ApiError(400, "Cole primeiro o Client ID do Spotify e salve.")
        if (!Regex("^[0-9a-fA-F]{32}$").matches(cid)) throw ApiError(400, "O Client ID do Spotify tem 32 letras e números. Copie de novo no painel do desenvolvedor.")
        try { server?.close() } catch (e: Exception) { }
        val ss = ServerSocket()
        try {
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), 8888), 5)
        } catch (e: Exception) {
            throw ApiError(500, "A porta 8888 está ocupada. Feche o app, abra de novo e tente outra vez.")
        }
        ss.soTimeout = 300000
        server = ss
        val verifier = Pkce.random(48)
        val state = Pkce.random(12)
        status = "Aguardando você entrar no navegador…"
        val url = "https://accounts.spotify.com/authorize?" + Http.form(
            linkedMapOf(
                "client_id" to cid,
                "response_type" to "code",
                "redirect_uri" to redirect,
                "scope" to scopes,
                "code_challenge_method" to "S256",
                "code_challenge" to Pkce.challenge(verifier),
                "state" to state
            )
        )
        Thread {
            try {
                val params = Loopback.wait(ss)
                try { ss.close() } catch (e: Exception) { }
                val code = params["code"]
                if (code == null || params["state"] != state) {
                    status = "Erro no login: " + (params["error"] ?: "resposta inválida")
                    return@Thread
                }
                val r = Http.request(
                    "POST", "https://accounts.spotify.com/api/token",
                    mapOf("Content-Type" to "application/x-www-form-urlencoded"),
                    Http.form(
                        linkedMapOf(
                            "grant_type" to "authorization_code",
                            "code" to code,
                            "redirect_uri" to redirect,
                            "client_id" to cid,
                            "code_verifier" to verifier
                        )
                    )
                )
                if (r.code !in 200..299) {
                    status = "Erro no login: " + r.body.take(140)
                    return@Thread
                }
                saveTokens(JSONObject(r.body))
                status = "Conectado"
            } catch (e: Exception) {
                status = "Erro no login: " + (e.message ?: "tempo esgotado")
            }
        }.start()
        return url
    }

    private fun saveTokens(j: JSONObject) {
        store.put("s_access", j.optString("access_token"))
        val rt = j.optString("refresh_token", "")
        if (rt.isNotEmpty()) store.put("s_refresh", rt)
        val sc = j.optString("scope", "")
        if (sc.isNotEmpty()) store.put("s_scope", sc)
        store.putL("s_exp", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L)
    }

    /**
     * Token de acesso. O login só é apagado quando o Spotify diz que ele foi revogado (invalid_grant);
     * falha de internet ou erro passageiro mantém o login e tenta de novo.
     */
    @Synchronized
    private fun token(force: Boolean = false): String {
        if (!connected()) throw ApiError(401, "Spotify não conectado.")
        if (!force && store.l("s_exp") - 60000L > System.currentTimeMillis() && store.s("s_access").isNotEmpty()) {
            return store.s("s_access")
        }
        for (attempt in 0 until 3) {
            try {
                val r = Http.request(
                    "POST", "https://accounts.spotify.com/api/token",
                    mapOf("Content-Type" to "application/x-www-form-urlencoded"),
                    Http.form(
                        linkedMapOf(
                            "grant_type" to "refresh_token",
                            "refresh_token" to store.s("s_refresh"),
                            "client_id" to store.s("s_client_id")
                        )
                    )
                )
                if (r.code in 200..299) {
                    saveTokens(JSONObject(r.body))
                    return store.s("s_access")
                }
                val err = try { JSONObject(r.body).optString("error") } catch (e: Exception) { "" }
                if ((r.code == 400 || r.code == 401) && err == "invalid_grant") {
                    logout()
                    throw ApiError(401, "O login do Spotify expirou. Entre de novo em Conexões.")
                }
                if (r.code < 500 && r.code != 429) break
            } catch (e: ApiError) {
                throw e
            } catch (e: Exception) {
                // sem internet agora: tenta de novo
            }
            try { Thread.sleep(500L * (attempt + 1)) } catch (e: InterruptedException) { }
        }
        val old = store.s("s_access")
        if (!force && old.isNotEmpty()) return old
        throw ApiError(503, "Sem conexão com o Spotify agora. Tento de novo sozinho.")
    }

    private fun raw(method: String, path: String, body: String?, force: Boolean): HttpResp {
        for (i in 0 until 2) {
            try {
                return Http.request(
                    method, "https://api.spotify.com/v1$path",
                    mapOf("Authorization" to "Bearer " + token(force), "Content-Type" to "application/json"), body
                )
            } catch (e: ApiError) {
                throw e
            } catch (e: java.io.IOException) {
                try { Thread.sleep(500) } catch (ie: InterruptedException) { }
            }
        }
        throw ApiError(503, "Sem internet para falar com o Spotify.")
    }

    /** 401 renova o token e repete; 429/5xx esperam um pouco e repetem uma vez. */
    private fun call(method: String, path: String, body: String? = null): HttpResp {
        var r = raw(method, path, body, false)
        if (r.code == 401) r = raw(method, path, body, true)
        if (r.code == 429 || r.code in 500..599) {
            try { Thread.sleep(1000) } catch (e: InterruptedException) { }
            r = raw(method, path, body, false)
        }
        return r
    }

    private fun errText(r: HttpResp): String {
        val raw = try {
            JSONObject(r.body).optJSONObject("error")?.optString("message", "") ?: ""
        } catch (e: Exception) { "" }
        return when {
            r.code == 429 -> "o Spotify pediu para esperar um pouco. Tente em alguns segundos."
            raw.contains("PREMIUM_REQUIRED", true) || raw.contains("Premium", true) -> "o controle do player exige Spotify Premium."
            raw.contains("not registered", true) ->
                "esse e-mail não está liberado no app do Spotify. No painel do desenvolvedor, abra User Management e adicione seu e-mail."
            raw.isNotEmpty() -> raw.take(140)
            else -> "erro " + r.code
        }
    }

    private fun artists(item: JSONObject): String {
        val names = ArrayList<String>()
        val ar = item.optJSONArray("artists") ?: JSONArray()
        for (i in 0 until ar.length()) names.add(ar.getJSONObject(i).optString("name"))
        return names.joinToString(", ")
    }

    private fun imgOf(o: JSONObject?, small: Boolean = false): String {
        val imgs = o?.optJSONArray("images") ?: return ""
        if (imgs.length() == 0) return ""
        // a imagem do meio (~300px) pesa bem menos que a de 640px e basta para a tela pequena
        val i = if (small && imgs.length() > 1) minOf(1, imgs.length() - 1) else 0
        return imgs.getJSONObject(i).optString("url")
    }

    fun state(): JSONObject {
        val out = JSONObject().put("configured", true).put("playing", false).put("active", false)
            .put("volume", JSONObject.NULL).put("track", JSONObject.NULL).put("shuffle", false)
            .put("device", JSONObject.NULL)
        val r = call("GET", "/me/player")
        if (r.code == 204 || r.body.isEmpty()) { lastState = out; return out }
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val j = JSONObject(r.body)
        out.put("playing", j.optBoolean("is_playing", false)).put("shuffle", j.optBoolean("shuffle_state", false))
        val dev = j.optJSONObject("device")
        if (dev != null) {
            out.put("active", dev.optBoolean("is_active", false))
            if (dev.optBoolean("is_active", false) && dev.optString("id").isNotEmpty()) store.put("s_dev", dev.optString("id"))
            out.put("device", JSONObject().put("id", dev.optString("id")).put("name", dev.optString("name")).put("type", dev.optString("type")))
            if (!dev.isNull("volume_percent")) out.put("volume", dev.optInt("volume_percent"))
        }
        val item = j.optJSONObject("item")
        if (item != null) {
            val album = item.optJSONObject("album")
            out.put(
                "track",
                JSONObject().put("id", item.optString("id")).put("uri", item.optString("uri"))
                    .put("name", item.optString("name")).put("artist", artists(item))
                    .put("img", imgOf(album, true)).put("duration_ms", item.optLong("duration_ms"))
                    .put("progress_ms", j.optLong("progress_ms"))
            )
        }
        lastState = out
        return out
    }

    @Volatile private var lastState: JSONObject? = null
    /** Último estado bom: se o Spotify falhar por um instante, a tela continua mostrando o que tocava em vez de "desconectado". */
    fun cachedState(): JSONObject? = lastState

    // ---- Cacau como aparelho Spotify (Web Playback SDK dentro da própria tela do app) ----
    @Volatile var webDevId: String = ""
    @Volatile var webPending: Boolean = false
    @Volatile var webError: String = ""

    fun webToken(): JSONObject =
        JSONObject().put("token", token()).put("streaming", store.s("s_scope").contains("streaming"))

    fun webDevice(j: JSONObject) {
        if (j.has("id")) { webDevId = j.optString("id"); webPending = false; webError = "" }
        if (j.has("pending")) webPending = j.optBoolean("pending")
        if (j.has("error")) { webError = j.optString("error"); webPending = false; webDevId = "" }
        if (j.optBoolean("gone", false)) webDevId = ""
    }

    private fun myId(): String {
        val cached = store.s("s_uid")
        if (cached.isNotEmpty()) return cached
        val r = call("GET", "/me")
        if (r.code !in 200..299) return ""
        val id = JSONObject(r.body).optString("id", "")
        if (id.isNotEmpty()) store.put("s_uid", id)
        return id
    }

    fun playlists(): JSONArray {
        val r = call("GET", "/me/playlists?limit=40")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val items = JSONObject(r.body).optJSONArray("items") ?: JSONArray()
        val me = myId()
        val out = JSONArray()
        try {
            val names = JSONArray()
            for (i in 0 until items.length()) { val n = items.optJSONObject(i)?.optString("name") ?: ""; if (n.isNotBlank()) names.put(n) }
            store.put("s_plnames", names.toString())
        } catch (e: Exception) { }
        for (i in 0 until items.length()) {
            val p = items.optJSONObject(i) ?: continue
            // desde fev/2026 o Spotify chama isso de "items" (antes "tracks")
            val total = p.optJSONObject("items")?.optInt("total", 0) ?: p.optJSONObject("tracks")?.optInt("total", 0) ?: 0
            // só as playlists suas ou colaborativas deixam listar as músicas
            val mine = me.isEmpty() || p.optJSONObject("owner")?.optString("id") == me || p.optBoolean("collaborative", false)
            out.put(
                JSONObject().put("uri", p.optString("uri")).put("id", p.optString("id")).put("name", p.optString("name"))
                    .put("img", imgOf(p, true)).put("tracks", total).put("listable", mine)
            )
        }
        return out
    }

    /** Músicas de uma playlist, para listar dentro do Cacau (sem abrir o app do Spotify). */
    fun tracks(uri: String, offset: Int): JSONObject {
        val id = uri.substringAfterLast(":")
        if (id.isEmpty()) throw ApiError(400, "playlist inválida")
        val fields = Http.enc("items(item(uri,name,duration_ms,artists(name)),track(uri,name,duration_ms,artists(name))),total,next")
        var r = call("GET", "/playlists/$id/items?limit=40&offset=$offset&additional_types=track&fields=$fields")
        if (r.code == 404 || r.code == 400) r = call("GET", "/playlists/$id/tracks?limit=40&offset=$offset&fields=$fields")
        if (r.code == 403 || r.code == 404) {
            return JSONObject().put("items", JSONArray()).put("total", 0).put("restricted", true)
        }
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val j = JSONObject(r.body)
        val arr = j.optJSONArray("items") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val row = arr.optJSONObject(i) ?: continue
            val t = row.optJSONObject("item") ?: row.optJSONObject("track") ?: continue
            val tu = t.optString("uri", "")
            if (!tu.startsWith("spotify:track:")) continue
            out.put(JSONObject().put("uri", tu).put("name", t.optString("name")).put("artist", artists(t)).put("ms", t.optLong("duration_ms")))
        }
        return JSONObject().put("items", out).put("total", j.optInt("total", out.length()))
            .put("restricted", arr.length() == 0 && !j.has("total"))
            .put("next", !j.isNull("next") && j.has("next"))
    }

    fun devices(): JSONArray {
        val r = call("GET", "/me/player/devices")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val arr = JSONObject(r.body).optJSONArray("devices") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val d = arr.getJSONObject(i)
            out.put(
                JSONObject().put("id", d.optString("id")).put("name", d.optString("name")).put("type", d.optString("type"))
                    .put("active", d.optBoolean("is_active", false))
            )
        }
        return out
    }

    fun transfer(id: String, play: Boolean) {
        val body = JSONObject().put("device_ids", JSONArray().put(id)).put("play", play)
        val r = call("PUT", "/me/player", body.toString())
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
    }


    /** Busca por nome para a tela do Spotify: devolve músicas e artistas para a pessoa escolher. */
    fun search(q0: String): JSONObject {
        val q = q0.trim()
        if (q.isEmpty()) throw ApiError(400, "Digite o nome da música ou do artista.")
        val enc = java.net.URLEncoder.encode(q, "UTF-8")
        val r = call("GET", "/search?q=$enc&type=track,artist&limit=8")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val j = JSONObject(r.body)
        val tr = j.optJSONObject("tracks")?.optJSONArray("items") ?: JSONArray()
        val ar = j.optJSONObject("artists")?.optJSONArray("items") ?: JSONArray()
        val tracks = JSONArray()
        for (i in 0 until tr.length()) {
            val t = tr.optJSONObject(i) ?: continue
            tracks.put(
                JSONObject().put("name", t.optString("name")).put("artist", artists(t)).put("uri", t.optString("uri"))
                    .put("ms", t.optInt("duration_ms", 0)).put("img", imgOf(t.optJSONObject("album"), true))
            )
        }
        val artistsOut = JSONArray()
        for (i in 0 until ar.length()) {
            val a = ar.optJSONObject(i) ?: continue
            artistsOut.put(JSONObject().put("name", a.optString("name")).put("uri", a.optString("uri")).put("img", imgOf(a, true)))
        }
        return JSONObject().put("tracks", tracks).put("artists", artistsOut)
    }

    // ---------------- entendimento de nomes: some acentos, erros de som e sotaque ----------------
    private fun fold(t: String): String =
        java.text.Normalizer.normalize(t.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** "Som" aproximado da palavra (português e inglês viram quase a mesma coisa): teim impala ~ tame impala. */
    private fun phon(s: String): String {
        val words = fold(s).split(" ").filter { it.isNotEmpty() }
        return words.joinToString("") { w0 ->
            var w = w0.replace("ph", "f").replace("th", "t").replace("ck", "k").replace("qu", "k")
                .replace("sh", "x").replace("ch", "x").replace("lh", "l").replace("nh", "n")
                .replace("ou", "u").replace("oo", "u").replace("ee", "i").replace("ey", "e").replace("ay", "e")
                .replace("ai", "e").replace("ei", "e").replace("w", "u").replace("y", "i")
            w = Regex("c(?=[ei])").replace(w, "s").replace("c", "k").replace("z", "s").replace("h", "")
            w = Regex("(.)\\1+").replace(w, "$1")
            if (w.length > 1) w = w[0] + w.substring(1).replace(Regex("[aeiou]"), "")
            w
        }
    }

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun sim(a: String, b: String): Double =
        if (a.isEmpty() || b.isEmpty()) 0.0 else 1.0 - lev(a, b).toDouble() / maxOf(a.length, b.length)

    /** 0..1: o quanto o que você falou se parece com este nome (letra por letra, palavra por palavra e pelo som). */
    private fun score(q: String, name: String): Double {
        val fq = fold(q)
        val fn = fold(name)
        if (fq.isEmpty() || fn.isEmpty()) return 0.0
        val whole = maxOf(sim(fq, fn), sim(phon(q), phon(name)))
        val qw = fq.split(" ").filter { it.isNotEmpty() }
        val nw = fn.split(" ").filter { it.isNotEmpty() }
        var tokens = 0.0
        if (qw.isNotEmpty() && nw.isNotEmpty()) {
            tokens = qw.sumOf { w -> nw.maxOf { x -> maxOf(sim(w, x), sim(phon(w), phon(x))) } } / qw.size
        }
        return maxOf(whole, tokens * 0.95)
    }

    private val junk = Regex("karaoke|cover|tribute|tributo|instrumental|versao|version|remix|sped up|slowed|nightcore|8d|lofi|lo fi")

    private fun rememberPlayed(vararg names: String) {
        try {
            val cur = try { JSONArray(store.s("s_hist")) } catch (e: Exception) { JSONArray() }
            val list = ArrayList<String>()
            for (n in names) if (n.isNotBlank()) list.add(n.trim())
            for (i in 0 until cur.length()) { val v = cur.optString(i); if (v.isNotBlank() && list.none { it.equals(v, true) }) list.add(v) }
            val out = JSONArray()
            for (v in list.take(80)) out.put(v)
            store.put("s_hist", out.toString())
        } catch (e: Exception) { }
    }

    /** Palavras para o reconhecimento de voz priorizar: o que você já tocou e os nomes das suas playlists. */
    fun biasWords(): List<String> {
        val out = ArrayList<String>()
        try { val a = JSONArray(store.s("s_hist")); for (i in 0 until a.length()) out.add(a.optString(i)) } catch (e: Exception) { }
        try { val a = JSONArray(store.s("s_plnames")); for (i in 0 until a.length()) out.add(a.optString(i)) } catch (e: Exception) { }
        return out.filter { it.isNotBlank() && it.length < 60 }.distinct().take(100)
    }

    private fun trackJson(t: JSONObject): JSONObject =
        JSONObject().put("name", t.optString("name")).put("artist", artists(t)).put("uri", t.optString("uri"))
            .put("ms", t.optInt("duration_ms", 0)).put("img", imgOf(t.optJSONObject("album"), true))

    /**
     * Procura por nome e toca o melhor resultado. Recebe vários jeitos de escrever o pedido (as alternativas do
     * reconhecimento de voz), junta os resultados de todos e escolhe pelo que mais combina em letras e em som.
     * Se não tiver certeza, devolve as opções para você escolher na tela em vez de tocar a música errada.
     */
    fun searchPlay(queries: List<String>): JSONObject {
        val qs = queries.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(5)
        if (qs.isEmpty()) throw ApiError(400, "Qual música?")
        val trackPool = LinkedHashMap<String, JSONObject>()
        val artistPool = LinkedHashMap<String, JSONObject>()
        var firstError: ApiError? = null
        fun pull(path: String) {
            val r = call("GET", path)
            if (r.code !in 200..299) { if (firstError == null) firstError = ApiError(502, "Spotify: " + errText(r)); return }
            val j = JSONObject(r.body)
            val tr = j.optJSONObject("tracks")?.optJSONArray("items") ?: JSONArray()
            for (i in 0 until tr.length()) { val t = tr.optJSONObject(i) ?: continue; trackPool.putIfAbsent(t.optString("uri"), t) }
            val ar = j.optJSONObject("artists")?.optJSONArray("items") ?: JSONArray()
            for (i in 0 until ar.length()) { val a = ar.optJSONObject(i) ?: continue; artistPool.putIfAbsent(a.optString("uri"), a) }
        }
        for ((i, q) in qs.withIndex()) {
            pull("/search?q=" + Http.enc(q) + "&type=track,artist&limit=" + (if (i == 0) 8 else 5))
            // "música do artista": também tenta com os dois pedaços separados
            val m = Regex("^(.+?)\\s+(?:de|do|da|dos|das|por|-)\\s+(.+)$", RegexOption.IGNORE_CASE).find(q)
            if (m != null && i < 2) pull("/search?q=" + Http.enc("track:" + m.groupValues[1] + " artist:" + m.groupValues[2]) + "&type=track&limit=5")
            // pedido sem acento nem vírgula costuma ajudar o Spotify
            val plain = fold(q)
            if (plain != q.lowercase() && i == 0) pull("/search?q=" + Http.enc(plain) + "&type=track,artist&limit=5")
        }
        if (trackPool.isEmpty() && artistPool.isEmpty()) {
            val e = firstError
            if (e != null) throw e
            throw ApiError(404, "Não achei \"" + qs[0] + "\" no Spotify.")
        }
        val wantsJunk = qs.any { junk.containsMatchIn(fold(it)) }
        var bestTrack: JSONObject? = null
        var bestScore = 0.0
        for (t in trackPool.values) {
            val nm = t.optString("name")
            val full = nm + " " + artists(t)
            var sc = 0.0
            for (q in qs) sc = maxOf(sc, score(q, nm), score(q, full) * 0.97)
            sc += t.optInt("popularity", 0) * 0.0012
            if (!wantsJunk && junk.containsMatchIn(fold(nm + " " + t.optJSONObject("album")?.optString("name", ""))) ) sc -= 0.12
            if (sc > bestScore) { bestScore = sc; bestTrack = t }
        }
        var bestArtist: JSONObject? = null
        var artistScore = 0.0
        for (a in artistPool.values) {
            var sc = 0.0
            for (q in qs) sc = maxOf(sc, score(q, a.optString("name")))
            sc += a.optInt("popularity", 0) * 0.0006
            if (sc > artistScore) { artistScore = sc; bestArtist = a }
        }
        val bt = bestTrack
        val ba = bestArtist
        val trackTitleScore = if (bt == null) 0.0 else qs.maxOf { score(it, bt.optString("name")) }
        val useArtist = ba != null && artistScore >= 0.85 && (bt == null || trackTitleScore < 0.7 || artistScore > bestScore + 0.05)
        val uri: String
        val say: String
        if (useArtist && ba != null) {
            uri = ba.optString("uri"); say = "Tocando " + ba.optString("name") + "."
            rememberPlayed(ba.optString("name"))
        } else if (bt != null && bestScore >= 0.55) {
            uri = bt.optString("uri"); say = "Tocando " + bt.optString("name") + ", de " + artists(bt) + "."
            rememberPlayed(bt.optString("name"), artists(bt).substringBefore(","))
        } else {
            // sem certeza: não toca a coisa errada; devolve opções para escolher
            val tracks = JSONArray()
            trackPool.values.sortedByDescending { t -> qs.maxOf { score(it, t.optString("name") + " " + artists(t)) } }
                .take(6).forEach { tracks.put(trackJson(it)) }
            val arts = JSONArray()
            artistPool.values.sortedByDescending { a -> qs.maxOf { score(it, a.optString("name")) } }.take(3).forEach {
                arts.put(JSONObject().put("name", it.optString("name")).put("uri", it.optString("uri")).put("img", imgOf(it, true)))
            }
            return JSONObject().put("ok", false).put("uncertain", true).put("q", qs[0]).put("tracks", tracks).put("artists", arts)
        }
        control(JSONObject().put("action", "play").put("uri", uri))
        return JSONObject().put("ok", true).put("say", say).put("uri", uri)
    }

    /** action: play | pause | next | prev | volume (value) | shuffle (value 0/1). "play" aceita uri, offset_uri e shuffle. */
    fun control(j: JSONObject) {
        val action = j.optString("action")
        if (action == "play" && j.has("shuffle")) call("PUT", "/me/player/shuffle?state=" + j.optBoolean("shuffle", false))
        var r = send(action, j)
        var tries = 0
        while ((r.code == 404 || (r.code == 403 && r.body.contains("NO_ACTIVE_DEVICE"))) && tries < 3) {
            tries++
            // sem aparelho ativo: liga o último usado, o próprio Cacau ou o celular; se o Cacau ainda está subindo, espera
            var woke = wakeDevice()
            var waited = 0
            while (!woke && tries == 1 && (webPending || webDevId.isEmpty() && webError.isEmpty() && store.s("s_scope").contains("streaming")) && waited < 8) {
                try { Thread.sleep(1000) } catch (e: InterruptedException) { }
                waited++
                woke = wakeDevice()
            }
            if (!woke) throw ApiError(409, "Nenhum aparelho do Spotify está ligado agora.")
            try { Thread.sleep(800) } catch (e: InterruptedException) { }
            r = send(action, j)
        }
        if (r.code == 403) throw ApiError(403, errText(r))
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
    }

    private fun send(action: String, j: JSONObject): HttpResp = when (action) {
        "pause" -> call("PUT", "/me/player/pause")
        "next" -> call("POST", "/me/player/next")
        "prev" -> call("POST", "/me/player/previous")
        "volume" -> call("PUT", "/me/player/volume?volume_percent=" + j.optInt("value", 50))
        "shuffle" -> call("PUT", "/me/player/shuffle?state=" + (j.optInt("value", 0) == 1))
        else -> {
            val uri = j.optString("uri", "")
            val b = JSONObject()
            if (uri.startsWith("spotify:track:")) b.put("uris", JSONArray().put(uri))
            else if (uri.isNotEmpty()) {
                b.put("context_uri", uri)
                val off = j.optString("offset_uri", "")
                if (off.isNotEmpty()) b.put("offset", JSONObject().put("uri", off))
            }
            call("PUT", "/me/player/play", if (b.length() > 0) b.toString() else "")
        }
    }

    private fun wakeDevice(): Boolean {
        val r = call("GET", "/me/player/devices")
        if (r.code !in 200..299) return false
        val arr = JSONObject(r.body).optJSONArray("devices") ?: return false
        if (arr.length() == 0) return false
        val all = ArrayList<JSONObject>()
        for (i in 0 until arr.length()) all.add(arr.getJSONObject(i))
        val last = store.s("s_dev")
        val order = ArrayList<JSONObject>()
        fun add(d: JSONObject?) { if (d != null && order.none { it.optString("id") == d.optString("id") }) order.add(d) }
        add(all.firstOrNull { it.optBoolean("is_active", false) })
        if (last.isNotEmpty()) add(all.firstOrNull { it.optString("id") == last })
        if (webDevId.isNotEmpty()) add(all.firstOrNull { it.optString("id") == webDevId })
        all.filter { it.optString("type").equals("Smartphone", true) }.forEach { add(it) }
        all.forEach { add(it) }
        for (d in order) {
            val id = d.optString("id")
            if (id.isEmpty()) continue
            val body = JSONObject().put("device_ids", JSONArray().put(id)).put("play", false)
            if (call("PUT", "/me/player", body.toString()).code in 200..299) { store.put("s_dev", id); return true }
        }
        return false
    }

    /** Só por pedido explícito do usuário (botão "Abrir Spotify"). */
    fun openSpotifyApp(): Boolean {
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.spotify.music") ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) { false }
    }
}
