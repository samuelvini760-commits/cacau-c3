package br.com.cacau.os

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Login PKCE do Spotify (retorno por cacau://spotify) e controle do player pela Web API. */
class Spotify(private val ctx: Context, private val store: Store) {
    private val redirect = "cacau://spotify"
    private val scopes = "user-read-playback-state user-modify-playback-state user-read-currently-playing " +
        "playlist-read-private playlist-read-collaborative"

    @Volatile var status: String = ""

    fun connected(): Boolean = store.s("s_refresh").isNotEmpty()

    fun logout() {
        store.remove("s_refresh", "s_access", "s_exp")
        status = ""
    }

    fun loginUrl(): String {
        val cid = store.s("s_client_id")
        if (cid.isEmpty()) throw ApiError(400, "Cole primeiro o Client ID do Spotify e salve.")
        val verifier = Pkce.random(48)
        val state = Pkce.random(12)
        store.put("s_verifier", verifier)
        store.put("s_state", state)
        status = "Aguardando você entrar no navegador…"
        return "https://accounts.spotify.com/authorize?" + Http.form(
            linkedMapOf(
                "client_id" to cid,
                "response_type" to "code",
                "redirect_uri" to redirect,
                "scope" to scopes,
                "code_challenge_method" to "S256",
                "code_challenge" to Pkce.challenge(verifier),
                "state" to state
            )
        )
    }

    /** Chamado quando o navegador volta para cacau://spotify?code=... */
    fun handleRedirect(uri: Uri) {
        val code = uri.getQueryParameter("code")
        val state = uri.getQueryParameter("state")
        if (code == null || state != store.s("s_state")) {
            status = "Erro no login: " + (uri.getQueryParameter("error") ?: "resposta inválida")
            return
        }
        Thread {
            try {
                val r = Http.request(
                    "POST", "https://accounts.spotify.com/api/token",
                    mapOf("Content-Type" to "application/x-www-form-urlencoded"),
                    Http.form(
                        linkedMapOf(
                            "grant_type" to "authorization_code",
                            "code" to code,
                            "redirect_uri" to redirect,
                            "client_id" to store.s("s_client_id"),
                            "code_verifier" to store.s("s_verifier")
                        )
                    )
                )
                if (r.code !in 200..299) {
                    status = "Erro no login: " + r.body.take(140)
                    return@Thread
                }
                saveTokens(JSONObject(r.body))
                status = "Conectado"
            } catch (e: Exception) {
                status = "Erro no login: " + (e.message ?: "falha de rede")
            }
        }.start()
    }

    private fun saveTokens(j: JSONObject) {
        store.put("s_access", j.optString("access_token"))
        val rt = j.optString("refresh_token", "")
        if (rt.isNotEmpty()) store.put("s_refresh", rt)
        store.putL("s_exp", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L)
    }

    @Synchronized
    private fun token(): String {
        if (!connected()) throw ApiError(401, "Spotify não conectado.")
        if (store.l("s_exp") - 60000L > System.currentTimeMillis() && store.s("s_access").isNotEmpty()) {
            return store.s("s_access")
        }
        val r = Http.request(
            "POST", "https://accounts.spotify.com/api/token",
            mapOf("Content-Type" to "application/x-www-form-urlencoded"),
            Http.form(
                linkedMapOf(
                    "grant_type" to "refresh_token",
                    "refresh_token" to store.s("s_refresh"),
                    "client_id" to store.s("s_client_id")
                )
            )
        )
        if (r.code !in 200..299) {
            if (r.code == 400 || r.code == 401) {
                logout()
                throw ApiError(401, "O login do Spotify expirou. Entre de novo em Conexões.")
            }
            throw ApiError(502, "Spotify " + r.code)
        }
        saveTokens(JSONObject(r.body))
        return store.s("s_access")
    }

    private fun call(method: String, path: String, body: String? = null): HttpResp =
        Http.request(
            method, "https://api.spotify.com/v1$path",
            mapOf("Authorization" to "Bearer " + token(), "Content-Type" to "application/json"), body
        )

    private fun errText(r: HttpResp): String {
        return try {
            JSONObject(r.body).optJSONObject("error")?.optString("message", "") ?: ("erro " + r.code)
        } catch (e: Exception) {
            "erro " + r.code
        }
    }

    fun state(): JSONObject {
        val out = JSONObject().put("configured", true).put("playing", false).put("active", false)
            .put("volume", JSONObject.NULL).put("track", JSONObject.NULL)
        val r = call("GET", "/me/player")
        if (r.code == 204 || r.body.isEmpty()) return out
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val j = JSONObject(r.body)
        out.put("playing", j.optBoolean("is_playing", false))
        val dev = j.optJSONObject("device")
        if (dev != null) {
            out.put("active", dev.optBoolean("is_active", false))
            if (!dev.isNull("volume_percent")) out.put("volume", dev.optInt("volume_percent"))
        }
        val item = j.optJSONObject("item")
        if (item != null) {
            val names = ArrayList<String>()
            val ar = item.optJSONArray("artists") ?: JSONArray()
            for (i in 0 until ar.length()) names.add(ar.getJSONObject(i).optString("name"))
            val imgs = item.optJSONObject("album")?.optJSONArray("images")
            val img = if (imgs != null && imgs.length() > 0) imgs.getJSONObject(0).optString("url") else ""
            out.put(
                "track",
                JSONObject().put("name", item.optString("name")).put("artist", names.joinToString(", "))
                    .put("img", img).put("duration_ms", item.optLong("duration_ms"))
                    .put("progress_ms", j.optLong("progress_ms"))
            )
        }
        return out
    }

    fun playlists(): JSONArray {
        val r = call("GET", "/me/playlists?limit=30")
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
        val items = JSONObject(r.body).optJSONArray("items") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until items.length()) {
            val p = items.optJSONObject(i) ?: continue
            val imgs = p.optJSONArray("images")
            val img = if (imgs != null && imgs.length() > 0) imgs.getJSONObject(0).optString("url") else ""
            val total = p.optJSONObject("items")?.optInt("total", 0) ?: p.optJSONObject("tracks")?.optInt("total", 0) ?: 0
            out.put(
                JSONObject().put("uri", p.optString("uri")).put("name", p.optString("name"))
                    .put("img", img).put("tracks", total)
            )
        }
        return out
    }

    /** action: play | pause | next | prev | volume (value) ; uri opcional em "play". */
    fun control(j: JSONObject) {
        val action = j.optString("action")
        val uri = j.optString("uri", "")
        var r = send(action, j, uri)
        if (r.code == 404 || (r.code == 403 && r.body.contains("NO_ACTIVE_DEVICE"))) {
            if (!wakeDevice()) {
                openSpotifyApp()
                throw ApiError(409, "Abra o Spotify no celular, toque numa música e tente de novo.")
            }
            Thread.sleep(700)
            r = send(action, j, uri)
        }
        if (r.code == 403) throw ApiError(403, "O controle do player exige Spotify Premium. " + errText(r))
        if (r.code !in 200..299) throw ApiError(502, "Spotify: " + errText(r))
    }

    private fun send(action: String, j: JSONObject, uri: String): HttpResp = when (action) {
        "pause" -> call("PUT", "/me/player/pause")
        "next" -> call("POST", "/me/player/next")
        "prev" -> call("POST", "/me/player/previous")
        "volume" -> call("PUT", "/me/player/volume?volume_percent=" + j.optInt("value", 50))
        else -> {
            val b = JSONObject()
            if (uri.startsWith("spotify:track:")) b.put("uris", JSONArray().put(uri))
            else if (uri.isNotEmpty()) b.put("context_uri", uri)
            call("PUT", "/me/player/play", if (b.length() > 0) b.toString() else "")
        }
    }

    private fun wakeDevice(): Boolean {
        val r = call("GET", "/me/player/devices")
        if (r.code !in 200..299) return false
        val arr = JSONObject(r.body).optJSONArray("devices") ?: return false
        if (arr.length() == 0) return false
        var pick = arr.getJSONObject(0)
        for (i in 0 until arr.length()) {
            val d = arr.getJSONObject(i)
            if (d.optString("type").equals("Smartphone", true)) { pick = d; break }
        }
        val body = JSONObject().put("device_ids", JSONArray().put(pick.getString("id"))).put("play", false)
        return call("PUT", "/me/player", body.toString()).code in 200..299
    }

    private fun openSpotifyApp() {
        try {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.spotify.music")
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            }
        } catch (e: Exception) { }
    }
}
