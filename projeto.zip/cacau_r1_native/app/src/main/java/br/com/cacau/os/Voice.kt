package br.com.cacau.os

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Fala (TTS) e escuta (STT) nativas do Android. */
class Voice(private val act: Activity) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null
    @Volatile private var heard: String = ""
    @Volatile private var latch: CountDownLatch = CountDownLatch(0)

    init {
        tts = TextToSpeech(act) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale("pt", "BR")
            }
        }
    }

    fun sttAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(act)

    fun speak(text: String, volPercent: Int, lang: String) {
        if (!ttsReady || text.isEmpty()) return
        act.runOnUiThread {
            val t = tts ?: return@runOnUiThread
            val loc = if (lang.isEmpty()) Locale("pt", "BR") else Locale.forLanguageTag(lang)
            t.language = loc
            val params = Bundle()
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, (volPercent.coerceIn(0, 100)) / 100f)
            t.speak(text, TextToSpeech.QUEUE_FLUSH, params, "cacau")
        }
    }

    fun start() {
        heard = ""
        latch = CountDownLatch(1)
        act.runOnUiThread {
            try {
                rec?.destroy()
                val r = SpeechRecognizer.createSpeechRecognizer(act)
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                    override fun onError(error: Int) { latch.countDown() }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val l = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (l != null && l.isNotEmpty()) heard = l[0]
                    }
                    override fun onResults(results: Bundle?) {
                        val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (l != null && l.isNotEmpty()) heard = l[0]
                        latch.countDown()
                    }
                })
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                rec = r
                r.startListening(i)
            } catch (e: Exception) {
                latch.countDown()
            }
        }
    }

    /** Para de ouvir e devolve o que foi entendido (espera até ~4 s pelo resultado final). */
    fun stop(): String {
        act.runOnUiThread {
            try { rec?.stopListening() } catch (e: Exception) { }
        }
        try { latch.await(4, TimeUnit.SECONDS) } catch (e: InterruptedException) { }
        val text = heard
        act.runOnUiThread {
            try { rec?.destroy() } catch (e: Exception) { }
            rec = null
        }
        return text
    }

    fun shutdown() {
        tts?.shutdown()
        act.runOnUiThread {
            try { rec?.destroy() } catch (e: Exception) { }
        }
    }
}
