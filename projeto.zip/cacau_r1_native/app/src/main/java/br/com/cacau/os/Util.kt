package br.com.cacau.os

import android.content.Context
import android.util.Base64
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URLDecoder
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

/** Preferências privadas do app (chaves, IDs e tokens). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cacau_native", Context.MODE_PRIVATE)

    fun s(k: String): String = p.getString(k, "") ?: ""
    fun l(k: String): Long = p.getLong(k, 0L)
    fun put(k: String, v: String) { p.edit().putString(k, v).apply() }
    fun putL(k: String, v: Long) { p.edit().putLong(k, v).apply() }
    fun remove(vararg ks: String) {
        val e = p.edit()
        for (k in ks) e.remove(k)
        e.apply()
    }
}

class HttpResp(val code: Int, val body: String)

class ApiError(val status: Int, message: String) : Exception(message)

object Http {
    fun request(
        method: String,
        url: String,
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        timeoutMs: Int = 25000
    ): HttpResp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null || method == "PUT" || method == "POST") {
                c.doOutput = true
                val bytes = (body ?: "").toByteArray(Charsets.UTF_8)
                c.setFixedLengthStreamingMode(bytes.size)
                c.outputStream.use { it.write(bytes) }
            }
            val code = c.responseCode
            val stream = if (code in 200..399) c.inputStream else c.errorStream
            val text = if (stream == null) "" else stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return HttpResp(code, text)
        } finally {
            c.disconnect()
        }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun form(m: Map<String, String>): String {
        val sb = StringBuilder()
        for ((k, v) in m) {
            if (sb.isNotEmpty()) sb.append('&')
            sb.append(enc(k)).append('=').append(enc(v))
        }
        return sb.toString()
    }
}

object Pkce {
    private const val FLAGS = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    fun random(bytes: Int): String {
        val b = ByteArray(bytes)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, FLAGS)
    }

    fun challenge(verifier: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        return Base64.encodeToString(d, FLAGS)
    }
}

/** Espera o navegador voltar para 127.0.0.1 com ?code=... (ignora conexões de teste do Chrome). */
object Loopback {
    fun wait(ss: ServerSocket): HashMap<String, String> {
        var tries = 0
        while (tries < 10) {
            tries++
            val sock = ss.accept()
            var params: HashMap<String, String>? = null
            try {
                sock.soTimeout = 5000
                val line = sock.getInputStream().bufferedReader().readLine() ?: ""
                val q = line.substringAfter("?", "").substringBefore(" ")
                if (line.startsWith("GET") && (q.contains("code=") || q.contains("error="))) {
                    val m = HashMap<String, String>()
                    for (pair in q.split("&")) {
                        if (pair.isEmpty()) continue
                        val k = URLDecoder.decode(pair.substringBefore("="), "UTF-8")
                        val v = URLDecoder.decode(pair.substringAfter("=", ""), "UTF-8")
                        m[k] = v
                    }
                    params = m
                }
                val good = params != null && params.containsKey("code")
                val msg = if (params == null) "Aguardando..." else if (good) "Conectado! Pode voltar para o app Cacau." else "Nao deu certo. Volte ao app e tente de novo."
                val html = "<html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'></head>" +
                    "<body style='font-family:sans-serif;text-align:center;margin-top:20vh'><h2>" + msg + "</h2></body></html>"
                val bytes = html.toByteArray(Charsets.UTF_8)
                val out = sock.getOutputStream()
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " +
                        bytes.size + "\r\nConnection: close\r\n\r\n").toByteArray()
                )
                out.write(bytes)
                out.flush()
            } catch (e: Exception) {
            }
            try { sock.close() } catch (e: Exception) { }
            if (params != null) return params
        }
        throw ApiError(408, "O navegador não voltou para o app.")
    }
}
