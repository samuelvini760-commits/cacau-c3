package br.com.cacau.os

import android.content.Context
import android.util.Base64
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URLDecoder
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

/** Cofre: cifra segredos (chaves, tokens) com uma chave que fica no Android Keystore, nunca no arquivo de preferências. */
object Vault {
    private const val ALIAS = "cacau_vault_v1"
    private const val TAG = "v1:"

    /** O Keystore de alguns celulares falha por instantes (logo após ligar, tela bloqueando). Tenta de novo antes de desistir. */
    private fun key(): SecretKey? {
        for (attempt in 0 until 4) {
            try {
                val ks = KeyStore.getInstance("AndroidKeyStore")
                ks.load(null)
                val k = ks.getKey(ALIAS, null) as? SecretKey
                if (k != null) return k
                // só cria uma chave nova quando a chave realmente não existe (não por erro passageiro)
                if (ks.containsAlias(ALIAS)) throw IllegalStateException("chave indisponível")
                val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                g.init(
                    KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256).build()
                )
                return g.generateKey()
            } catch (e: Exception) {
                try { Thread.sleep(150L * (attempt + 1)) } catch (ie: InterruptedException) { }
            }
        }
        return null
    }

    fun seal(plain: String): String {
        if (plain.isEmpty()) return plain
        return try {
            val k = key() ?: return plain
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, k)
            val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            TAG + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) { plain }
    }

    /** Devolve "" se o texto cifrado não abre mais (ex.: o Keystore foi zerado): o app só pede para entrar de novo. */
    fun open(stored: String): String {
        if (!stored.startsWith(TAG)) return stored
        return try {
            val raw = Base64.decode(stored.substring(TAG.length), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key() ?: return "", GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (e: Exception) { "" }
    }
}

/** Preferências privadas do app (chaves, IDs e tokens). Segredos ficam cifrados pelo Vault. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cacau_native", Context.MODE_PRIVATE)
    private val secret = setOf("groq_key", "g_client_secret", "g_refresh", "g_access", "s_refresh", "s_access")

    init {
        // migra valores antigos (texto puro) para o formato cifrado
        val e = p.edit()
        var dirty = false
        for (k in secret) {
            val v = p.getString(k, "") ?: ""
            if (v.isNotEmpty() && !v.startsWith("v1:")) {
                val sealed = Vault.seal(v)
                if (sealed != v) { e.putString(k, sealed); dirty = true }
            }
        }
        if (dirty) e.apply()
    }

    // segredos já abertos ficam na memória: uma falha passageira do Keystore não derruba o login
    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun s(k: String): String {
        if (k !in secret) return p.getString(k, "") ?: ""
        cache[k]?.let { return it }
        val v = Vault.open(p.getString(k, "") ?: "")
        if (v.isNotEmpty()) cache[k] = v
        return v
    }
    fun l(k: String): Long = p.getLong(k, 0L)
    fun put(k: String, v: String) {
        if (k in secret) { if (v.isEmpty()) cache.remove(k) else cache[k] = v }
        p.edit().putString(k, if (k in secret) Vault.seal(v) else v).apply()
    }
    fun putL(k: String, v: Long) { p.edit().putLong(k, v).apply() }
    fun remove(vararg ks: String) {
        val e = p.edit()
        for (k in ks) { e.remove(k); cache.remove(k) }
        e.apply()
    }
}

class HttpResp(val code: Int, val body: String)

class ApiError(val status: Int, message: String) : Exception(message)

object Http {
    fun request(
        method: String,
        url: String,
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        timeoutMs: Int = 25000
    ): HttpResp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "CacauOS/2.0 (Android)")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null || method == "PUT" || method == "POST") {
                c.doOutput = true
                val bytes = (body ?: "").toByteArray(Charsets.UTF_8)
                c.setFixedLengthStreamingMode(bytes.size)
                c.outputStream.use { it.write(bytes) }
            }
            val code = c.responseCode
            val stream = if (code in 200..399) c.inputStream else c.errorStream
            val text = if (stream == null) "" else stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return HttpResp(code, text)
        } finally {
            c.disconnect()
        }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun form(m: Map<String, String>): String {
        val sb = StringBuilder()
        for ((k, v) in m) {
            if (sb.isNotEmpty()) sb.append('&')
            sb.append(enc(k)).append('=').append(enc(v))
        }
        return sb.toString()
    }
}

object Pkce {
    private const val FLAGS = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    fun random(bytes: Int): String {
        val b = ByteArray(bytes)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, FLAGS)
    }

    fun challenge(verifier: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        return Base64.encodeToString(d, FLAGS)
    }
}

/** Espera o navegador voltar para 127.0.0.1 com ?code=... (ignora conexões de teste do Chrome). */
object Loopback {
    fun wait(ss: ServerSocket): HashMap<String, String> {
        var tries = 0
        while (tries < 10) {
            tries++
            val sock = ss.accept()
            var params: HashMap<String, String>? = null
            try {
                sock.soTimeout = 5000
                val line = sock.getInputStream().bufferedReader().readLine() ?: ""
                val q = line.substringAfter("?", "").substringBefore(" ")
                if (line.startsWith("GET") && (q.contains("code=") || q.contains("error="))) {
                    val m = HashMap<String, String>()
                    for (pair in q.split("&")) {
                        if (pair.isEmpty()) continue
                        val k = URLDecoder.decode(pair.substringBefore("="), "UTF-8")
                        val v = URLDecoder.decode(pair.substringAfter("=", ""), "UTF-8")
                        m[k] = v
                    }
                    params = m
                }
                val good = params != null && params.containsKey("code")
                val msg = if (params == null) "Aguardando..." else if (good) "Pronto! Volte para o Cacau." else "Não deu certo. Volte ao Cacau e tente de novo."
                val html = "<html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'></head>" +
                    "<body style='font-family:sans-serif;text-align:center;margin-top:16vh;padding:0 6vw'><h2>" + msg + "</h2>" +
                    (if (params != null) "<p><a href='cacau://voltar' style='display:inline-block;padding:14px 26px;border-radius:30px;background:#ff5a1f;color:#1c0800;font-weight:700;text-decoration:none'>Voltar ao Cacau</a></p>" else "") +
                    "</body></html>"
                val bytes = html.toByteArray(Charsets.UTF_8)
                val out = sock.getOutputStream()
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " +
                        bytes.size + "\r\nConnection: close\r\n\r\n").toByteArray()
                )
                out.write(bytes)
                out.flush()
            } catch (e: Exception) {
            }
            try { sock.close() } catch (e: Exception) { }
            if (params != null) return params
        }
        throw ApiError(408, "O navegador não voltou para o app.")
    }
}
