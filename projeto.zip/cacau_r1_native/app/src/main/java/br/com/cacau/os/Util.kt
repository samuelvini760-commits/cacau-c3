package br.com.cacau.os

import android.content.Context
import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

/** Preferências privadas do app (chaves, IDs e tokens). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cacau_native", Context.MODE_PRIVATE)

    fun s(k: String): String = p.getString(k, "") ?: ""
    fun l(k: String): Long = p.getLong(k, 0L)
    fun put(k: String, v: String) { p.edit().putString(k, v).apply() }
    fun putL(k: String, v: Long) { p.edit().putLong(k, v).apply() }
    fun remove(vararg ks: String) {
        val e = p.edit()
        for (k in ks) e.remove(k)
        e.apply()
    }
}

class HttpResp(val code: Int, val body: String)

class ApiError(val status: Int, message: String) : Exception(message)

object Http {
    fun request(
        method: String,
        url: String,
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        timeoutMs: Int = 25000
    ): HttpResp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null || method == "PUT" || method == "POST") {
                c.doOutput = true
                val bytes = (body ?: "").toByteArray(Charsets.UTF_8)
                c.setFixedLengthStreamingMode(bytes.size)
                c.outputStream.use { it.write(bytes) }
            }
            val code = c.responseCode
            val stream = if (code in 200..399) c.inputStream else c.errorStream
            val text = if (stream == null) "" else stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return HttpResp(code, text)
        } finally {
            c.disconnect()
        }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun form(m: Map<String, String>): String {
        val sb = StringBuilder()
        for ((k, v) in m) {
            if (sb.isNotEmpty()) sb.append('&')
            sb.append(enc(k)).append('=').append(enc(v))
        }
        return sb.toString()
    }
}

object Pkce {
    private const val FLAGS = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    fun random(bytes: Int): String {
        val b = ByteArray(bytes)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, FLAGS)
    }

    fun challenge(verifier: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        return Base64.encodeToString(d, FLAGS)
    }
}
