package br.com.cacau.os

import org.json.JSONArray
import org.json.JSONObject

/** IA online: API da Groq (formato OpenAI, plano grátis). A chave fica só neste aparelho. */
object Groq {
    const val PERSONA =
        "Você é o Cacau, um passarinho assistente de bolso, simpático e curioso. " +
            "Responda em português do Brasil, em no máximo duas frases curtas, sem listas e sem formatação, " +
            "porque sua resposta aparece numa tela pequena e é falada em voz alta."

    private const val URL = "https://api.groq.com/openai/v1/chat/completions"
    private const val MODELS_URL = "https://api.groq.com/openai/v1/models"

    private val HARD = Regex(
        "\\b(explique|explica|analis|compar|planej|resum|por ?que|como funciona|diferen[cç]a|vantagens|" +
            "pr[oó]s e contras|estrat[eé]gia|escreva|redij|demonstr|calcule|passo a passo)",
        RegexOption.IGNORE_CASE
    )

    fun tierFor(text: String, mode: String): String {
        val words = text.trim().split(Regex("\\s+")).size
        return if (mode == "smart" && words <= 7 && !HARD.containsMatchIn(text)) "fast" else mode
    }

    // A Groq aposenta modelos de tempos em tempos (llama-3.3-70b-versatile e llama-3.1-8b-instant saíram em 16/08/2026).
    // Por isso o app pergunta à própria Groq quais modelos a chave enxerga e usa o primeiro da lista de preferência
    // que existir; se a consulta falhar, tenta a lista de preferência mesmo assim.
    private val LEGACY = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant") // só funcionam em contas enterprise
    private val NOT_TEXT = Regex("whisper|orpheus|tts|guard|safeguard|compound|embed|playai|distil", RegexOption.IGNORE_CASE)

    private fun prefs(tier: String): List<String> = when (tier) {
        "fast" -> listOf("openai/gpt-oss-20b", "openai/gpt-oss-120b", "qwen/qwen3.8-27b", "qwen/qwen3.6-27b")
        else -> listOf("openai/gpt-oss-120b", "qwen/qwen3.8-27b", "openai/gpt-oss-20b", "qwen/qwen3.6-27b")
    }

    @Volatile private var modelCache: Pair<Long, List<String>>? = null

    /** Apaga a lista guardada (chamado quando a chave muda). */
    fun forgetModels() { modelCache = null }

    /** Modelos que a chave enxerga, ou null se não deu para saber. Lança erro claro se a chave for recusada. */
    private fun available(key: String): List<String>? {
        val c = modelCache
        if (c != null && System.currentTimeMillis() - c.first < 10 * 60 * 1000) return c.second
        return try {
            val r = Http.request("GET", MODELS_URL, mapOf("Authorization" to "Bearer $key"), null, 12000)
            if (r.code == 401) throw ApiError(401, "Groq: " + friendly(errInfo(r.body), 401, ""))
            if (r.code !in 200..299) return null
            val arr = JSONObject(r.body).optJSONArray("data") ?: return null
            val ids = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val id = arr.getJSONObject(i).optString("id")
                if (id.isNotEmpty()) ids.add(id)
            }
            if (ids.isEmpty()) return null
            modelCache = Pair(System.currentTimeMillis(), ids)
            ids
        } catch (e: ApiError) { throw e } catch (e: Exception) { null }
    }

    private fun sizeOf(id: String): Int = Regex("(\\d+)b", RegexOption.IGNORE_CASE).find(id)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    private fun models(key: String, tier: String): List<String> {
        val want = prefs(tier) + LEGACY
        val have = available(key) ?: return want
        val hit = want.filter { it in have }
        if (hit.isNotEmpty()) return hit
        val other = have.filter { !NOT_TEXT.containsMatchIn(it) }.sortedByDescending { sizeOf(it) }.take(3)
        return if (other.isNotEmpty()) other else want
    }

    private fun visionModels(key: String): List<String> {
        val guess = listOf("qwen/qwen3.8-27b", "qwen/qwen3.6-27b", "meta-llama/llama-4-scout-17b-16e-instruct")
        val have = available(key) ?: return guess
        val hint = Regex("vision|[-/]vl|scout|maverick|qwen3\\.[5-9]|gemma-?3|pixtral|llava", RegexOption.IGNORE_CASE)
        val hit = have.filter { hint.containsMatchIn(it) && !NOT_TEXT.containsMatchIn(it) }
        return if (hit.isNotEmpty()) hit.take(3) else guess.filter { it in have }
    }

    /** Parâmetros extras por modelo: os gpt-oss são de raciocínio, então limitamos o quanto pensam. */
    private fun extras(model: String, tier: String): JSONObject {
        val o = JSONObject()
        if (model.startsWith("openai/gpt-oss") && !model.contains("safeguard")) {
            o.put("reasoning_effort", when (tier) { "deep" -> "medium"; "max" -> "high"; else -> "low" })
            o.put("include_reasoning", false)
        }
        return o
    }

    /** Confere o que o usuário colou antes de salvar. Devolve a chave limpa ou explica o erro em português. */
    fun cleanKey(raw: String): String {
        val k = raw.trim().trim('"', '\'', '`').replace(Regex("\\s+"), "")
        if (k.isEmpty()) return ""
        if (k.startsWith("AIza"))
            throw ApiError(400, "Essa chave é do Gemini. A da Groq começa com gsk_ e vem de console.groq.com/keys.")
        if (k.startsWith("sk-"))
            throw ApiError(400, "Essa chave é de outro serviço (Claude/OpenAI). A da Groq começa com gsk_ e vem de console.groq.com/keys.")
        if (k.endsWith(".apps.googleusercontent.com") || k.startsWith("GOCSPX-"))
            throw ApiError(400, "Isso é do login Google (Client ID/secret). Aqui vai a chave da Groq, que começa com gsk_.")
        if (!k.startsWith("gsk_"))
            throw ApiError(400, "A chave da Groq começa com gsk_. Copie ela de console.groq.com/keys.")
        if (k.length < 20) throw ApiError(400, "A chave está curta demais. Copie ela inteira, sem cortar o final.")
        return k
    }

    private fun maxTokens(tier: String): Int = when (tier) {
        "fast" -> 1024
        "smart" -> 2048
        "deep" -> 4096
        else -> 6000
    }

    private fun msg(role: String, content: Any): JSONObject = JSONObject().put("role", role).put("content", content)

    private fun post(key: String, body: JSONObject, timeoutMs: Int) = Http.request(
        "POST", URL,
        mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key"),
        body.toString(), timeoutMs
    )

    /** Devolve (texto, modelo usado). Tenta os modelos da lista em ordem e pula os que sumiram, estouraram o limite ou falharam. */
    private fun run(key: String, tier: String, modelList: List<String>, messages: JSONArray, maxTok: Int): Pair<String, String> {
        var lastMsg = "a IA não respondeu"
        var gone = 0
        for (model in modelList) {
            var ex = extras(model, tier)
            var attempt = 0
            while (attempt < 2) {
                attempt++
                val body = JSONObject().put("model", model).put("messages", messages).put("max_tokens", maxTok)
                for (k in ex.keys()) body.put(k, ex.get(k))
                val r = post(key, body, 45000)
                if (r.code in 200..299) {
                    val text = extract(r.body)
                    if (text.isNotEmpty()) return Pair(text, model)
                    lastMsg = "resposta vazia"
                    break
                }
                val info = errInfo(r.body)
                lastMsg = friendly(info, r.code, model)
                if (r.code == 401) throw ApiError(401, "Groq: $lastMsg")
                if (r.code == 400 && ex.length() > 0 && !info.gone) { ex = JSONObject(); continue } // parâmetro que o modelo não aceita
                if (info.gone) gone++
                break
            }
        }
        if (gone > 0 && gone == modelList.size)
            throw ApiError(404, "a Groq não liberou nenhum modelo de texto para essa chave. Crie uma chave nova em console.groq.com/keys e, no projeto dela, confira em Limites se algum modelo está bloqueado.")
        throw ApiError(502, lastMsg)
    }

    fun generate(key: String, tier: String, system: String, chat: JSONArray): Pair<String, String> {
        val messages = JSONArray().put(msg("system", system))
        for (i in 0 until chat.length()) messages.put(chat.getJSONObject(i))
        return run(key, tier, models(key, tier), messages, maxTokens(tier))
    }

    private fun extract(raw: String): String {
        val j = JSONObject(raw)
        val ch = j.optJSONArray("choices") ?: return ""
        if (ch.length() == 0) return ""
        val t = ch.getJSONObject(0).optJSONObject("message")?.optString("content", "") ?: ""
        return t.replace(Regex("(?s)<think>.*?</think>"), "").trim()
    }

    private class ErrInfo(val msg: String, val code: String, val gone: Boolean)

    private fun errInfo(raw: String): ErrInfo {
        var msg = ""
        var code = ""
        try {
            val e = JSONObject(raw).optJSONObject("error")
            msg = e?.optString("message", "") ?: ""
            code = e?.optString("code", "") ?: ""
        } catch (e: Exception) { }
        val low = msg.lowercase()
        val gone = code == "model_not_found" || code == "model_decommissioned" || code == "model_permission_blocked_project" ||
            low.contains("does not exist") || low.contains("decommission") || low.contains("no longer supported") ||
            low.contains("do not have access")
        return ErrInfo(msg, code, gone)
    }

    private fun friendly(i: ErrInfo, code: Int, model: String): String = when {
        code == 401 || i.msg.contains("invalid api key", true) ->
            "chave inválida. Copie de novo em console.groq.com/keys (começa com gsk_)."
        i.gone -> "o modelo " + (if (model.isEmpty()) "" else "$model ") + "não está disponível para essa chave (a Groq aposenta modelos de tempos em tempos)."
        code == 429 -> "o limite grátis da Groq acabou por agora. Espere 1 minuto e tente de novo."
        code == 403 -> "a Groq recusou essa chave" + (if (i.msg.isNotEmpty()) " (" + i.msg.take(90) + ")" else "") + "."
        code == 413 -> "a mensagem ficou grande demais para a Groq."
        code == 503 || code == 502 -> "a Groq está sobrecarregada agora. Tente de novo em instantes."
        i.msg.isNotEmpty() -> i.msg.take(160)
        else -> "erro $code"
    }

    fun ask(key: String, text: String, history: JSONArray?, mode: String): Triple<String, String, String> {
        val tier = tierFor(text, mode)
        val chat = JSONArray()
        if (history != null) {
            val from = maxOf(0, history.length() - 6)
            for (i in from until history.length()) {
                val h = history.getJSONObject(i)
                val role = if (h.optString("role") == "assistant") "assistant" else "user"
                val c = h.optString("content")
                if (c.isNotEmpty()) chat.put(msg(role, c))
            }
        }
        chat.put(msg("user", text))
        val r = generate(key, tier, PERSONA, chat)
        return Triple(r.first, r.second, tier)
    }

    fun vision(key: String, imageB64: String, prompt: String): String {
        val parts = JSONArray()
            .put(JSONObject().put("type", "text").put("text", if (prompt.isEmpty()) "Descreva o que você vê." else prompt))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imageB64")))
        val messages = JSONArray()
            .put(msg("system", "$PERSONA Você está olhando pela câmera do aparelho."))
            .put(msg("user", parts))
        val vm = visionModels(key)
        if (vm.isEmpty()) throw ApiError(422, "a Groq não tem modelo que enxerga imagens para essa chave agora.")
        return run(key, "vision", vm, messages, 1024).first
    }

    fun translate(key: String, text: String, to: String): String {
        val sys = "Você é um tradutor. Traduza o texto do usuário para $to. " +
            "Responda SOMENTE com a tradução, sem aspas e sem explicações."
        val chat = JSONArray().put(msg("user", text))
        return generate(key, "fast", sys, chat).first
    }

    /** Pede uma resposta em JSON (usado para o "clima" das músicas). Devolve null se a IA não conseguir. */
    fun json(key: String, prompt: String, timeoutMs: Int = 12000): JSONObject? {
        val list = try { models(key, "fast") } catch (e: Exception) { return null }
        for (model in list.take(2)) {
            for (mode in 0..1) { // 0: com response_format json; 1: sem (alguns modelos não aceitam)
                val body = JSONObject().put("model", model)
                    .put("messages", JSONArray().put(msg("user", "$prompt\nResponda somente com um objeto JSON.")))
                    .put("max_tokens", 900).put("temperature", 0.2)
                val ex = extras(model, "fast")
                for (k in ex.keys()) body.put(k, ex.get(k))
                if (mode == 0) body.put("response_format", JSONObject().put("type", "json_object"))
                val r = try { post(key, body, timeoutMs) } catch (e: Exception) { return null }
                if (r.code in 200..299) {
                    val t = try { extract(r.body) } catch (e: Exception) { return null }
                    val a = t.indexOf('{')
                    val b = t.lastIndexOf('}')
                    if (a >= 0 && b > a) return try { JSONObject(t.substring(a, b + 1)) } catch (e: Exception) { null }
                    return null
                }
                if (r.code == 401 || r.code == 403 || r.code == 429) return null
                if (r.code != 400) break
            }
        }
        return null
    }
}
