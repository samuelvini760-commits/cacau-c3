package br.com.cacau.os

import org.json.JSONArray
import org.json.JSONObject

/** IA online: API da Groq (formato OpenAI, plano grátis). A chave fica só neste aparelho. */
object Groq {
    const val PERSONA =
        "Você é o Cacau, um passarinho assistente de bolso, simpático e curioso. " +
            "Responda em português do Brasil, em no máximo duas frases curtas, sem listas e sem formatação, " +
            "porque sua resposta aparece numa tela pequena e é falada em voz alta."

    private const val URL = "https://api.groq.com/openai/v1/chat/completions"
    private const val VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"

    private val HARD = Regex(
        "\\b(explique|explica|analis|compar|planej|resum|por ?que|como funciona|diferen[cç]a|vantagens|" +
            "pr[oó]s e contras|estrat[eé]gia|escreva|redij|demonstr|calcule|passo a passo)",
        RegexOption.IGNORE_CASE
    )

    fun tierFor(text: String, mode: String): String {
        val words = text.trim().split(Regex("\\s+")).size
        return if (mode == "smart" && words <= 7 && !HARD.containsMatchIn(text)) "fast" else mode
    }

    // Se um modelo sumir ou for aposentado, cai para o próximo da lista.
    private fun models(tier: String): List<String> = when (tier) {
        "fast" -> listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile")
        "deep", "max" -> listOf("openai/gpt-oss-120b", "llama-3.3-70b-versatile", "llama-3.1-8b-instant")
        else -> listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant")
    }

    /** Confere o que o usuário colou antes de salvar. Devolve a chave limpa ou explica o erro em português. */
    fun cleanKey(raw: String): String {
        val k = raw.trim().trim('"', '\'', '`').replace(Regex("\\s+"), "")
        if (k.isEmpty()) return ""
        if (k.startsWith("AIza"))
            throw ApiError(400, "Essa chave é do Gemini. A da Groq começa com gsk_ e vem de console.groq.com/keys.")
        if (k.startsWith("sk-"))
            throw ApiError(400, "Essa chave é de outro serviço (Claude/OpenAI). A da Groq começa com gsk_ e vem de console.groq.com/keys.")
        if (k.endsWith(".apps.googleusercontent.com") || k.startsWith("GOCSPX-"))
            throw ApiError(400, "Isso é do login Google (Client ID/secret). Aqui vai a chave da Groq, que começa com gsk_.")
        if (!k.startsWith("gsk_"))
            throw ApiError(400, "A chave da Groq começa com gsk_. Copie ela de console.groq.com/keys.")
        if (k.length < 20) throw ApiError(400, "A chave está curta demais. Copie ela inteira, sem cortar o final.")
        return k
    }

    private fun maxTokens(tier: String): Int = when (tier) {
        "fast" -> 1024
        "smart" -> 2048
        "deep" -> 4096
        else -> 6000
    }

    private fun msg(role: String, content: Any): JSONObject = JSONObject().put("role", role).put("content", content)

    private fun post(key: String, body: JSONObject, timeoutMs: Int) = Http.request(
        "POST", URL,
        mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key"),
        body.toString(), timeoutMs
    )

    /** Devolve (texto, modelo usado). Tenta o modelo do nível e cai para o seguinte se ele não existir. */
    private fun run(key: String, modelList: List<String>, messages: JSONArray, maxTok: Int): Pair<String, String> {
        var lastMsg = "a IA não respondeu"
        for (model in modelList) {
            val body = JSONObject().put("model", model).put("messages", messages).put("max_tokens", maxTok)
            val r = post(key, body, 45000)
            if (r.code in 200..299) {
                val text = extract(r.body)
                if (text.isNotEmpty()) return Pair(text, model)
                lastMsg = "resposta vazia"
                continue
            }
            lastMsg = errMsg(r.body, r.code)
            if (r.code == 401 || r.code == 403) throw ApiError(r.code, "Groq: $lastMsg")
            if (r.code != 400 && r.code != 404 && r.code != 413 && r.code != 429 && r.code < 500) break
        }
        throw ApiError(502, lastMsg)
    }

    fun generate(key: String, tier: String, system: String, chat: JSONArray): Pair<String, String> {
        val messages = JSONArray().put(msg("system", system))
        for (i in 0 until chat.length()) messages.put(chat.getJSONObject(i))
        return run(key, models(tier), messages, maxTokens(tier))
    }

    private fun extract(raw: String): String {
        val j = JSONObject(raw)
        val ch = j.optJSONArray("choices") ?: return ""
        if (ch.length() == 0) return ""
        val t = ch.getJSONObject(0).optJSONObject("message")?.optString("content", "") ?: ""
        return t.replace(Regex("(?s)<think>.*?</think>"), "").trim()
    }

    private fun errMsg(raw: String, code: Int): String {
        var msg = ""
        try { msg = JSONObject(raw).optJSONObject("error")?.optString("message", "") ?: "" } catch (e: Exception) { }
        return when {
            code == 401 || msg.contains("invalid api key", true) ->
                "chave inválida. Copie de novo em console.groq.com/keys (começa com gsk_)."
            code == 429 -> "o limite grátis da Groq acabou por agora. Espere 1 minuto ou use o nível Rápida."
            code == 403 -> "a Groq recusou essa chave" + (if (msg.isNotEmpty()) " (" + msg.take(90) + ")" else "") + "."
            code == 413 -> "a mensagem ficou grande demais para a Groq."
            code == 503 || code == 502 -> "a Groq está sobrecarregada agora. Tente de novo em instantes."
            msg.isNotEmpty() -> msg.take(160)
            else -> "erro $code"
        }
    }

    fun ask(key: String, text: String, history: JSONArray?, mode: String): Triple<String, String, String> {
        val tier = tierFor(text, mode)
        val chat = JSONArray()
        if (history != null) {
            val from = maxOf(0, history.length() - 6)
            for (i in from until history.length()) {
                val h = history.getJSONObject(i)
                val role = if (h.optString("role") == "assistant") "assistant" else "user"
                val c = h.optString("content")
                if (c.isNotEmpty()) chat.put(msg(role, c))
            }
        }
        chat.put(msg("user", text))
        val r = generate(key, tier, PERSONA, chat)
        return Triple(r.first, r.second, tier)
    }

    fun vision(key: String, imageB64: String, prompt: String): String {
        val parts = JSONArray()
            .put(JSONObject().put("type", "text").put("text", if (prompt.isEmpty()) "Descreva o que você vê." else prompt))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imageB64")))
        val messages = JSONArray()
            .put(msg("system", "$PERSONA Você está olhando pela câmera do aparelho."))
            .put(msg("user", parts))
        return run(key, listOf(VISION_MODEL), messages, 1024).first
    }

    fun translate(key: String, text: String, to: String): String {
        val sys = "Você é um tradutor. Traduza o texto do usuário para $to. " +
            "Responda SOMENTE com a tradução, sem aspas e sem explicações."
        val chat = JSONArray().put(msg("user", text))
        return generate(key, "fast", sys, chat).first
    }

    /** Pede uma resposta em JSON (usado para o "clima" das músicas). Devolve null se a IA não conseguir. */
    fun json(key: String, prompt: String, timeoutMs: Int = 12000): JSONObject? {
        for (model in listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile")) {
            val body = JSONObject().put("model", model)
                .put("messages", JSONArray().put(msg("user", "$prompt\nResponda somente com um objeto JSON.")))
                .put("max_tokens", 300).put("temperature", 0.2)
                .put("response_format", JSONObject().put("type", "json_object"))
            val r = try { post(key, body, timeoutMs) } catch (e: Exception) { return null }
            if (r.code in 200..299) {
                val t = try { extract(r.body) } catch (e: Exception) { return null }
                val a = t.indexOf('{')
                val b = t.lastIndexOf('}')
                if (a >= 0 && b > a) return try { JSONObject(t.substring(a, b + 1)) } catch (e: Exception) { null }
                return null
            }
            if (r.code == 401 || r.code == 403 || r.code == 429) return null
        }
        return null
    }
}
