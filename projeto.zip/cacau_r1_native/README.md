# Cacau OS para Android

O seu `cacau-os-android-r3.html` empacotado como app Android, **sem mudar a interface**.
O app responde por dentro aos mesmos `/api/*` que o programa da placa respondia.

- IA fraca offline: hora, data e contas (e as regras que já estavam no HTML).
- IA forte online: Gemini (níveis Rápida, Equilibrada, Alta e Máxima).
- Google: Agenda, Gmail, Drive (backup das notas e rotinas) e YouTube (playlists e inscrições).
- Spotify: tocar, pausar, próxima, anterior, volume e playlists.
- Voz, escuta, câmera, Vision, Magic Câmera (fotos em Pictures/Cacau) e músicas do celular.

Tudo se configura na tela **Conexões** do próprio Cacau.

## Gemini
Crie uma chave grátis em https://aistudio.google.com/apikey, cole em Conexões, Salvar e Testar.

## Google (Agenda, Gmail, Drive, YouTube)
1. https://console.cloud.google.com: crie um projeto.
2. APIs e serviços, Biblioteca: ative Google Calendar API, Gmail API, Google Drive API e YouTube Data API v3.
3. Tela de consentimento OAuth: tipo Externo e adicione o seu e-mail em Usuários de teste.
4. Credenciais, Criar ID do cliente OAuth, tipo **App para computador**.
5. Cole o Client ID e o Client secret em Conexões, Salvar, Entrar.
   O Google avisa "app não verificado": toque em Avançado e continue.

Em modo de teste o Google desconecta a cada 7 dias; é só entrar de novo.

## Spotify
1. https://developer.spotify.com/dashboard: crie um app, Redirect URI `http://127.0.0.1:8888/callback`, marque Web API.
2. Cole o Client ID em Conexões, Salvar, Entrar.
3. Precisa de Spotify Premium e do app Spotify instalado no celular (é ele que toca).

## Novidades
- Abertura nova: vários calopsitas (o desenho geométrico do app) cobrem a tela e voam devagar da diagonal inferior esquerda para a superior direita, com asas batendo, rastros e faíscas. Dura cerca de 6 segundos.
- Desligar novo: uma pena facetada, no mesmo estilo, plana como folha caindo, do meio da tela até o chão, e a tela apaga.
- Spotify por dentro: playlists abrem no app, faixas tocam sem sair; se não há aparelho ligado, você escolhe um (não abre mais o Spotify à força).
- Cacau dança ao lado da música (Spotify e músicas do celular) e reage a TV Girl, Tame Impala e Daft Punk, e a momentos da letra (só marcações, o texto não é guardado).
- Telas não piscam mais; perfil leve (30 fps, sem sombras pesadas, sem fontes externas) para aparelhos fracos.
- Conexões: Colar, passo a passo, validação do Client ID/secret/chave, teste de cada serviço Google; chaves e tokens cifrados no Android Keystore.
- Nota: o Spotify fechou a análise de áudio para apps novos; o bpm vem do Gemini (se houver chave) ou de estimativa. Toque na Cacau no ritmo para ajustar. Playlists que não são suas só deixam listar músicas se forem colaborativas.

## Gerar o APK
Suba este ZIP como `projeto.zip` no repositório (o workflow já descompacta e compila).
O APK fica em Actions, Artifacts, `cacau-r1-debug-apk`.
