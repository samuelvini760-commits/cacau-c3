# Cacau OS para Android

O seu `cacau-os-android-r3.html` empacotado como app Android, **sem mudar a interface**.
O app responde por dentro aos mesmos `/api/*` que o programa da placa respondia.

- IA fraca offline: hora, data e contas (e as regras que já estavam no HTML).
- IA forte online: Groq, plano grátis (níveis Rápida, Equilibrada, Alta e Máxima). Os modelos são escolhidos sozinhos entre os que a sua chave enxerga (hoje GPT-OSS 20B e 120B), porque a Groq aposentou o Llama 3.x em 16/08/2026.
- Google: Agenda, Gmail, Drive (backup das notas e rotinas) e YouTube (playlists e inscrições).
- Spotify: tocar, pausar, próxima, anterior, volume e playlists.
- Voz, escuta, câmera, Vision, Magic Câmera (fotos em Pictures/Cacau) e músicas do celular.

Tudo se configura na tela **Conexões** do próprio Cacau.

## Groq
Crie uma chave grátis em https://console.groq.com/keys, cole em Conexões, Salvar e Testar.

## Google (Agenda, Gmail, Drive, YouTube)
1. https://console.cloud.google.com: crie um projeto.
2. APIs e serviços, Biblioteca: ative Google Calendar API, Gmail API, Google Drive API e YouTube Data API v3.
3. Tela de consentimento OAuth: tipo Externo e adicione o seu e-mail em Usuários de teste.
4. Credenciais, Criar ID do cliente OAuth, tipo **App para computador**.
5. Cole o Client ID e o Client secret em Conexões, Salvar, Entrar.
   O Google avisa "app não verificado": toque em Avançado e continue.

Em modo de teste o Google desconecta a cada 7 dias; é só entrar de novo.

## Spotify
1. https://developer.spotify.com/dashboard: crie um app, Redirect URI `http://127.0.0.1:8888/callback`, marque Web API.
2. Cole o Client ID em Conexões, Salvar, Entrar.
3. Precisa de Spotify Premium e do app Spotify instalado no celular (é ele que toca).

## Novidades
- Abertura leve: vários calopsitas cobrem a tela e voam devagar da diagonal inferior esquerda para a superior direita, com asas batendo e rastros. Só as asas animam (na GPU), então não trava.
- Desligar novo: uma pena de contorno grosso e cor chapada cai balançando e virando, amassa no chão sobre uma sombra cinza, e a tela apaga.
- Spotify por dentro: playlists abrem no app, faixas tocam sem sair; se não há aparelho ligado, você escolhe um (não abre mais o Spotify à força).
- Cacau dança ao lado da música (Spotify e músicas do celular) e reage a TV Girl, Tame Impala e Daft Punk, e a momentos da letra (só marcações, o texto não é guardado).
- Telas não piscam mais; perfil leve (30 fps, sem sombras pesadas, sem fontes externas) para aparelhos fracos.
- Conexões: Colar, passo a passo, validação do Client ID/secret/chave, teste de cada serviço Google; chaves e tokens cifrados no Android Keystore.
- Nota: o Spotify fechou a análise de áudio para apps novos; o bpm vem da Groq (se houver chave) ou de estimativa. Toque na Cacau no ritmo para ajustar. Playlists que não são suas só deixam listar músicas se forem colaborativas.

## Falar com o Cacau pelos botões do celular
- **Botão de ligar segurado**: o Android só entrega esse botão para o "assistente digital". Vá em Configurações, Apps, Apps padrão, App assistente digital, e escolha **Cacau OS**. Em alguns aparelhos também é preciso, em Configurações, Botão liga/desliga (ou Recursos avançados), trocar "Manter pressionado" para **Assistente digital**. Daí, segurar o botão abre o Cacau já ouvindo e ele responde sozinho quando você para de falar.
- **Volume segurado**: dentro do app, segurar o volume abre o modo conversa; toque curto continua mudando o volume. (Fora do app não dá sem serviço de acessibilidade, que o Play Protect bloqueia em apps instalados fora da loja.)
- Escolhendo o Cacau como assistente, ele passa a usar o reconhecimento de voz do Google (ou outro instalado) para a escuta.

## Gerar o APK
Suba este ZIP como `projeto.zip` no repositório (o workflow já descompacta e compila).
O APK fica em Actions, Artifacts, `cacau-r1-debug-apk`.
- Música por nome: "toca Tame Impala", "toca a música X do artista Y", "coloca TV girl pra tocar", "quero ouvir...", "toca X no celular", além de pausa, próxima, anterior e continuar. Entende erros comuns da voz (espotifai, teim impala, ti vi gol, daf pank). Precisa do Spotify conectado; sem ele, procura nas músicas do celular.
- Apertar o microfone (botão lateral, ligar ou volume) corta na hora o "não entendi" (voz, texto e histórico) e já abre a escuta.
- Tela inicial: a fala da Cacau ganhou um campo próprio (balão roxo com rolagem). O Cacau sobe e diminui enquanto fala, e o texto nunca é cortado.
- Tela do Spotify: botão "Buscar música ou artista". Digite ou segure o microfone e fale o nome; aparecem artistas e músicas com capa, e tocar é só um toque.

