# Cacau OS para Android

O seu `cacau-os-android-r3.html` empacotado como app Android, **sem mudar a interface**.
O app responde por dentro aos mesmos `/api/*` que o programa da placa respondia.

- IA fraca offline: hora, data e contas (e as regras que já estavam no HTML).
- IA forte online: Gemini (níveis Rápida, Equilibrada, Alta e Máxima).
- Google: Agenda, Gmail, Drive (backup das notas e rotinas) e YouTube (playlists e inscrições).
- Spotify: tocar, pausar, próxima, anterior, volume e playlists.
- Voz, escuta, câmera, Vision, Magic Câmera (fotos em Pictures/Cacau) e músicas do celular.

Tudo se configura na tela **Conexões** do próprio Cacau.

## Gemini
Crie uma chave grátis em https://aistudio.google.com/apikey, cole em Conexões, Salvar e Testar.

## Google (Agenda, Gmail, Drive, YouTube)
1. https://console.cloud.google.com: crie um projeto.
2. APIs e serviços, Biblioteca: ative Google Calendar API, Gmail API, Google Drive API e YouTube Data API v3.
3. Tela de consentimento OAuth: tipo Externo e adicione o seu e-mail em Usuários de teste.
4. Credenciais, Criar ID do cliente OAuth, tipo **App para computador**.
5. Cole o Client ID e o Client secret em Conexões, Salvar, Entrar.
   O Google avisa "app não verificado": toque em Avançado e continue.

Em modo de teste o Google desconecta a cada 7 dias; é só entrar de novo.

## Spotify
1. https://developer.spotify.com/dashboard: crie um app, Redirect URI `http://127.0.0.1:8888/callback`, marque Web API.
2. Cole o Client ID em Conexões, Salvar, Entrar.
3. Precisa de Spotify Premium e do app Spotify instalado no celular (é ele que toca).

## Gerar o APK
Suba este ZIP como `projeto.zip` no repositório (o workflow já descompacta e compila).
O APK fica em Actions, Artifacts, `cacau-r1-debug-apk`.
